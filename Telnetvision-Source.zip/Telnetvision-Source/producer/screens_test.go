package main

import (
	"math"
	"strings"
	"testing"
)

func TestParseScreenSource(t *testing.T) {
	for in, want := range map[string]screenSource{
		"screen":                   {kind: "all"},
		"Desktop":                  {kind: "all"},
		"screen1":                  {kind: "index", index: 1},
		"Screen 2":                 {kind: "index", index: 2},
		"screen:3":                 {kind: "index", index: 3},
		"monitor2":                 {kind: "index", index: 2},
		"display#4":                {kind: "index", index: 4},
		"screen:-1920,0,1920x1080": {kind: "region", region: screenInfo{X: -1920, Y: 0, W: 1920, H: 1080}},
		"window:Notepad":           {kind: "window", title: "Notepad"},
	} {
		got, ok := parseScreenSource(in)
		if !ok || got != want {
			t.Errorf("%q: got %+v %v", in, got, ok)
		}
	}
	for _, bad := range []string{"screen0", "screens2x", "camera", "window:", "screen:1,2"} {
		if _, ok := parseScreenSource(bad); ok {
			t.Errorf("%q should not be a screen", bad)
		}
	}
	if !isLiveSource("screen2") || !isLiveSource("window:VLC") || !isLiveSource("visualizer") {
		t.Error("screen sources are live")
	}
}

func TestScreenCaptureArgs(t *testing.T) {
	scr := []screenInfo{
		{X: 0, Y: 0, W: 2560, H: 1440, Primary: true},
		{X: -1920, Y: 180, W: 1920, H: 1080},
		{X: 2560, Y: 0, W: 1281, H: 1024},
	}
	orderScreens(scr)
	if !scr[0].Primary || scr[1].X != -1920 || scr[2].X != 2560 {
		t.Fatalf("order %+v", scr)
	}
	ss, _ := parseScreenSource("screen2")
	a, desc, err := screenCaptureArgs(ss, "15", "windows", "", scr)
	if err != nil || strings.Join(a, " ") != "-f gdigrab -framerate 15 -draw_mouse 1 -offset_x -1920 -offset_y 180 -video_size 1920x1080 -i desktop" {
		t.Fatalf("%q %v", a, err)
	}
	if !strings.Contains(desc, "screen2") {
		t.Error(desc)
	}
	ss, _ = parseScreenSource("screen3")
	a, _, _ = screenCaptureArgs(ss, "15", "windows", "", scr)
	if !strings.Contains(strings.Join(a, " "), "-video_size 1280x1024") {
		t.Errorf("odd width should be made even: %q", a)
	}
	ss, _ = parseScreenSource("screen4")
	if _, _, err := screenCaptureArgs(ss, "15", "windows", "", scr); err == nil || !strings.Contains(err.Error(), "3 screen") {
		t.Errorf("screen4: %v", err)
	}
	ss, _ = parseScreenSource("screen")
	a, _, _ = screenCaptureArgs(ss, "15", "windows", "", scr)
	if strings.Join(a, " ") != "-f gdigrab -framerate 15 -draw_mouse 1 -i desktop" {
		t.Errorf("all: %q", a)
	}
	ss, _ = parseScreenSource("window:My Game")
	a, _, _ = screenCaptureArgs(ss, "15", "windows", "", scr)
	if a[len(a)-1] != "title=My Game" {
		t.Errorf("window: %q", a)
	}
	ss, _ = parseScreenSource("screen:100,50,640x480")
	a, _, _ = screenCaptureArgs(ss, "15", "linux", ":0", nil)
	if strings.Join(a, " ") != "-f x11grab -framerate 15 -draw_mouse 1 -video_size 640x480 -i :0+100,50" {
		t.Errorf("x11 region: %q", a)
	}
}

func TestVizEngine(t *testing.T) {
	if vizPresetIndex("galaxy") != 1 || vizPresetIndex("NEON flower") < 0 || vizPresetIndex("nope") != -1 {
		t.Fatal("preset names")
	}
	e := newVizEngine(80, 48, 22050, 15, "auto", 2)
	var names []string
	e.announce = func(n string) { names = append(names, n) }
	pcm := make([]byte, 1470*2) // 1/15 s
	out := make([]byte, 80*48*3)
	for f := 0; f < 15*8; f++ {
		for i := 0; i < 1470; i++ {
			tt := float64(f*1470+i) / 22050
			v := 0.3 * math.Sin(2*math.Pi*330*tt)
			if math.Mod(tt, 0.5) < 0.1 { // a kick twice a second
				v += 0.6 * math.Sin(2*math.Pi*55*tt)
			}
			s := int16(v * 30000)
			pcm[2*i], pcm[2*i+1] = byte(s), byte(uint16(s)>>8)
		}
		e.feed(pcm, 1)
		e.frame(1.0/15, out)
	}
	lit := 0
	for _, b := range out {
		if b > 40 {
			lit++
		}
	}
	if lit < len(out)/50 {
		t.Errorf("the picture is nearly black (%d bright values)", lit)
	}
	if e.st.beats < 10 || e.st.beats > 20 {
		t.Errorf("beats %d in 8 s of two kicks a second", e.st.beats)
	}
	if len(names) < 2 {
		t.Errorf("auto should change look every 2 s: %v", names)
	}
	e.Next()
	before := e.preset
	e.frame(1.0/15, out)
	if e.preset == before {
		t.Error("V should change the look")
	}
}

func TestMatchWindowTitle(t *testing.T) {
	titles := []string{"Untitled - Notepad", "VLC media player", "notepad"}
	if matchWindowTitle(titles, "NOTEPAD") != "notepad" || matchWindowTitle(titles, "vlc") != "VLC media player" ||
		matchWindowTitle(titles, "untitled") != "Untitled - Notepad" || matchWindowTitle(titles, "word") != "" {
		t.Fatal("window title matching")
	}
}

func TestPasteText(t *testing.T) {
	c := newControls(&Config{})
	c.pasteText("https://www.youtube.com/@NASA\r\n")
	if l, txt, on := c.promptLine(); !on || txt != "https://www.youtube.com/@NASA" || !strings.HasPrefix(l, "Play") {
		t.Fatalf("paste opens the Play line: %q %q %v", l, txt, on)
	}
	c.key('\r')
	if a := <-c.actions; a.kind != "switch" || a.arg != "https://www.youtube.com/@NASA" {
		t.Fatalf("%+v", a)
	}
	// A short paste ("q") must not act as a key, and goes into an open line.
	c.key('t')
	c.pasteText("q")
	c.pasteText("\r\n\r\nsecond line only\r\nthird")
	if _, txt, _ := c.promptLine(); txt != "qsecond line only" {
		t.Fatalf("into the open line: %q", txt)
	}
	c.key(27)
	c.pasteText("")
	if _, _, on := c.promptLine(); on || c.flashText() == "" {
		t.Fatal("an empty clipboard just says so")
	}
}
