package main

import "strings"

// Movie night on/off for everyone, from the camera PC (MOVIE_NIGHT, the W
// key). Viewers still show or hide the chat for themselves with N; this
// decides whether they can. tvserver is told when the link comes up and
// whenever it changes.

const (
	msgMovieNight = 0x19 // producer -> tvserver: 0x19 | u8 1 = viewers may open movie night, 0 = not
	msgChat       = 0x25 // tvserver -> producer: 0x25 | u8 0 = a message, 1 = a notice | name | 0 | text
	capChat       = 0x10 // hello caps: show movie night's chat here (send CHAT)
)

func movieNightMsg(on bool) []byte {
	b := byte(0)
	if on {
		b = 1
	}
	return framed([]byte{msgMovieNight, b})
}

// MovieNight reports whether viewers may open movie night.
func (s *Sender) MovieNight() bool { return s.movieNight.Load() }

// SetMovieNight turns movie night on or off for everyone, and tells
// tvserver at once.
func (s *Sender) SetMovieNight(on bool) {
	s.movieNight.Store(on)
	if s.isTV.Load() {
		s.SendControl(movieNightMsg(on))
	}
}

// showChat writes a movie night chat line in this window.
func (s *Sender) showChat(b []byte) {
	name, text, ok := strings.Cut(string(b[2:]), "\x00")
	if !ok {
		return
	}
	clean := func(x string) string {
		return strings.Map(func(r rune) rune {
			if r < 32 || r == 127 {
				return ' '
			}
			return r
		}, x)
	}
	name, text = clean(name), clean(text)
	if b[1] == 1 {
		s.logf("movie night: %s %s", name, text)
	} else {
		s.logf("movie night  %s: %s", name, text)
	}
}
