package main

// Movie night: the picture on the left, a scrolling chat on the right,
// like a live stream. A viewer presses N to show or hide it; the first
// time, they pick a name, which gets a colour of its own. Enter starts a
// message, Enter sends it, Esc cancels. Everyone on the same channel who
// has movie night showing sees the same chat. Turned off for everyone
// with  movie_night = off  in tvserver.ini.

import (
	"bytes"
	"fmt"
	"math/rand"
	"strings"
	"sync"
	"time"
	"unicode"
	"unicode/utf8"
)

const (
	msgMovieNight = 0x19 // producer -> server: 0x19 | u8 1 = viewers may open movie night, 0 = not (its W key)
	msgChat       = 0x25 // server -> producer: 0x25 | u8 0 = a message, 1 = a notice | name | 0 | text
	capChat       = 0x10 // producer-hello caps bit: it shows the chat in its window

	chatKeep      = 200 // messages kept
	chatMaxLen    = 200 // characters a message
	chatNameLen   = 16
	chatMinGap    = 700 * time.Millisecond // between one viewer's messages
	chatToggleKey = 0x0E                   // the key reader's "N pressed" (Ctrl-N: nothing else sends it)
)

// chatColors are the name colours (bright, readable on black, in every
// terminal): SGR foreground codes.
var chatColors = []string{"1;31", "1;32", "1;33", "1;35", "1;36", "0;31", "0;32", "0;33", "0;35", "0;36", "1;34", "1;37"}

type chatMsg struct {
	seq    uint64
	name   string
	color  string // SGR code; "" = a notice (joined, left)
	text   string
	at     time.Time
	viewer *viewer // who sent it (nil for notices)
}

type chatMember struct {
	name, color string
	last        time.Time // their last message
}

// chatRoom is one channel's chat.
type chatRoom struct {
	mu      sync.Mutex
	seq     uint64
	msgs    []chatMsg
	members map[*viewer]*chatMember
	out     chan chatMsg // every message, for the camera PC's window (nil = nobody)
}

func newChatRoom() *chatRoom { return &chatRoom{members: map[*viewer]*chatMember{}} }

// movieNightAllowed reports whether the camera PC lets viewers open movie
// night (an older one never says: yes).
func (h *hub) movieNightAllowed(name string) bool {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	return !f.mnOff
}

// chatPayload is a CHAT message for the camera PC (framed).
func chatPayload(m chatMsg) []byte {
	kind := byte(0)
	if m.color == "" {
		kind = 1
	}
	p := append([]byte{msgChat, kind}, m.name...)
	p = append(append(p, 0), m.text...)
	n := len(p)
	return append([]byte{byte(n >> 24), byte(n >> 16), byte(n >> 8), byte(n)}, p...)
}

// chat is the channel's chat room.
func (h *hub) chat(name string) *chatRoom {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.chat == nil {
		f.chat = newChatRoom()
		// Every message also goes to the camera PC, in order, for its window.
		f.chat.out = make(chan chatMsg, 64)
		go func(out chan chatMsg) {
			for m := range out {
				f.mu.Lock()
				if f.producer != nil && f.chatOK {
					f.producer.SetWriteDeadline(time.Now().Add(2 * time.Second))
					f.producer.Write(chatPayload(m))
				}
				f.mu.Unlock()
			}
		}(f.chat.out)
	}
	return f.chat
}

// cleanChatText keeps printable characters only, squeezes spaces, and
// cuts it to n characters.
func cleanChatText(s string, n int) string {
	var b strings.Builder
	count := 0
	space := false
	for _, r := range s {
		if !unicode.IsPrint(r) || r == utf8.RuneError {
			r = ' '
		}
		if r == ' ' {
			if space || count == 0 {
				continue
			}
			space = true
		} else {
			space = false
		}
		if count == n {
			break
		}
		b.WriteRune(r)
		count++
	}
	return strings.TrimSpace(b.String())
}

// join adds v under name (made unique in the room), keeping color if
// given (else a random one). It returns the name and colour used.
func (r *chatRoom) join(v *viewer, name, color string) (string, string) {
	name = cleanChatText(name, chatNameLen)
	if name == "" {
		name = "guest"
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	if m := r.members[v]; m != nil {
		return m.name, m.color
	}
	taken := func(n string) bool {
		for _, m := range r.members {
			if strings.EqualFold(m.name, n) {
				return true
			}
		}
		return false
	}
	base := name
	for i := 2; taken(name); i++ {
		suffix := fmt.Sprint(i)
		name = string([]rune(base)[:min(utf8.RuneCountInString(base), chatNameLen-len(suffix))]) + suffix
	}
	valid := false
	for _, c := range chatColors {
		valid = valid || c == color
	}
	if !valid {
		color = chatColors[rand.Intn(len(chatColors))]
	}
	r.members[v] = &chatMember{name: name, color: color}
	r.addLocked(chatMsg{name: name, text: "joined movie night"})
	return name, color
}

// leave takes v out (a notice says so).
func (r *chatRoom) leave(v *viewer) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if m := r.members[v]; m != nil {
		delete(r.members, v)
		r.addLocked(chatMsg{name: m.name, text: "left"})
	}
}

// say posts v's message. It reports why not when it can't.
func (r *chatRoom) say(v *viewer, text string, now time.Time) error {
	text = cleanChatText(text, chatMaxLen)
	if text == "" {
		return nil
	}
	r.mu.Lock()
	defer r.mu.Unlock()
	m := r.members[v]
	if m == nil {
		return fmt.Errorf("pick a name first")
	}
	if now.Sub(m.last) < chatMinGap {
		return fmt.Errorf("slow down a little")
	}
	m.last = now
	r.addLocked(chatMsg{name: m.name, color: m.color, text: text, at: now, viewer: v})
	return nil
}

func (r *chatRoom) addLocked(m chatMsg) {
	r.seq++
	m.seq = r.seq
	if m.at.IsZero() {
		m.at = time.Now()
	}
	r.msgs = append(r.msgs, m)
	if r.out != nil {
		select {
		case r.out <- m:
		default: // the camera PC's copy is behind: skip it rather than wait
		}
	}
	if len(r.msgs) > chatKeep {
		r.msgs = append([]chatMsg(nil), r.msgs[len(r.msgs)-chatKeep:]...)
	}
}

// snapshot is the latest messages, the room's sequence number, and how
// many are in movie night.
func (r *chatRoom) snapshot() ([]chatMsg, uint64, int) {
	r.mu.Lock()
	defer r.mu.Unlock()
	return append([]chatMsg(nil), r.msgs...), r.seq, len(r.members)
}

// chatWidth is how many columns the chat takes on a screen cols wide (0 =
// too narrow for movie night).
func chatWidth(cols int) int {
	if cols < 60 {
		return 0
	}
	return max(24, min(40, cols*3/10))
}

// wrapRunes cuts s into lines at most w characters, at spaces when it can.
func wrapRunes(s string, w int) []string {
	if w < 1 {
		return nil
	}
	var out []string
	r := []rune(s)
	for len(r) > w {
		cut := w
		for i := w; i > w/2; i-- {
			if r[i] == ' ' {
				cut = i
				break
			}
		}
		out = append(out, string(r[:cut]))
		r = []rune(strings.TrimLeft(string(r[cut:]), " "))
	}
	return append(out, string(r))
}

// chatView is what one viewer's chat panel shows besides the messages.
type chatView struct {
	typing  bool   // writing a message (or their name)
	naming  bool   // the line being typed is their name
	line    []rune // what they've typed
	notice  string // a short note at the bottom ("slow down a little")
	members int
}

// drawChat draws the chat panel: columns left .. left+w-1 (1-based), rows
// top .. bottom.
func drawChat(buf *bytes.Buffer, msgs []chatMsg, cv chatView, left, w, top, bottom int, cp437 bool) {
	if w < 10 || bottom-top < 4 {
		return
	}
	put := func(row int, attr, text string) {
		t := clipRunes(text, w)
		t += strings.Repeat(" ", max(0, w-utf8.RuneCountInString(t)))
		fmt.Fprintf(buf, "\x1b[%d;%dH%s", row, left, attr)
		buf.Write(captionText(t, cp437))
	}
	head := fmt.Sprintf(" MOVIE NIGHT - %d here", cv.members)
	put(top, "\x1b[0;1;37;45m", head)
	// The bottom two rows: a hint line and the typing line.
	hint, input := " Enter: chat   N: hide", ""
	switch {
	case cv.typing && cv.naming:
		hint, input = " Pick a name, then Enter", " name: "+string(cv.line)+"_"
	case cv.typing:
		hint, input = " Enter send, Esc cancel", "> "+string(cv.line)+"_"
	}
	if cv.notice != "" {
		hint = " " + cv.notice
	}
	if cv.typing {
		// Show the end of a long line.
		if r := []rune(input); len(r) > w {
			input = string(r[len(r)-w:])
		}
	}
	put(bottom-1, "\x1b[0;36;40m", hint)
	put(bottom, "\x1b[0;1;37;44m", input)
	// Messages, newest at the bottom, wrapped to the panel.
	type line struct{ name, color, text string }
	var lines []line
	room := bottom - 2 - top
	for i := len(msgs) - 1; i >= 0 && len(lines) < room; i-- {
		m := msgs[i]
		var ls []line
		if m.color == "" { // a notice
			for _, t := range wrapRunes("* "+m.name+" "+m.text, w-1) {
				ls = append(ls, line{text: t})
			}
		} else {
			first := true
			for _, t := range wrapRunes(m.name+": "+m.text, w-1) {
				if first {
					ls = append(ls, line{name: m.name, color: m.color, text: strings.TrimPrefix(t, m.name)})
					first = false
				} else {
					ls = append(ls, line{text: t})
				}
			}
		}
		lines = append(ls, lines...)
	}
	if len(lines) > room {
		lines = lines[len(lines)-room:]
	}
	row := top + 1
	for ; row < top+1+room-len(lines); row++ {
		put(row, "\x1b[0;40m", "")
	}
	for _, l := range lines {
		fmt.Fprintf(buf, "\x1b[%d;%dH\x1b[0;40m ", row, left)
		used := 1
		if l.name != "" {
			fmt.Fprintf(buf, "\x1b[%sm", l.color)
			buf.Write(captionText(l.name, cp437))
			used += utf8.RuneCountInString(l.name)
		}
		if l.name == "" && strings.HasPrefix(l.text, "* ") {
			buf.WriteString("\x1b[0;2;37;40m")
		} else {
			buf.WriteString("\x1b[0;37;40m")
		}
		t := clipRunes(l.text, w-used)
		buf.Write(captionText(t, cp437))
		buf.WriteString(strings.Repeat(" ", max(0, w-used-utf8.RuneCountInString(t))))
		row++
	}
	buf.WriteString("\x1b[0m")
}
