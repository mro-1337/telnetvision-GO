package main

import (
	"encoding/binary"
	"testing"
	"time"
)

func TestPlaylistPayload(t *testing.T) {
	m := playlistPayload(1, []int{2}, []string{"A", "B\tside", "C"})[4:]
	if m[0] != msgPlaylist || binary.BigEndian.Uint32(m[1:5]) != 1 || binary.BigEndian.Uint16(m[5:7]) != 1 || binary.BigEndian.Uint32(m[7:11]) != 2 {
		t.Fatalf("header % x", m[:11])
	}
	if got := string(m[11:]); got != "A\nB side\nC" {
		t.Errorf("names %q", got)
	}
	live := playlistPayload(-1, nil, nil)[4:]
	if binary.BigEndian.Uint32(live[1:5]) != 0xFFFFFFFF || len(live) != 7 {
		t.Errorf("live % x", live)
	}
}

func TestUpNext(t *testing.T) {
	p := NewPlayer(&Config{}, "", nil, nil, time.Time{}, func(string, ...any) {})
	for _, n := range []string{"a.mp4", "b.mp4", "c.mp4", "d.mp4"} {
		p.items = append(p.items, entry{src: n, kind: entFile})
	}
	if !p.ToggleUpNext(3) || !p.ToggleUpNext(1) || !p.ToggleUpNext(2) || p.ToggleUpNext(1) {
		t.Fatal("tagging")
	}
	cur, up, names := p.PlaylistInfo()
	if cur != 0 || len(names) != 4 || len(up) != 2 || up[0] != 3 || up[1] != 2 {
		t.Fatalf("info %d %v %v", cur, up, names)
	}
	if !p.takeUpNext() || p.pos != 3 || !p.takeUpNext() || p.pos != 2 || p.takeUpNext() {
		t.Errorf("up next order: pos %d", p.pos)
	}

}

func TestViewerPlaylistOff(t *testing.T) {
	p := NewPlayer(&Config{ViewerPlaylist: false}, "", nil, nil, time.Time{}, func(string, ...any) {})
	p.items = []entry{{src: "a.mp4", kind: entFile}}
	s := NewSender(&Config{}, 0, t.Logf)
	handlePlaylistRequest([]byte{msgWantPlaylist}, p, s, t.Logf)
	handlePlaylistRequest([]byte{msgPlayItem, 0, 0, 0, 0, 0}, p, s, t.Logf)
	s.mu.Lock()
	defer s.mu.Unlock()
	if len(s.ctrl) != 2 {
		t.Fatalf("%d answers", len(s.ctrl))
	}
	for _, m := range s.ctrl {
		if m[4] != msgPlaylist || binary.BigEndian.Uint32(m[5:9]) != playlistOff {
			t.Errorf("answer % x, want 'turned off'", m)
		}
	}
	select {
	case c := <-p.cmds:
		t.Errorf("played something while off: %+v", c)
	default:
	}
	if !p.ToggleViewerPlaylist() || !p.ViewerPlaylist() {
		t.Error("O didn't turn it on")
	}
}

func TestPlaylistNamesOnlyWhenChanged(t *testing.T) {
	names := []string{"a.mp3", "b.mp3", "c.mp3"}
	if m := playlistAnswer(1, nil, names, true)[4:]; m[0] != msgPlaylist {
		t.Fatalf("asked for the names: % x", m)
	}
	m := playlistAnswer(2, []int{0}, names, false)[4:]
	if m[0] != msgPlaylistNow || binary.BigEndian.Uint32(m[1:5]) != 2 || binary.BigEndian.Uint16(m[5:7]) != 1 || len(m) != 11 {
		t.Fatalf("same names: % x", m)
	}
	if m := playlistAnswer(2, nil, append(names, "d.mp3"), false)[4:]; m[0] != msgPlaylist {
		t.Fatalf("names changed: % x", m[:1])
	}
}
