package main

import (
	"bytes"
	"regexp"
	"strings"
	"testing"
	"time"
)

func TestChatRoom(t *testing.T) {
	r := newChatRoom()
	a, b := newViewer(false), newViewer(false)
	na, ca := r.join(a, "  Bob\x07 ", "")
	nb, cb := r.join(b, "bob", "1;32")
	if na != "Bob" || nb != "bob2" || cb != "1;32" || ca == "" {
		t.Errorf("names %q %q colours %q %q", na, nb, ca, cb)
	}
	now := time.Now()
	if err := r.say(a, "hello\x1b[2J  world", now); err != nil {
		t.Fatal(err)
	}
	if err := r.say(a, "again", now.Add(100*time.Millisecond)); err == nil {
		t.Error("no limit on how fast")
	}
	if err := r.say(newViewer(false), "hi", now); err == nil {
		t.Error("someone who hasn't joined could talk")
	}
	r.leave(b)
	msgs, seq, n := r.snapshot()
	if n != 1 || seq != 4 || len(msgs) != 4 {
		t.Fatalf("%d members, seq %d, %d messages", n, seq, len(msgs))
	}
	if msgs[2].text != "hello [2J world" || msgs[2].color != ca {
		t.Errorf("message %+v", msgs[2])
	}
	if msgs[3].text != "left" || msgs[3].color != "" {
		t.Errorf("leaving: %+v", msgs[3])
	}
	for i := 0; i < chatKeep+50; i++ {
		r.mu.Lock()
		r.addLocked(chatMsg{name: "x", color: "1;31", text: "spam"})
		r.mu.Unlock()
	}
	if msgs, _, _ := r.snapshot(); len(msgs) != chatKeep {
		t.Errorf("kept %d", len(msgs))
	}
}

func TestDrawChat(t *testing.T) {
	msgs := []chatMsg{
		{name: "Ann", text: "joined the chat"},
		{name: "Ann", color: "1;35", text: "this movie is great, especially the part where the long sentence wraps around"},
		{name: "Bob", color: "1;32", text: "agreed"},
	}
	var b bytes.Buffer
	drawChat(&b, msgs, chatView{members: 2, typing: true, line: []rune("me too")}, 57, 24, 1, 23, false)
	s := b.String()
	if !strings.Contains(s, "\x1b[1;35mAnn") || !strings.Contains(s, "\x1b[1;32mBob") {
		t.Error("names aren't in their colours")
	}
	plain := regexp.MustCompile(`\x1b\[(\d+);(\d+)H`).ReplaceAllString(s, "\n")
	plain = regexp.MustCompile(`\x1b\[[0-9;]*m`).ReplaceAllString(plain, "")
	for _, want := range []string{"GROUP CHAT - 2 here", "* Ann joined the", "Ann: this movie is", "Bob: agreed", "> me too_", "Enter send"} {
		if !strings.Contains(plain, want) {
			t.Errorf("missing %q in\n%s", want, plain)
		}
	}
	for _, l := range strings.Split(plain, "\n") {
		if n := len([]rune(l)); n > 24 {
			t.Errorf("line wider than the panel (%d): %q", n, l)
		}
	}
	// Every row from 1 to 23 is drawn, all in columns 57-80.
	rows := regexp.MustCompile(`\x1b\[(\d+);57H`).FindAllStringSubmatch(s, -1)
	if len(rows) != 23 {
		t.Errorf("%d rows drawn, want 23", len(rows))
	}
}

func TestChatWidth(t *testing.T) {
	if chatWidth(50) != 0 || chatWidth(80) != 24 || chatWidth(132) != 39 || chatWidth(200) != 40 {
		t.Errorf("%d %d %d %d", chatWidth(50), chatWidth(80), chatWidth(132), chatWidth(200))
	}
}

func TestChatPayload(t *testing.T) {
	p := chatPayload(chatMsg{name: "Ann", color: "1;35", text: "hi"})
	if string(p) != "\x00\x00\x00\x08\x25\x00Ann\x00hi" {
		t.Errorf("% x", p)
	}
	if p := chatPayload(chatMsg{name: "Ann", text: "left"}); p[5] != 1 {
		t.Errorf("a notice: % x", p)
	}
}

func TestGroupChatSetting(t *testing.T) {
	for _, k := range []string{"movie_night", "group_chat"} {
		c := defaultServerConfig()
		if err := c.apply(map[string]string{k: "off"}); err != nil || c.View.movieNight {
			t.Errorf("%s = off: on %v, err %v", k, c.View.movieNight, err)
		}
	}
	out, _, _, _ := cleanINI([]byte("movie_night = off\n"), serverINITemplate(""), map[string]string{"movie_night": "group_chat"}, map[string]bool{"token": true}, "tvserver")
	if s := string(out); !strings.Contains(s, "group_chat = off") || strings.Contains(s, "movie_night") {
		t.Errorf("not renamed:\n%s", s)
	}
}
