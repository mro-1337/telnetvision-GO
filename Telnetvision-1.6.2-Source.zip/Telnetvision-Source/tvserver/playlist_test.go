package main

import (
	"bytes"
	"encoding/binary"
	"regexp"
	"strings"
	"testing"
)

func testPlaylistMsg(cur uint32, up []uint32, names ...string) []byte {
	p := []byte{msgPlaylist}
	p = binary.BigEndian.AppendUint32(p, cur)
	p = binary.BigEndian.AppendUint16(p, uint16(len(up)))
	for _, u := range up {
		p = binary.BigEndian.AppendUint32(p, u)
	}
	return append(p, strings.Join(names, "\n")...)
}

func TestParsePlaylist(t *testing.T) {
	pl, ok := parsePlaylist(testPlaylistMsg(1, []uint32{3, 0}, "Alien", "Blade Runner", "Brazil", "Dune"))
	if !ok || pl.cur != 1 || len(pl.names) != 4 || pl.names[3] != "Dune" || len(pl.upNext) != 2 || pl.upNext[0] != 3 {
		t.Fatalf("got %+v", pl)
	}
	live, ok := parsePlaylist(testPlaylistMsg(0xFFFFFFFF, nil))
	if !ok || live.cur != -1 || len(live.names) != 0 {
		t.Errorf("live: %+v", live)
	}
	if off, ok := parsePlaylist(testPlaylistMsg(0xFFFFFFFE, nil)); !ok || !off.off || len(off.names) != 0 {
		t.Errorf("turned off: %+v", off)
	}
	if _, ok := parsePlaylist([]byte{msgPlaylist, 0, 0}); ok {
		t.Error("short message accepted")
	}
}

func TestNavKeys(t *testing.T) {
	var kp keyParser
	got := ""
	for _, c := range []byte("\x1b[A\x1bOB\x1b[5~\x1b[6~\x1b[H\x1b[4~\x1b[90~") {
		if ev, code, _ := kp.feed(c); ev == keyNav {
			got += string(rune(code))
		}
	}
	if got != "UDPNHE!" {
		t.Errorf("got %q", got)
	}
}

func TestLightbar(t *testing.T) {
	var names []string
	for i := 1; i <= 40; i++ {
		names = append(names, "Movie number "+strings.Repeat("x", i%7))
	}
	names[5] = "Amélie (2001) - a very long title that goes on and on well past the edge of the box"
	pl := &playlistInfo{cur: 5, upNext: []int{7, 2}, names: names}
	var lv listView
	var b bytes.Buffer
	drawPlaylist(&b, pl, &lv, 80, 24, false)
	if lv.sel != 5 {
		t.Errorf("highlight starts on %d, want what's playing (5)", lv.sel)
	}
	plain := regexp.MustCompile(`\x1b\[[0-9;]*[A-Za-z]`).ReplaceAllString(b.String(), "\n")
	for _, want := range []string{"PLAYLIST - 40 item(s)", ">  6  Amélie", "[next 1]", "[next 2]", "2 tagged to play next", "Enter: play now"} {
		if !strings.Contains(plain, want) {
			t.Errorf("missing %q in\n%s", want, plain)
		}
	}
	for _, l := range strings.Split(plain, "\n") {
		if n := len([]rune(l)); n > 78 {
			t.Errorf("line too wide (%d): %q", n, l)
		}
	}
	// The highlight is the inverse bar.
	if !strings.Contains(b.String(), "\x1b[0;30;47m >  6") {
		t.Error("the highlighted line isn't the lightbar")
	}
	lv.move(navEnd, len(names), listRows(24))
	b.Reset()
	drawPlaylist(&b, pl, &lv, 80, 24, true)
	if lv.sel != 39 || lv.top != 40-listRows(24) {
		t.Errorf("End: sel %d top %d", lv.sel, lv.top)
	}
	lv.move(navPgUp, len(names), listRows(24))
	lv.move(navUp, len(names), listRows(24))
	if lv.sel != 39-listRows(24)-1 {
		t.Errorf("PgUp, Up: %d", lv.sel)
	}
	lv.move(navHome, len(names), listRows(24))
	lv.move(navUp, len(names), listRows(24))
	if lv.sel != 0 {
		t.Errorf("Up at the top: %d", lv.sel)
	}
}

// A refresh without the names keeps the names and takes what's playing.
func TestPlaylistNow(t *testing.T) {
	h := newHub()
	f := h.get("tv")
	f.playlist, _ = parsePlaylist(testPlaylistMsg(0, nil, "a", "b", "c"))
	now := testPlaylistMsg(2, []uint32{1})
	now[0] = msgPlaylistNow
	applyPlaylistNow(f, now)
	pl := h.playlist("tv")
	if pl == nil || pl.cur != 2 || len(pl.names) != 3 || len(pl.upNext) != 1 || pl.upNext[0] != 1 {
		t.Fatalf("got %+v", pl)
	}
}
