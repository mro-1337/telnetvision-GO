package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestBanLists(t *testing.T) {
	dir := t.TempDir()
	setupBans(dir)
	for _, f := range []string{ipBanFile, chatBanFile} {
		if b, err := os.ReadFile(filepath.Join(dir, f)); err != nil || !strings.HasPrefix(string(b), "# Telnetvision") {
			t.Fatalf("%s not made: %v", f, err)
		}
	}
	if ipBans.bannedIP("203.0.113.5:1234") {
		t.Error("banned with an empty list")
	}
	os.WriteFile(filepath.Join(dir, ipBanFile), []byte("\uFEFF# notes\r\n203.0.113.5  # him\r\n198.51.100.*\r\n10.1.0.0/16\r\nnonsense\r\n2001:db8::1\r\n"), 0o644)
	ipBans.lastCheck = time.Time{}
	for addr, want := range map[string]bool{
		"203.0.113.5:1": true, "203.0.113.6:1": false, "198.51.100.77:9": true, "198.51.101.1:9": false,
		"10.1.200.3:5": true, "10.2.0.1:5": false, "[2001:db8::1]:23": true, "[2001:db8::2]:23": false,
	} {
		if got := ipBans.bannedIP(addr); got != want {
			t.Errorf("%s banned %v, want %v", addr, got, want)
		}
	}
	// chatban.txt: addresses and names; the server window's commands.
	if err := chatBans.add("Bob"); err != nil {
		t.Fatal(err)
	}
	if err := chatBans.add("bob"); err == nil {
		t.Error("added twice")
	}
	chatBans.add("192.0.2.*")
	if !chatBans.bannedChat("1.1.1.1:2", "BOB") || !chatBans.bannedChat("192.0.2.9:2", "Ann") || chatBans.bannedChat("1.1.1.1:2", "Ann") {
		t.Error("chat bans wrong")
	}
	if n, _ := chatBans.remove("bob"); n != 1 || chatBans.bannedChat("1.1.1.1:2", "Bob") {
		t.Errorf("unchatban: %d", n)
	}
	if err := ipBans.add("Bob"); err == nil {
		t.Error("a name in ipban.txt")
	}
}

func TestChatRename(t *testing.T) {
	r := newChatRoom()
	a, b := &viewer{}, &viewer{}
	r.join(a, "Ann", "")
	r.join(b, "Bob", "")
	if _, err := r.rename(a, "bob"); err == nil {
		t.Error("took someone else's name")
	}
	if n, err := r.rename(a, "  Annie  "); err != nil || n != "Annie" {
		t.Errorf("rename: %q %v", n, err)
	}
	msgs, _, _ := r.snapshot()
	if last := msgs[len(msgs)-1]; last.name != "Ann" || last.text != "is now called Annie" {
		t.Errorf("notice %+v", last)
	}
	if _, err := r.rename(&viewer{}, "X"); err == nil {
		t.Error("renamed someone not in the chat")
	}
}
