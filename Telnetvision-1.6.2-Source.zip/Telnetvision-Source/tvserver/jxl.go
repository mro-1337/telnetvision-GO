package main

// JPEG XL output for terminals that can draw JXL pictures: SyncTERM 1.10
// (and terminals that copy its commands), and the web page (tvaudio.js).
// The camera PC encodes each frame once (FRAME_JXL); here it's wrapped in SyncTERM's command
//
//	ESC _ SyncTERM:C;DrawJXLBlob;DX=x;DY=y;ZX=z;ZY=z;<base64 picture> ESC \
//
// which draws it at pixel (x, y), zoomed z times. A terminal is asked
// first with  ESC _ SyncTERM:Q;JXL ESC \ ; SyncTERM answers ESC [ = 1 ; 1 - n
// when it can (1;0 when it can't). Behind the question goes a status
// request (ESC [ 5 n, answered ESC [ 0 n), so a terminal that doesn't
// know the question is spotted at once instead of waiting it out.

import (
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"fmt"
	"regexp"
	"time"

	"github.com/hmderdoc/termprobe"
)

const jxlQuery = "\x1b_SyncTERM:Q;JXL\x1b\\" + "\x1b[5n"

var (
	reJXLAnswer = regexp.MustCompile(`\x1b\[=1;([01])-n`)
	reDSR       = regexp.MustCompile(`\x1b\[[03]n`)
)

// jxlProbe asks whether the terminal can show JPEG XL. It returns the
// answer and the bytes that weren't answers (keys typed meanwhile).
func jxlProbe(w interface{ Write([]byte) (int, error) }, r termprobe.TimedReader, timeout time.Duration) (bool, []byte) {
	if _, err := w.Write([]byte(jxlQuery)); err != nil {
		return false, nil
	}
	var buf []byte
	scratch := make([]byte, 256)
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) && len(buf) < 4096 {
		rem := time.Until(deadline)
		if rem > 50*time.Millisecond {
			rem = 50 * time.Millisecond
		}
		n, err := r.ReadTimeout(scratch, rem)
		buf = append(buf, scratch[:n]...)
		if err != nil {
			break
		}
		// Answers come in order: once the status answer is in, the JXL
		// answer (if any) came before it.
		if reJXLAnswer.Match(buf) || reDSR.Match(buf) {
			break
		}
	}
	ok := false
	if m := reJXLAnswer.FindSubmatch(buf); m != nil {
		ok = m[1][0] == '1'
	}
	rest := reJXLAnswer.ReplaceAll(buf, nil)
	rest = reDSR.ReplaceAll(rest, nil)
	return ok, rest
}

// jxlFresh reports whether a FRAME_JXL payload belongs with the frame
// being drawn (stamped within a second and a half of it).
func jxlFresh(p []byte, framePTS int64) bool {
	if len(p) < 14 || p[0] != msgFrameJXL {
		return false
	}
	pts := int64(binary.BigEndian.Uint64(p[5:13]))
	d := pts - framePTS
	return framePTS < 0 || (d > -1500 && d < 1500)
}

// renderJXL draws a FRAME_JXL picture centred in the picture's region,
// zoomed by the largest whole number that fits. It reports false when
// the picture doesn't fit at all (the caller draws characters instead).
func renderJXL(buf *bytes.Buffer, p []byte, fitCols, fitRows, ox, oy, cellW, cellH int) bool {
	w := int(binary.BigEndian.Uint16(p[1:3]))
	h := int(binary.BigEndian.Uint16(p[3:5]))
	if w <= 0 || h <= 0 {
		return false
	}
	tw, th := fitCols*cellW, fitRows*cellH
	z := min(tw/w, th/h)
	if z < 1 {
		return false
	}
	dx := ox*cellW + (tw-w*z)/2
	dy := oy*cellH + (th-h*z)/2
	fmt.Fprintf(buf, "\x1b_SyncTERM:C;DrawJXLBlob;DX=%d;DY=%d;ZX=%d;ZY=%d;", dx, dy, z, z)
	enc := base64.NewEncoder(base64.StdEncoding, buf)
	enc.Write(p[13:])
	enc.Close()
	buf.WriteString("\x1b\\")
	return true
}

// jxlCapsText says what JPEG XL a camera PC's hello offers, for the log.
func jxlCapsText(caps byte) string {
	switch {
	case caps&capJXL == 0:
		return "no"
	case caps&capJXLLevels == 0:
		return "High detail only"
	}
	return "High, Medium and Low detail"
}
