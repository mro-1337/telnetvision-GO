package main

// The playlist for viewers: a viewer who is the only one watching presses
// L to see the camera PC's playlist as a lightbar list (no typing: arrow
// keys move, Enter plays the highlighted one now, Space tags it to play
// next). The camera PC sends the list when asked (WANT_PLAYLIST ->
// PLAYLIST) and takes the choice (PLAY_ITEM).

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"strings"
	"time"
	"unicode/utf8"
)

const (
	msgPlaylist     = 0x17 // producer -> server: 0x17 | u32 playing (0xFFFFFFFF none) | u16 n | n x u32 up next | names, one per line
	msgPlaylistNow  = 0x18 // producer -> server: PLAYLIST without the names (unchanged since last sent)
	msgWantPlaylist = 0x23 // server -> producer: 0x23 | u8 1 = send PLAYLIST with the names, 0 = only if they changed
	msgPlayItem     = 0x24 // server -> producer: 0x24 | u8 0 = play now, 1 = tag/untag up next | u32 index
	capPlaylist     = 0x08 // producer-hello caps bit: it shares its playlist
)

type playlistInfo struct {
	off    bool  // the camera PC has the viewers' playlist turned off
	cur    int   // what's playing (-1 = none)
	upNext []int // tagged to play next, in order
	names  []string
	at     time.Time
}

// parsePlaylist reads a PLAYLIST message. An empty list means the camera
// PC is showing something live.
func parsePlaylist(p []byte) (*playlistInfo, bool) {
	if len(p) < 7 || p[0] != msgPlaylist {
		return nil, false
	}
	pl := &playlistInfo{cur: -1, at: time.Now()}
	switch c := binary.BigEndian.Uint32(p[1:5]); c {
	case 0xFFFFFFFF:
	case 0xFFFFFFFE:
		pl.off = true // turned off on the camera PC (its O key, VIEWER_PLAYLIST=0)
	default:
		pl.cur = int(c)
	}
	n := int(binary.BigEndian.Uint16(p[5:7]))
	rest := p[7:]
	if len(rest) < 4*n {
		return nil, false
	}
	for i := 0; i < n; i++ {
		pl.upNext = append(pl.upNext, int(binary.BigEndian.Uint32(rest[4*i:])))
	}
	rest = rest[4*n:]
	if len(rest) > 0 {
		pl.names = strings.Split(string(rest), "\n")
	}
	if pl.cur >= len(pl.names) {
		pl.cur = -1
	}
	return pl, true
}

// requestPlaylist asks the channel's camera PC for its playlist: with all
// the names (full: the list is just opening), or only what's playing and
// up next unless the names changed (refreshing an open list - a big list
// sent every few seconds would hold up the sound). False if it can't share
// one (none connected, or an older version).
func (h *hub) requestPlaylist(name string, full bool) bool {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.producer == nil || !f.playlistOK {
		return false
	}
	f.producer.SetWriteDeadline(time.Now().Add(2 * time.Second))
	want := byte(0)
	if full {
		want = 1
	}
	f.producer.Write([]byte{0, 0, 0, 2, msgWantPlaylist, want})
	return true
}

// playlist is the channel's last known playlist (nil if none yet).
func (h *hub) playlist(name string) *playlistInfo {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.playlist
}

// playItem tells the camera PC to play entry i now (upNext false) or to
// tag / untag it to play next.
func (h *hub) playItem(name string, i int, upNext bool) {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	if f.producer == nil || !f.playlistOK {
		return
	}
	mode := byte(0)
	if upNext {
		mode = 1
	}
	b := []byte{0, 0, 0, 6, msgPlayItem, mode}
	b = binary.BigEndian.AppendUint32(b, uint32(i))
	f.producer.SetWriteDeadline(time.Now().Add(2 * time.Second))
	f.producer.Write(b)
}

// watching is how many viewers the channel has now.
func (h *hub) watching(name string) int {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	return len(f.viewers)
}

// listView is one viewer's open playlist: which entry is highlighted and
// which one is at the top of the box.
type listView struct {
	sel, top int
	moved    bool // they've moved the highlight (else it follows what's playing)
}

// Lightbar keys, as the key reader passes them on.
const (
	navUp     = 'U'
	navDown   = 'D'
	navPgUp   = 'P'
	navPgDn   = 'N'
	navHome   = 'H'
	navEnd    = 'E'
	navPlay   = '!' // Enter: play the highlighted entry now
	navTag    = '^' // Space: tag / untag it to play next
	navClose  = 'x'
	navOpen   = 'L'
	listWidth = 70
)

// move applies a lightbar key to the highlight; rows is how many entries
// the box shows.
func (lv *listView) move(k byte, n, rows int) {
	if n == 0 {
		return
	}
	switch k {
	case navUp:
		lv.sel--
	case navDown:
		lv.sel++
	case navPgUp:
		lv.sel -= rows
	case navPgDn:
		lv.sel += rows
	case navHome:
		lv.sel = 0
	case navEnd:
		lv.sel = n - 1
	default:
		return
	}
	lv.moved = true
	lv.sel = max(0, min(n-1, lv.sel))
}

// listRows is how many entries fit in the box on a screen rows high.
func listRows(rows int) int { return max(3, min(rows-6, 18)) }

// drawPlaylist draws the lightbar box over the picture.
func drawPlaylist(buf *bytes.Buffer, pl *playlistInfo, lv *listView, cols, rows int, cp437 bool) {
	n := len(pl.names)
	vis := listRows(rows)
	if !lv.moved && pl.cur >= 0 {
		lv.sel = pl.cur // start on what's playing
	}
	lv.sel = max(0, min(n-1, lv.sel))
	if lv.sel < lv.top {
		lv.top = lv.sel
	}
	if lv.sel >= lv.top+vis {
		lv.top = lv.sel - vis + 1
	}
	lv.top = max(0, min(lv.top, n-vis))
	w := min(listWidth, cols-2)
	tags := map[int]int{}
	for k, i := range pl.upNext {
		tags[i] = k + 1
	}
	lines := []struct {
		text, attr string
	}{
		{fmt.Sprintf(" PLAYLIST - %d item(s)", n), "\x1b[0;1;33;44m"},
		{" Arrows move   Enter: play now   Space: tag for up next   Esc: close", "\x1b[0;36;44m"},
	}
	numW := len(fmt.Sprint(n))
	for i := lv.top; i < min(n, lv.top+vis); i++ {
		mark := "  "
		if i == pl.cur {
			mark = "> "
		}
		tag := ""
		if t, ok := tags[i]; ok {
			tag = fmt.Sprintf(" [next %d]", t)
		}
		name := pl.names[i]
		room := w - 2 - numW - 2 - len(tag) - 1
		name = clipRunes(name, room)
		text := fmt.Sprintf(" %s%*d  %s", mark, numW, i+1, name)
		text += strings.Repeat(" ", max(0, w-utf8.RuneCountInString(text)-len(tag))) + tag
		attr := "\x1b[0;37;44m"
		switch {
		case i == lv.sel:
			attr = "\x1b[0;30;47m" // the lightbar
		case i == pl.cur:
			attr = "\x1b[0;1;37;44m"
		case tag != "":
			attr = "\x1b[0;1;32;44m"
		}
		lines = append(lines, struct{ text, attr string }{text, attr})
	}
	more := ""
	if n > vis {
		more = fmt.Sprintf(" %d-%d of %d", lv.top+1, min(n, lv.top+vis), n)
	}
	if len(pl.upNext) > 0 {
		more += fmt.Sprintf("   %d tagged to play next", len(pl.upNext))
	}
	lines = append(lines, struct{ text, attr string }{more, "\x1b[0;36;44m"})
	top := max(1, (rows-len(lines))/2+1)
	left := max(1, (cols-w)/2+1)
	for i, l := range lines {
		if top+i > rows {
			break
		}
		t := clipRunes(l.text, w)
		t += strings.Repeat(" ", max(0, w-utf8.RuneCountInString(t)))
		fmt.Fprintf(buf, "\x1b[%d;%dH%s", top+i, left, l.attr)
		buf.Write(captionText(t, cp437))
	}
	buf.WriteString("\x1b[0m")
}

// clipRunes cuts s to at most n characters (with "..." when cut).
func clipRunes(s string, n int) string {
	if n <= 0 {
		return ""
	}
	r := []rune(s)
	if len(r) <= n {
		return s
	}
	if n <= 3 {
		return string(r[:n])
	}
	return string(r[:n-3]) + "..."
}
