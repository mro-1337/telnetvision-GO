package main

import (
	"bytes"
	"encoding/base64"
	"encoding/binary"
	"io"
	"net"
	"strings"
	"testing"
	"time"

	"github.com/hmderdoc/termprobe"
)

type recWriter struct{ bytes.Buffer }

func jxlProbeWith(answer string) (bool, []byte, string) {
	ch := make(chan []byte, 4)
	if answer != "" {
		ch <- []byte(answer)
	}
	w := &recWriter{}
	ok, rest := jxlProbe(w, termprobe.ChanReader(ch), 300*time.Millisecond)
	return ok, rest, w.String()
}

func TestJXLProbe(t *testing.T) {
	ok, rest, sent := jxlProbeWith("\x1b[=1;1-n\x1b[0n")
	if !ok || len(rest) != 0 || sent != jxlQuery {
		t.Fatalf("SyncTERM yes: %v %q %q", ok, rest, sent)
	}
	if ok, _, _ := jxlProbeWith("\x1b[=1;0-n\x1b[0n"); ok {
		t.Fatal("SyncTERM without JXL said no")
	}
	// A terminal that doesn't know the question only answers the status
	// request; keys typed meanwhile come back.
	start := time.Now()
	ok, rest, _ = jxlProbeWith("q\x1b[0n")
	if ok || string(rest) != "q" || time.Since(start) > 200*time.Millisecond {
		t.Fatalf("no JXL: %v %q after %s", ok, rest, time.Since(start))
	}
	if ok, _, _ := jxlProbeWith(""); ok { // silent terminal: times out, no
		t.Fatal("silence is not a yes")
	}
}

func jxlMsg(w, h int, pts int64, data []byte) []byte {
	p := []byte{msgFrameJXL}
	p = binary.BigEndian.AppendUint16(p, uint16(w))
	p = binary.BigEndian.AppendUint16(p, uint16(h))
	p = binary.BigEndian.AppendUint64(p, uint64(pts))
	return append(p, data...)
}

func TestRenderJXL(t *testing.T) {
	data := []byte{0xff, 0x0a, 1, 2, 3, 4, 5}
	var b bytes.Buffer
	// 80x24 cells of 8x16 = 640x384 pixels; a 320x192 picture fits twice.
	if !renderJXL(&b, jxlMsg(320, 192, 1000, data), 80, 24, 0, 0, 8, 16) {
		t.Fatal("should draw")
	}
	want := "\x1b_SyncTERM:C;DrawJXLBlob;DX=0;DY=0;ZX=2;ZY=2;" + base64.StdEncoding.EncodeToString(data) + "\x1b\\"
	if b.String() != want {
		t.Fatalf("got %q", b.String())
	}
	// Centred in a region that's off to the side.
	b.Reset()
	renderJXL(&b, jxlMsg(320, 192, 1000, data), 60, 24, 10, 1, 8, 16)
	if !strings.HasPrefix(b.String(), "\x1b_SyncTERM:C;DrawJXLBlob;DX=160;DY=112;ZX=1;ZY=1;") {
		t.Fatalf("got %q", b.String()[:60])
	}
	if renderJXL(&b, jxlMsg(320, 192, 0, data), 20, 5, 0, 0, 8, 16) {
		t.Fatal("too big for the space: characters instead")
	}
	if !jxlFresh(jxlMsg(4, 4, 5000, data), 4000) || jxlFresh(jxlMsg(4, 4, 9000, data), 4000) || !jxlFresh(jxlMsg(4, 4, 1, data), -1) {
		t.Fatal("freshness")
	}
}

func TestHubWantJXL(t *testing.T) {
	h := newHub()
	srv, cam := net.Pipe()
	defer srv.Close()
	defer cam.Close()
	f := h.get("tv")
	f.mu.Lock()
	f.producer, f.jxlOK = srv, true
	f.mu.Unlock()
	v := newViewer(false)
	h.subscribe("tv", v)
	got := make(chan []byte, 4)
	go func() {
		for {
			b := make([]byte, 6)
			if _, err := cam.Read(b); err != nil {
				return
			}
			got <- b
		}
	}()
	h.setWantJXL("tv", v, 0)
	if b := <-got; b[4] != msgWantJXL || b[5] != 1 {
		t.Fatalf("WANT_JXL on: %v", b)
	}
	if !h.jxlAvailable("tv") {
		t.Fatal("camera PC can make JXL")
	}
	h.unsubscribe("tv", v)
	if b := <-got; b[4] != msgWantJXL || b[5] != 0 {
		t.Fatalf("WANT_JXL off when the last JXL viewer leaves: %v", b)
	}
	// A camera PC that can't make JXL is never asked.
	f.mu.Lock()
	f.jxlOK, f.jxlAsked = false, 0
	f.mu.Unlock()
	v2 := newViewer(false)
	h.subscribe("tv", v2)
	h.setWantJXL("tv", v2, 0)
	select {
	case b := <-got:
		t.Fatalf("asked a camera PC that can't: %v", b)
	case <-time.After(100 * time.Millisecond):
	}
}

func TestJXLMenuChoice(t *testing.T) {
	v := viewerSettings{color: colorTrue, sixelOK: true, jxlOK: true, jxlCam: true}
	seen := map[string]bool{}
	for i := 0; i < 5; i++ {
		v.change('1')
		seen[v.color] = true
	}
	if !seen[colorJXL] || !seen[colorSixel] {
		t.Fatalf("choices %v", seen)
	}
	v2 := viewerSettings{color: colorTrue, sixelOK: true}
	for i := 0; i < 5; i++ {
		if v2.change('1'); v2.color == colorJXL {
			t.Fatal("JXL offered to a terminal that can't show it")
		}
	}
	v.color = colorJXL
	v.jxlCam = false
	if !strings.Contains(v.colorLabel(), "can't") {
		t.Fatal(v.colorLabel())
	}
	v3 := viewerSettings{color: colorTrue}
	v3.restore(savedSettings{Color: colorJXL})
	if v3.color != colorTrue {
		t.Fatal("a saved JXL choice needs a terminal that can show it")
	}
}

// Detail levels: the camera PC is asked for the levels in use, and each
// viewer gets its own level's pictures; a 1.3.0 camera PC (High only)
// serves everyone with High.
func TestHubJXLLevels(t *testing.T) {
	h := newHub()
	srv, cam := net.Pipe()
	defer srv.Close()
	defer cam.Close()
	f := h.get("tv")
	f.mu.Lock()
	f.producer, f.jxlOK, f.jxlLevels = srv, true, true
	f.mu.Unlock()
	got := make(chan byte, 8)
	go func() {
		for {
			b := make([]byte, 6)
			if _, err := io.ReadFull(cam, b); err != nil {
				return
			}
			got <- b[5]
		}
	}()
	a, b := newViewer(false), newViewer(false)
	h.subscribe("tv", a)
	h.subscribe("tv", b)
	h.setWantJXL("tv", a, 0)
	if m := <-got; m != 1 {
		t.Fatalf("asked for %b, want High", m)
	}
	h.setWantJXL("tv", b, 2)
	if m := <-got; m != 5 {
		t.Fatalf("asked for %b, want High and Low", m)
	}
	h.setWantJXL("tv", a, 1)
	if m := <-got; m != 6 {
		t.Fatalf("asked for %b, want Medium and Low", m)
	}
	// Pictures go to the viewers of their level.
	low := append([]byte{msgFrameJXLLevel, 2, 0, 160, 0, 96, 0, 0, 0, 0, 0, 0, 0, 1}, 0xff, 0x0a)
	f.mu.Lock()
	f.jxlLevels = true
	f.mu.Unlock()
	deliverJXL(f, low)
	if p := b.latestJXL(); p == nil || p[0] != msgFrameJXL || binary.BigEndian.Uint16(p[1:3]) != 160 || p[13] != 0xff {
		t.Fatalf("Low viewer got %v", p)
	}
	if p := a.latestJXL(); p != nil {
		t.Fatalf("Medium viewer got a Low picture %v", p)
	}
	// High only: everyone asks for (and gets) High.
	f.mu.Lock()
	f.jxlLevels, f.jxlAsked = false, 0
	f.updateWantJXLLocked()
	f.mu.Unlock()
	if m := <-got; m != 1 {
		t.Fatalf("High-only camera PC asked for %b", m)
	}
	hi := append([]byte{msgFrameJXL, 1, 64, 0, 192, 0, 0, 0, 0, 0, 0, 0, 2}, 0xff, 0x0a)
	deliverJXL(f, hi)
	if p := a.latestJXL(); p == nil || p[2] != 64 {
		t.Fatalf("Medium viewer didn't get High from a High-only camera PC: %v", p)
	}
}

func TestDetailMenu(t *testing.T) {
	v := viewerSettings{color: colorJXL, jxlOK: true, jxlCam: true, jxlLevels: true, jxlDetail: sixelHigh, detail: sixelMedium, autoDetail: true}
	if !v.canLower() || v.effJXL() != sixelHigh {
		t.Fatal("High can be lowered")
	}
	v.autoDrop = 2
	if v.effJXL() != sixelLow || v.canLower() {
		t.Fatalf("two steps down from High: %s", v.effJXL())
	}
	var buf bytes.Buffer
	drawMenu(&buf, &v, "1.00 Mbit/s", 80, 25, true)
	if !bytes.Contains(buf.Bytes(), []byte("Low (lowered: connection is slow)")) {
		t.Errorf("menu doesn't say it was lowered:\n%q", buf.String())
	}
	v.change('7') // their own choice: Medium, no automatic step
	if v.jxlDetail != sixelMedium || v.autoDrop != 0 || v.effJXL() != sixelMedium {
		t.Errorf("after 7: %s, dropped %d", v.jxlDetail, v.autoDrop)
	}
	v.change('8')
	if v.autoDetail {
		t.Error("8 didn't turn it off")
	}
	s := v.saved()
	w := viewerSettings{jxlOK: true, autoDetail: true, jxlDetail: sixelHigh}
	w.restore(s)
	if w.autoDetail || w.jxlDetail != sixelMedium {
		t.Errorf("restored %+v", w)
	}
	v.color = colorTrue
	if v.change('7') {
		t.Error("7 changed something in 24-bit")
	}
}
