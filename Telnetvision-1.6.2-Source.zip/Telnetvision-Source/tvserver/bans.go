package main

// Ban lists: two plain text files next to tvserver.ini.
//
//	ipban.txt    addresses that can't watch at all (telnet or web)
//	chatban.txt  addresses or chat names that can watch but not chat
//
// One entry a line; # starts a note. An address can be exact
// (203.0.113.5), have * for any number (203.0.113.*), or be a range
// (203.0.113.0/24). In chatban.txt, anything that isn't an address is a
// chat name (any capitals). The files are read again whenever they
// change, so editing them in Notepad works while tvserver runs; the
// server window's ban / chatban commands add to them too.

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

const (
	ipBanFile   = "ipban.txt"
	chatBanFile = "chatban.txt"
)

var ipBanHeader = `# Telnetvision server: addresses that can't watch (telnet or the web page).
# One a line. 203.0.113.5 = that address, 203.0.113.* = any number in
# place of the *, 203.0.113.0/24 = a range. # starts a note, e.g.
#   198.51.100.7   # kept reconnecting
# tvserver reads this again when it changes: no restart needed. In the
# server window,  ban 198.51.100.7  adds a line and  unban  takes it out.
# Callers through a BBS (door.exe) all come from the BBS's own address:
# ban those on the BBS instead.
`

var chatBanHeader = `# Telnetvision server: who can watch but not chat in the group chat.
# One a line: an address (203.0.113.5, 203.0.113.*, 203.0.113.0/24) or a
# chat name (any capitals). # starts a note, e.g.
#   198.51.100.7   # spam
#   Bob
# tvserver reads this again when it changes: no restart needed. In the
# server window,  chatban Bob  adds a line and  unchatban Bob  takes it out.
# A name can be changed with /name, so an address is the surer ban.
`

// banEntry is one line of a ban file.
type banEntry struct {
	raw  string
	ip   net.IP     // exact address
	nw   *net.IPNet // a range
	wild []string   // 4 parts, "*" = any (IPv4)
	name string     // lower case (chatban.txt only)
}

// parseBanEntry reads one entry; allowName: a non-address is a name.
func parseBanEntry(s string, allowName bool) (banEntry, bool) {
	e := banEntry{raw: s}
	if ip := net.ParseIP(s); ip != nil {
		e.ip = ip
		return e, true
	}
	if _, nw, err := net.ParseCIDR(s); err == nil {
		e.nw = nw
		return e, true
	}
	if p := strings.Split(s, "."); len(p) == 4 && strings.Contains(s, "*") {
		ok := true
		for _, x := range p {
			if x == "*" {
				continue
			}
			n := 0
			if _, err := fmt.Sscanf(x, "%d", &n); err != nil || n < 0 || n > 255 || fmt.Sprint(n) != x {
				ok = false
			}
		}
		if ok {
			e.wild = p
			return e, true
		}
	}
	if allowName {
		if n := cleanChatText(s, chatNameLen); n != "" {
			e.name = strings.ToLower(n)
			return e, true
		}
	}
	return e, false
}

func (e banEntry) matchIP(ip net.IP) bool {
	switch {
	case ip == nil:
		return false
	case e.ip != nil:
		return e.ip.Equal(ip)
	case e.nw != nil:
		return e.nw.Contains(ip)
	case e.wild != nil:
		v4 := ip.To4()
		if v4 == nil {
			return false
		}
		for i, x := range e.wild {
			if x != "*" && x != fmt.Sprint(v4[i]) {
				return false
			}
		}
		return true
	}
	return false
}

// banList is one ban file, read again when it changes.
type banList struct {
	mu        sync.Mutex
	path      string
	names     bool // entries may be chat names
	header    string
	entries   []banEntry
	modTime   time.Time
	size      int64
	lastCheck time.Time
}

var (
	ipBans   = &banList{header: ipBanHeader}
	chatBans = &banList{header: chatBanHeader, names: true}
)

// setupBans points the lists at dir, making the files (just their notes)
// if they aren't there.
func setupBans(dir string) {
	for _, b := range []*banList{ipBans, chatBans} {
		name := ipBanFile
		if b.names {
			name = chatBanFile
		}
		b.mu.Lock()
		b.path = filepath.Join(dir, name)
		b.lastCheck = time.Time{}
		if _, err := os.Stat(b.path); os.IsNotExist(err) {
			os.WriteFile(b.path, []byte(strings.ReplaceAll(b.header, "\n", "\r\n")), 0o644)
		}
		b.mu.Unlock()
		n := len(b.list())
		if n > 0 {
			log.Printf("%s: %d ban(s)", name, n)
		}
	}
}

// refreshLocked reads the file again if it changed (at most every 2 s).
func (b *banList) refreshLocked() {
	if b.path == "" || time.Since(b.lastCheck) < 2*time.Second {
		return
	}
	b.lastCheck = time.Now()
	fi, err := os.Stat(b.path)
	if err != nil {
		b.entries, b.modTime, b.size = nil, time.Time{}, 0
		return
	}
	if fi.ModTime().Equal(b.modTime) && fi.Size() == b.size {
		return
	}
	f, err := os.Open(b.path)
	if err != nil {
		return
	}
	defer f.Close()
	var es []banEntry
	sc := bufio.NewScanner(f)
	line := 0
	for sc.Scan() {
		line++
		s := sc.Text()
		if i := strings.Index(s, "#"); i >= 0 {
			s = s[:i]
		}
		s = strings.TrimSpace(strings.TrimPrefix(s, "\uFEFF"))
		if s == "" {
			continue
		}
		if e, ok := parseBanEntry(s, b.names); ok {
			es = append(es, e)
		} else {
			log.Printf("%s line %d: %q isn't an address (203.0.113.5, 203.0.113.* or 203.0.113.0/24): skipped", filepath.Base(b.path), line, s)
		}
	}
	if !b.modTime.IsZero() {
		log.Printf("%s changed: %d ban(s) now", filepath.Base(b.path), len(es))
	}
	b.entries, b.modTime, b.size = es, fi.ModTime(), fi.Size()
}

func (b *banList) list() []banEntry {
	b.mu.Lock()
	defer b.mu.Unlock()
	b.refreshLocked()
	return b.entries
}

// hostIP is the address part of "host:port".
func hostIP(addr string) net.IP {
	host, _, err := net.SplitHostPort(addr)
	if err != nil {
		host = addr
	}
	return net.ParseIP(strings.Trim(host, "[]"))
}

// bannedIP reports whether addr ("host:port") is on the list.
func (b *banList) bannedIP(addr string) bool {
	ip := hostIP(addr)
	for _, e := range b.list() {
		if e.matchIP(ip) {
			return true
		}
	}
	return false
}

// bannedChat reports whether someone at addr called name can't chat.
func (b *banList) bannedChat(addr, name string) bool {
	ip := hostIP(addr)
	name = strings.ToLower(cleanChatText(name, chatNameLen))
	for _, e := range b.list() {
		if e.matchIP(ip) || (e.name != "" && e.name == name) {
			return true
		}
	}
	return false
}

// add appends entry to the file (the server window's ban commands).
func (b *banList) add(entry string) error {
	entry = strings.TrimSpace(entry)
	e, ok := parseBanEntry(entry, b.names)
	if !ok {
		if b.names {
			return fmt.Errorf("%q isn't an address or a name", entry)
		}
		return fmt.Errorf("%q isn't an address (203.0.113.5, 203.0.113.* or 203.0.113.0/24)", entry)
	}
	for _, x := range b.list() {
		if strings.EqualFold(x.raw, e.raw) {
			return fmt.Errorf("%s is already on the list", entry)
		}
	}
	b.mu.Lock()
	defer b.mu.Unlock()
	old, _ := os.ReadFile(b.path)
	if len(old) == 0 {
		old = []byte(strings.ReplaceAll(b.header, "\n", "\r\n"))
	}
	if len(old) > 0 && old[len(old)-1] != '\n' {
		old = append(old, '\r', '\n')
	}
	line := fmt.Sprintf("%s   # added %s\r\n", entry, time.Now().Format("2006-01-02 15:04"))
	if err := os.WriteFile(b.path, append(old, line...), 0o644); err != nil {
		return err
	}
	b.lastCheck, b.modTime = time.Time{}, time.Time{}
	return nil
}

// remove takes entry's lines out of the file. It reports how many.
func (b *banList) remove(entry string) (int, error) {
	entry = strings.TrimSpace(entry)
	b.mu.Lock()
	defer b.mu.Unlock()
	old, err := os.ReadFile(b.path)
	if err != nil {
		return 0, err
	}
	lines := strings.SplitAfter(string(old), "\n")
	var out strings.Builder
	n := 0
	for _, l := range lines {
		s := l
		if i := strings.Index(s, "#"); i >= 0 {
			s = s[:i]
		}
		if s = strings.TrimSpace(s); s != "" && strings.EqualFold(s, entry) {
			n++
			continue
		}
		out.WriteString(l)
	}
	if n == 0 {
		return 0, nil
	}
	if err := os.WriteFile(b.path, []byte(out.String()), 0o644); err != nil {
		return 0, err
	}
	b.lastCheck, b.modTime = time.Time{}, time.Time{}
	return n, nil
}
