package main

// In-process version of the upstream relay (service/main.go): one producer
// per channel publishes, many viewers subscribe, and each viewer keeps only
// the newest frame (drop-to-latest) so a slow caller never builds lag.
//
// Producers connect with the same wire protocol as before, so
// telnetvision.exe (and the original producer.py) work unchanged.

import (
	"crypto/subtle"
	"encoding/binary"
	"fmt"
	"io"
	"log"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

const msgHelloProducer = 0x01

// hubReadMsg returns one length-prefixed payload.
func hubReadMsg(r io.Reader) ([]byte, error) {
	var lb [4]byte
	if _, err := io.ReadFull(r, lb[:]); err != nil {
		return nil, err
	}
	n := binary.BigEndian.Uint32(lb[:])
	if n == 0 || n > maxMsg {
		return nil, fmt.Errorf("bad message length %d", n)
	}
	p := make([]byte, n)
	if _, err := io.ReadFull(r, p); err != nil {
		return nil, err
	}
	return p, nil
}

func hubString(b []byte, off int) (string, int, bool) {
	if off >= len(b) {
		return "", 0, false
	}
	n := int(b[off])
	off++
	if off+n > len(b) {
		return "", 0, false
	}
	return string(b[off : off+n]), off + n, true
}

type viewer struct {
	mu        sync.Mutex
	latest    []byte       // newest FRAME payload (one slot)
	audio     [][]byte     // AUDIO payloads (bounded queue)
	wantAudio atomic.Bool  // can change mid-session (late sound answer)
	wantHi    atomic.Bool  // watching in sixel: wants the sharper pictures
	hi        []byte       // newest FRAME_HI payload
	jxlWant   atomic.Int32 // watching in JPEG XL: detail level + 1 (0 = not)
	jxl       []byte       // newest FRAME_JXL payload at that level
	notify    chan struct{}
	arrived   atomic.Int64 // frames delivered to this viewer's slot
}

func newViewer(wantAudio bool) *viewer {
	v := &viewer{notify: make(chan struct{}, 1)}
	v.wantAudio.Store(wantAudio)
	return v
}

func (v *viewer) wake() {
	select {
	case v.notify <- struct{}{}:
	default:
	}
}

func (v *viewer) set(frame []byte) {
	v.arrived.Add(1)
	v.mu.Lock()
	v.latest = frame
	v.mu.Unlock()
	v.wake()
}

func (v *viewer) pushAudio(p []byte) {
	v.mu.Lock()
	v.audio = append(v.audio, p)
	if len(v.audio) > 16 {
		v.audio = v.audio[len(v.audio)-16:]
	}
	v.mu.Unlock()
	v.wake()
}

func (v *viewer) setHi(p []byte) {
	v.mu.Lock()
	v.hi = p
	v.mu.Unlock()
}

func (v *viewer) setJXL(p []byte) {
	v.mu.Lock()
	v.jxl = p
	v.mu.Unlock()
}

// latestJXL is the newest JPEG XL picture.
func (v *viewer) latestJXL() []byte {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.jxl
}

// latestHi is the newest sharper picture (kept: it's drawn from repeatedly).
func (v *viewer) latestHi() []byte {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.hi
}

// take returns and clears the pending frame and audio.
func (v *viewer) take() ([]byte, [][]byte) {
	v.mu.Lock()
	defer v.mu.Unlock()
	f, a := v.latest, v.audio
	v.latest, v.audio = nil, nil
	return f, a
}

type feed struct {
	framesIn atomic.Int64 // frames received from the camera PC
	bytesIn  atomic.Int64 // all bytes received from the camera PC
	from     atomic.Value // camera PC address (string)

	mu        sync.Mutex
	latest    []byte
	latestHi  []byte
	hiAsked   bool // WANT_HI sent to the current producer
	latestJXL [jxlLevels][]byte
	jxlAsked  byte // the levels WANT_JXL last asked the current producer for
	jxlOK     bool // the current producer can make JPEG XL pictures
	jxlLevels bool // ... at all three detail levels (else High only)
	// The producer's playlist, for viewers' L key (playlist.go).
	playlistOK bool          // the current producer shares its playlist
	playlist   *playlistInfo // its last answer (nil = none yet)
	chat       *chatRoom     // group chat (chat.go)
	mnOff      bool          // the camera PC turned group chat off (its W key)
	chatOK     bool          // the camera PC shows the chat in its window (send it CHAT)
	lastFrame  time.Time
	viewers    map[*viewer]struct{}
	producer   net.Conn
}

type hub struct {
	mu    sync.Mutex
	feeds map[string]*feed

	statsMu sync.Mutex
	stats   map[*viewerStats]struct{}
}

func newHub() *hub {
	return &hub{feeds: map[string]*feed{}, stats: map[*viewerStats]struct{}{}}
}

func (h *hub) get(name string) *feed {
	h.mu.Lock()
	defer h.mu.Unlock()
	f := h.feeds[name]
	if f == nil {
		f = &feed{viewers: map[*viewer]struct{}{}}
		h.feeds[name] = f
	}
	return f
}

func (h *hub) subscribe(name string, v *viewer) {
	f := h.get(name)
	f.mu.Lock()
	f.viewers[v] = struct{}{}
	if f.latest != nil {
		v.set(f.latest)
	}
	f.mu.Unlock()
}

func (h *hub) unsubscribe(name string, v *viewer) {
	f := h.get(name)
	f.mu.Lock()
	delete(f.viewers, v)
	f.updateWantHiLocked()
	f.updateWantJXLLocked()
	f.mu.Unlock()
}

// setWantHi records whether viewer v watches in sixel, and tells the
// camera PC to start or stop sending sharper pictures as needed.
func (h *hub) setWantHi(name string, v *viewer, on bool) {
	v.wantHi.Store(on)
	f := h.get(name)
	f.mu.Lock()
	if on && f.latestHi != nil {
		v.setHi(f.latestHi)
	}
	f.updateWantHiLocked()
	f.mu.Unlock()
}

// updateWantHiLocked sends WANT_HI when the answer to "does anyone watch
// in sixel?" changes.
func (f *feed) updateWantHiLocked() {
	want := false
	for v := range f.viewers {
		if v.wantHi.Load() {
			want = true
			break
		}
	}
	if want == f.hiAsked || f.producer == nil {
		return
	}
	f.hiAsked = want
	on := byte(0)
	if want {
		on = 1
	}
	f.producer.SetWriteDeadline(time.Now().Add(2 * time.Second))
	f.producer.Write([]byte{0, 0, 0, 2, msgWantHi, on})
	f.producer.SetWriteDeadline(time.Time{})
}

// setWantJXL records the JPEG XL detail level viewer v watches at (0 High,
// 1 Medium, 2 Low; -1 = not watching in JPEG XL), and tells the camera PC
// which levels to make.
func (h *hub) setWantJXL(name string, v *viewer, level int) {
	if level >= jxlLevels {
		level = jxlLevels - 1
	}
	v.jxlWant.Store(int32(level + 1))
	f := h.get(name)
	f.mu.Lock()
	// The picture on screen stays until one of the new level comes (any
	// level draws fine; stale ones are skipped by their time stamp).
	if level >= 0 {
		if p := f.latestJXL[f.jxlSourceLocked(level)]; p != nil {
			v.setJXL(p)
		}
	}
	f.updateWantJXLLocked()
	f.mu.Unlock()
}

// jxlSourceLocked is the level whose pictures go to a viewer of level
// (a camera PC making High only serves everyone with High).
func (f *feed) jxlSourceLocked(level int) int {
	if !f.jxlLevels {
		return 0
	}
	return level
}

// jxlLevelsAvailable reports whether the channel's camera PC makes all
// three detail levels.
func (h *hub) jxlLevelsAvailable(name string) bool {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.producer != nil && f.jxlOK && f.jxlLevels
}

// jxlAvailable reports whether the channel's camera PC can make JPEG XL.
func (h *hub) jxlAvailable(name string) bool {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.producer != nil && f.jxlOK
}

func (f *feed) updateWantJXLLocked() {
	want := byte(0)
	for v := range f.viewers {
		if l := v.jxlWant.Load(); l > 0 {
			want |= 1 << f.jxlSourceLocked(int(l-1))
		}
	}
	if !f.jxlOK {
		want = 0
	}
	if want == f.jxlAsked || f.producer == nil {
		return
	}
	f.jxlAsked = want
	f.producer.SetWriteDeadline(time.Now().Add(2 * time.Second))
	f.producer.Write([]byte{0, 0, 0, 2, msgWantJXL, want})
	f.producer.SetWriteDeadline(time.Time{})
}

// status reports whether a producer is connected and when the last frame came.
func (h *hub) status(name string) (live bool, last time.Time, viewers int) {
	f := h.get(name)
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.producer != nil, f.lastFrame, len(f.viewers)
}

func (h *hub) viewerCount() int {
	h.mu.Lock()
	defer h.mu.Unlock()
	n := 0
	for _, f := range h.feeds {
		f.mu.Lock()
		n += len(f.viewers)
		f.mu.Unlock()
	}
	return n
}

func (h *hub) handleProducer(conn net.Conn, token string) {
	defer conn.Close()
	conn.SetReadDeadline(time.Now().Add(20 * time.Second))
	p, err := hubReadMsg(conn)
	if err != nil {
		log.Printf("feed %s: no hello (%v) - if this repeats, check TLS is set the same on both ends", conn.RemoteAddr(), err)
		return
	}
	if p[0] != msgHelloProducer {
		log.Printf("feed %s: bad hello 0x%02x - likely a TLS mismatch between telnetvision.ini and the server", conn.RemoteAddr(), p[0])
		return
	}
	tok, off, ok := hubString(p, 1)
	if !ok {
		return
	}
	ch, off, ok := hubString(p, off)
	if !ok {
		return
	}
	if subtle.ConstantTimeCompare([]byte(tok), []byte(token)) != 1 {
		log.Printf("feed %s: wrong token", conn.RemoteAddr())
		return
	}
	var caps byte
	if off < len(p) {
		caps = p[off]
	}
	conn.SetReadDeadline(time.Time{})
	// Tell telnetvision.exe what we understand (old ones ignore this).
	conn.SetWriteDeadline(time.Now().Add(5 * time.Second))
	conn.Write([]byte{0, 0, 0, 2, msgWelcome, capZFrames | capMessages})
	conn.SetWriteDeadline(time.Time{})
	var unz, unzHi frameUnzipper
	f := h.get(ch)
	f.mu.Lock()
	old := f.producer
	f.producer = conn
	f.hiAsked = false
	f.latestHi = nil
	f.updateWantHiLocked() // sixel viewers already waiting
	f.jxlAsked, f.latestJXL = 0, [jxlLevels][]byte{}
	f.jxlOK, f.jxlLevels = caps&capJXL != 0, caps&capJXLLevels != 0
	f.playlistOK, f.playlist = caps&capPlaylist != 0, nil
	f.mnOff, f.chatOK = false, caps&capChat != 0
	f.updateWantJXLLocked() // and JXL viewers
	f.mu.Unlock()
	if old != nil {
		log.Printf("channel %q: new feed took over; dropping the previous one", ch)
		old.Close()
	}
	log.Printf("feed %s is live on channel %q (audio=%v, jpeg xl=%s)", conn.RemoteAddr(), ch, caps&capAudio != 0, jxlCapsText(caps))
	f.from.Store(conn.RemoteAddr().String())
	defer func() {
		f.mu.Lock()
		if f.producer == conn {
			f.producer = nil
		}
		f.mu.Unlock()
	}()
	for {
		// A live feed sends ~15 frames/s; a minute of silence is a dead link.
		conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		p, err := hubReadMsg(conn)
		if err != nil {
			log.Printf("feed %s on channel %q ended: %v", conn.RemoteAddr(), ch, err)
			return
		}
		f.bytesIn.Add(int64(len(p) + 4))
		if p[0] == msgFrameHiZ {
			fp, err := unzHi.unzip(p)
			if err != nil {
				log.Printf("feed %s: bad packed sharp picture (%v)", conn.RemoteAddr(), err)
				continue
			}
			p = fp
		}
		if p[0] == msgFrameZ {
			fp, err := unz.unzip(p)
			if err != nil {
				log.Printf("feed %s: bad packed picture (%v)", conn.RemoteAddr(), err)
				continue
			}
			p = fp
		}
		switch p[0] {
		case msgFrame:
			f.framesIn.Add(1)
			f.mu.Lock()
			f.latest = p
			f.lastFrame = time.Now()
			for v := range f.viewers {
				v.set(p)
			}
			f.mu.Unlock()
		case msgFrameHi:
			f.mu.Lock()
			f.latestHi = p
			for v := range f.viewers {
				if v.wantHi.Load() {
					v.setHi(p)
				}
			}
			f.mu.Unlock()
		case msgPlaylist:
			if pl, ok := parsePlaylist(p); ok {
				f.mu.Lock()
				f.playlist = pl
				f.mu.Unlock()
			}
		case msgPlaylistNow:
			applyPlaylistNow(f, p)
		case msgMovieNight:
			if len(p) >= 2 {
				f.mu.Lock()
				f.mnOff = p[1] == 0
				f.mu.Unlock()
				log.Printf("channel %q: the camera PC turned group chat %s", ch, map[bool]string{true: "on", false: "off"}[p[1] != 0])
			}
		case msgFrameJXL, msgFrameJXLLevel:
			deliverJXL(f, p)
		case msgAudio:
			f.mu.Lock()
			for v := range f.viewers {
				if v.wantAudio.Load() {
					v.pushAudio(p)
				}
			}
			f.mu.Unlock()
		}
	}
}

// handleDoor serves the original door.exe protocol on the optional door
// port, so a BBS can still run the classic door alongside telnet viewers.
func (h *hub) handleDoor(conn net.Conn) {
	defer conn.Close()
	p, err := hubReadMsg(conn)
	if err != nil || p[0] != msgHelloConsumer {
		return
	}
	ch, off, ok := hubString(p, 1)
	if !ok {
		return
	}
	wantAudio := off < len(p) && p[off]&capAudio != 0
	v := newViewer(wantAudio)
	h.subscribe(ch, v)
	defer h.unsubscribe(ch, v)
	log.Printf("door %s watching channel %q", conn.RemoteAddr(), ch)
	done := make(chan struct{})
	go func() { io.Copy(io.Discard, conn); close(done) }()
	write := func(p []byte) error {
		var lb [4]byte
		binary.BigEndian.PutUint32(lb[:], uint32(len(p)))
		_, err := conn.Write(append(lb[:], p...))
		return err
	}
	for {
		select {
		case <-done:
			return
		case <-v.notify:
		}
		f, aud := v.take()
		for _, a := range aud {
			if write(a) != nil {
				return
			}
		}
		if f != nil && write(f) != nil {
			return
		}
	}
}

// deliverJXL hands a FRAME_JXL / FRAME_JXL_LEVEL picture to the viewers
// watching at its level.
func deliverJXL(f *feed, p []byte) {
	level := 0
	if p[0] == msgFrameJXLLevel {
		if len(p) < 15 || int(p[1]) >= jxlLevels {
			return
		}
		// Same layout as FRAME_JXL from here on.
		level = int(p[1])
		p = append([]byte{msgFrameJXL}, p[2:]...)
	} else if len(p) < 14 {
		return
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	f.latestJXL[level] = p
	for v := range f.viewers {
		if l := v.jxlWant.Load(); l > 0 && f.jxlSourceLocked(int(l-1)) == level {
			v.setJXL(p)
		}
	}
}

// applyPlaylistNow takes a PLAYLIST_NOW: what's playing and up next, with
// the names as last sent.
func applyPlaylistNow(f *feed, p []byte) {
	now, ok := parsePlaylist(append([]byte{msgPlaylist}, p[1:]...))
	if !ok {
		return
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	old := f.playlist
	if old == nil || old.off {
		return
	}
	now.names = old.names
	if c := binary.BigEndian.Uint32(p[1:5]); c < 0xFFFFFFFE {
		now.cur = int(c) // (parsePlaylist dropped it: no names in this message)
	}
	if now.cur >= len(now.names) {
		now.cur = -1
	}
	f.playlist = now
}
