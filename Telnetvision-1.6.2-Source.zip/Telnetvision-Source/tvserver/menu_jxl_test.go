package main

import (
	"bytes"
	"regexp"
	"strings"
	"testing"
)

func TestMenuJXLFits(t *testing.T) {
	for _, cam := range []bool{true, false} {
		v := viewerSettings{color: colorJXL, jxlOK: true, jxlCam: cam, fps: 15, maxFPS: 30, quality: qualityBest, codec: soundADPCM, detail: sixelMedium}
		var b bytes.Buffer
		drawMenu(&b, &v, "", 80, 25, false)
		txt := regexp.MustCompile("\x1b\\[[0-9;]*H").ReplaceAllString(b.String(), "\n")
		txt = regexp.MustCompile("\x1b\\[[0-9;?]*[A-Za-z]").ReplaceAllString(txt, "")
		for _, l := range strings.Split(txt, "\n") {
			if strings.Contains(l, "Colors") || strings.Contains(l, "JPEG") {
				t.Logf("%q", l)
				if len([]rune(l)) > 80 {
					t.Errorf("too wide: %d", len([]rune(l)))
				}
			}
		}
	}
}
