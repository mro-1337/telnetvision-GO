package main

// The playlist for viewers (tvserver's L key): a viewer who is the only one
// watching can see what's in the playlist, play something now, or tag
// things to play next. tvserver asks for the list (WANT_PLAYLIST); this
// answers with PLAYLIST; a choice comes back as PLAY_ITEM.

import (
	"encoding/binary"
	"hash/fnv"
	"strconv"
	"strings"
	"sync"
)

// playlistOff in PLAYLIST's "now playing" means the camera PC has the
// viewers' playlist turned off (an older tvserver reads it as an empty
// list: "nothing to pick").
const playlistOff = 0xFFFFFFFE

const (
	msgPlaylist     = 0x17 // 0x17 | u32 now playing (0xFFFFFFFF = none) | u16 n | n x u32 up next, in order | names, one per line
	msgPlaylistNow  = 0x18 // 0x18 | u32 now playing | u16 n | n x u32 up next: PLAYLIST without the names (they haven't changed)
	msgWantPlaylist = 0x23 // server -> producer: send PLAYLIST (0x23 | u8 1 = with the names, 0 = only if they changed)
	msgPlayItem     = 0x24 // server -> producer: 0x24 | u8 0 = play now, 1 = tag / untag as up next | u32 index
	capPlaylist     = 0x08 // hello caps: this producer shares its playlist

	maxPlaylistNames = 20000
	maxPlaylistName  = 200 // characters
)

// The names last sent in full: while a viewer has the list open, tvserver
// asks every few seconds what's playing, and the names - which can be
// thousands of songs - only go again when they've changed. (Sending them
// every time held up the sound behind them.)
var playlistSent struct {
	sync.Mutex
	hash uint64
}

func namesHash(names []string) uint64 {
	h := fnv.New64a()
	for _, n := range names {
		h.Write([]byte(n))
		h.Write([]byte{0})
	}
	return h.Sum64()
}

// playlistAnswer is what to send: the whole list (full, or the names
// changed since they were last sent), or just what's playing and up next.
func playlistAnswer(cur int, upNext []int, names []string, full bool) []byte {
	h := namesHash(names)
	playlistSent.Lock()
	same := !full && playlistSent.hash == h
	playlistSent.hash = h
	playlistSent.Unlock()
	if !same {
		return playlistPayload(cur, upNext, names)
	}
	m := []byte{msgPlaylistNow}
	c := uint32(0xFFFFFFFF)
	if cur >= 0 && cur < len(names) {
		c = uint32(cur)
	}
	m = binary.BigEndian.AppendUint32(m, c)
	upNext = upNext[:min(len(upNext), 1000)]
	m = binary.BigEndian.AppendUint16(m, uint16(len(upNext)))
	for _, i := range upNext {
		m = binary.BigEndian.AppendUint32(m, uint32(i))
	}
	return framed(m)
}

// playlistPayload is a PLAYLIST message (framed).
func playlistPayload(cur int, upNext []int, names []string) []byte {
	if len(names) > maxPlaylistNames {
		names = names[:maxPlaylistNames]
	}
	if len(upNext) > 1000 {
		upNext = upNext[:1000]
	}
	p := []byte{msgPlaylist}
	c := uint32(0xFFFFFFFF)
	if cur >= 0 && cur < len(names) {
		c = uint32(cur)
	}
	p = binary.BigEndian.AppendUint32(p, c)
	p = binary.BigEndian.AppendUint16(p, uint16(len(upNext)))
	for _, i := range upNext {
		p = binary.BigEndian.AppendUint32(p, uint32(i))
	}
	clean := make([]string, len(names))
	for i, n := range names {
		n = strings.Map(func(r rune) rune {
			if r < 32 || r == 127 {
				return ' '
			}
			return r
		}, n)
		if r := []rune(n); len(r) > maxPlaylistName {
			n = string(r[:maxPlaylistName])
		}
		clean[i] = n
	}
	p = append(p, strings.Join(clean, "\n")...)
	return framed(p)
}

// handlePlaylistRequest acts on WANT_PLAYLIST / PLAY_ITEM from tvserver.
func handlePlaylistRequest(b []byte, p *Player, snd *Sender, logf func(string, ...any)) {
	if !p.ViewerPlaylist() {
		if b[0] == msgPlayItem {
			logf("a viewer tried to pick from the playlist, but it's turned off (O)")
		}
		off := []byte{msgPlaylist, 0xFF, 0xFF, 0xFF, 0xFE, 0, 0}
		snd.SendControl(framed(off))
		return
	}
	switch {
	case b[0] == msgWantPlaylist:
		full := len(b) < 2 || b[1] != 0 // tvserver 1.5.0-1.5.5 always wants the names
		cur, up, names := p.PlaylistInfo()
		snd.SendControl(playlistAnswer(cur, up, names, full))
	case b[0] == msgPlayItem && len(b) >= 6:
		mode, i := b[1], int(binary.BigEndian.Uint32(b[2:6]))
		_, _, names := p.PlaylistInfo()
		if i < 0 || i >= len(names) {
			return
		}
		if mode == 0 {
			logf("a viewer picked %d %s from the playlist: playing it now", i+1, names[i])
			p.Command("goto", strconv.Itoa(i+1))
		} else if on := p.ToggleUpNext(i); on {
			logf("a viewer tagged %d %s to play next", i+1, names[i])
		} else {
			logf("a viewer untagged %d %s", i+1, names[i])
		}
		cur, up, names := p.PlaylistInfo()
		snd.SendControl(playlistAnswer(cur, up, names, false))
	}
}
