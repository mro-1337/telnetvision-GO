package main

// A music visualizer in the spirit of Milkdrop. Each frame:
//
//  1. the sound of the last ~50 ms is analysed: bass, mid and treble
//     loudness (relative to the song's own recent average, so quiet and
//     loud songs both move), a spectrum, and beats;
//  2. the previous frame is warped - zoomed, rotated, moved, rippled - and
//     faded a little, which is what makes the trails and tunnels;
//  3. the preset draws on top: a waveform, a spectrum, particles, rings;
//  4. some presets mirror the picture into a kaleidoscope.
//
// The motion follows the music: presets' zoom, spin and ripple are
// formulas of the bass/mid/treble and time. Every VIZ_SECONDS (on a beat)
// it blends smoothly into another preset; V switches by hand.
//
// It renders at the picture size viewers get (160x96 for sixel, 80x48
// for characters), which is small enough to be cheap on any PC.

import (
	"math"
	"math/cmplx"
	"math/rand"
	"strings"
	"sync/atomic"
)

const (
	vizFFT     = 1024
	vizBands   = 32
	vizBlendS  = 2.5 // seconds to blend into the next preset
	vizMinBeat = 0.3 // seconds between beats at most this often
)

// vizState is what presets' formulas can use.
type vizState struct {
	t                float64 // seconds
	bass, mid, treb  float64 // ~1 = the song's average, 2 = twice as loud
	bassA, midA, trA float64 // the same, smoothed (Milkdrop's *_att)
	vol              float64 // overall loudness 0..1
	beat             float64 // 1 at a beat, fading to 0
	beats            int     // beats so far
	aspect           float64
}

type vizMotion struct {
	zoom, rot      float64 // >1 zooms in; radians per frame
	dx, dy         float64 // move per frame (screen heights)
	cx, cy         float64 // centre of zoom/rotation
	warp, warpFreq float64 // ripple strength and frequency
	warpSpeed      float64
	decay          float64 // how much of the last frame stays (0.85..0.99)
	hueDrift       float64 // colour rotation of the trails per frame
}

const (
	waveCircle = iota
	waveLine
	waveSpectrum
	waveDots
	waveScope
	waveRings
	waveFlower
	waveBars
)

type vizPreset struct {
	name     string
	motion   func(s *vizState) vizMotion
	waves    []int
	mirror   int     // 0 none, 1 left/right, 2 four ways
	hueSpeed float64 // how fast the drawing colour cycles
	hueBase  float64 // starting hue (0..1)
	sat      float64 // drawing colour saturation
}

var vizPresets = []vizPreset{
	{name: "Tunnel", waves: []int{waveCircle}, hueSpeed: 0.05, sat: 0.9,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.025 + 0.04*s.bassA, rot: 0.012 * math.Sin(s.t*0.37), warp: 0.008, warpFreq: 4, warpSpeed: 1.2,
				decay: 0.94, hueDrift: 0.004}
		}},
	{name: "Spiral Galaxy", waves: []int{waveScope}, hueSpeed: 0.03, sat: 0.8,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 0.992 + 0.015*s.bassA, rot: 0.05 + 0.03*s.midA, warp: 0.004, warpFreq: 3, warpSpeed: 0.7, decay: 0.94, hueDrift: 0.006}
		}},
	{name: "Kaleidoscope", waves: []int{waveFlower}, mirror: 2, hueSpeed: 0.08, sat: 1,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.02 + 0.02*s.bass, rot: 0.03 * math.Sin(s.t*0.21), warp: 0.025, warpFreq: 5, warpSpeed: 2,
				decay: 0.93, hueDrift: 0.01}
		}},
	{name: "Plasma Ocean", waves: []int{waveLine}, hueSpeed: 0.02, hueBase: 0.55, sat: 0.85,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.003, warp: 0.03 + 0.03*s.trA, warpFreq: 2.5, warpSpeed: 1.5 + s.mid, dy: 0.002 * math.Sin(s.t*0.5),
				decay: 0.955, hueDrift: 0.012}
		}},
	{name: "Spectrum City", waves: []int{waveSpectrum}, mirror: 1, hueSpeed: 0.04, sat: 0.9,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1, dy: -0.012 - 0.01*s.bassA, decay: 0.9, hueDrift: 0.003}
		}},
	{name: "Starburst", waves: []int{waveDots, waveCircle}, hueSpeed: 0.1, sat: 0.7,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.06 + 0.12*s.beat, rot: 0.01, decay: 0.9, hueDrift: 0.002}
		}},
	{name: "Vortex", waves: []int{waveCircle}, hueSpeed: 0.06, hueBase: 0.8, sat: 0.95,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.035 + 0.02*s.bassA, rot: 0.06 + 0.06*math.Sin(s.t*0.13), cx: 0.35 * math.Sin(s.t*0.31), cy: 0.25 * math.Cos(s.t*0.23),
				warp: 0.01, warpFreq: 3, warpSpeed: 1, decay: 0.95, hueDrift: 0.008}
		}},
	{name: "Fire", waves: []int{waveSpectrum, waveDots}, hueSpeed: 0.004, hueBase: 0.02, sat: 1,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.004, dy: -0.018 - 0.015*s.trA, warp: 0.018, warpFreq: 6, warpSpeed: 3, decay: 0.91}
		}},
	{name: "Mirror Scope", waves: []int{waveScope, waveScope}, mirror: 1, hueSpeed: 0.05, hueBase: 0.3, sat: 0.9,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 0.996 + 0.01*s.bass, rot: 0.02, decay: 0.94, hueDrift: 0.005}
		}},
	{name: "Pulse Rings", waves: []int{waveRings, waveCircle}, hueSpeed: 0.07, sat: 0.9,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.045 + 0.03*s.bassA, rot: -0.008, decay: 0.93, hueDrift: 0.004}
		}},
	{name: "Rain", waves: []int{waveLine, waveDots}, hueSpeed: 0.02, hueBase: 0.6, sat: 0.6,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1, dy: 0.016 + 0.01*s.bassA, dx: 0.003 * math.Sin(s.t*0.4), warp: 0.004, warpFreq: 8, warpSpeed: 2, decay: 0.94}
		}},
	{name: "Neon Flower", waves: []int{waveFlower, waveBars}, mirror: 2, hueSpeed: 0.12, sat: 1,
		motion: func(s *vizState) vizMotion {
			return vizMotion{zoom: 1.01 + 0.01*s.bassA, rot: -0.03 - 0.02*s.trA, decay: 0.95, hueDrift: 0.015}
		}},
}

// vizPresetIndex finds a preset by (part of) its name.
func vizPresetIndex(name string) int {
	n := strings.ToLower(strings.ReplaceAll(strings.TrimSpace(name), " ", ""))
	for i, p := range vizPresets {
		if strings.Contains(strings.ToLower(strings.ReplaceAll(p.name, " ", "")), n) && n != "" {
			return i
		}
	}
	return -1
}

func vizPresetNames() []string {
	out := make([]string, len(vizPresets))
	for i, p := range vizPresets {
		out[i] = p.name
	}
	return out
}

type vizEngine struct {
	w, h      int
	cur, prev []float32 // RGB 0..1
	rate      int
	fps       float64

	ring    []float32 // the newest samples, mono
	ringR   []float32 // right channel (or a delayed copy for mono)
	ringPos int

	st               vizState
	avgB, avgM, avgT float64
	lastBeat         float64
	spectrum         [vizBands]float64
	preset, from     int
	blend            float64 // 1 = fully on preset; <1 = blending from "from"
	nextSwitch       float64
	switchEvery      float64 // 0 = only by hand
	fixed            bool
	hue              float64
	rings            []float64 // ring radii (waveRings)
	dots             []vizDot
	rng              *rand.Rand
	request          atomic.Int32 // 1 = next preset (V key)
	window           [vizFFT]float64
	announce         func(string)
}

type vizDot struct{ x, y, vx, vy, life, hue float64 }

// newVizEngine makes a visualizer. choice is VISUALIZER: "auto" (random
// presets in turn) or a preset name to start with and stay on.
func newVizEngine(w, h, rate int, fps float64, choice string, switchSecs float64) *vizEngine {
	e := &vizEngine{w: w, h: h, rate: rate, fps: fps, rng: rand.New(rand.NewSource(rand.Int63())),
		cur: make([]float32, w*h*3), prev: make([]float32, w*h*3),
		ring: make([]float32, vizFFT), ringR: make([]float32, vizFFT),
		avgB: 1e-6, avgM: 1e-6, avgT: 1e-6, blend: 1, switchEvery: switchSecs}
	e.st.aspect = float64(w) / float64(h)
	e.preset = e.rng.Intn(len(vizPresets))
	if i := vizPresetIndex(choice); i >= 0 {
		e.preset, e.fixed = i, true
	}
	e.nextSwitch = switchSecs
	for i := range e.window {
		e.window[i] = 0.5 - 0.5*math.Cos(2*math.Pi*float64(i)/float64(vizFFT-1))
	}
	return e
}

// PresetName is the preset showing now.
func (e *vizEngine) PresetName() string { return vizPresets[e.preset].name }

// Next asks for the next preset (from another goroutine: the V key).
func (e *vizEngine) Next() { e.request.Store(1) }

// feed adds interleaved 16-bit samples.
func (e *vizEngine) feed(pcm []byte, ch int) {
	for i := 0; i+2*ch <= len(pcm); i += 2 * ch {
		l := float32(int16(uint16(pcm[i])|uint16(pcm[i+1])<<8)) / 32768
		r := l
		if ch == 2 {
			r = float32(int16(uint16(pcm[i+2])|uint16(pcm[i+3])<<8)) / 32768
		}
		e.ring[e.ringPos] = (l + r) / 2
		e.ringR[e.ringPos] = r
		e.ringPos = (e.ringPos + 1) % vizFFT
	}
}

// sample returns the i-th newest-but-ordered sample (0 = oldest in ring).
func (e *vizEngine) sample(i int) float64 { return float64(e.ring[(e.ringPos+i)%vizFFT]) }
func (e *vizEngine) sampleR(i int) float64 {
	return float64(e.ringR[(e.ringPos+i)%vizFFT])
}

// analyse updates bass/mid/treble, the spectrum and beats.
func (e *vizEngine) analyse(dt float64) {
	var buf [vizFFT]complex128
	sum := 0.0
	for i := 0; i < vizFFT; i++ {
		s := e.sample(i)
		sum += s * s
		buf[i] = complex(s*e.window[i], 0)
	}
	fft(buf[:])
	binHz := float64(e.rate) / vizFFT
	band := func(lo, hi float64) float64 {
		a, b := int(lo/binHz), int(hi/binHz)
		if a < 1 {
			a = 1
		}
		if b > vizFFT/2 {
			b = vizFFT / 2
		}
		v := 0.0
		for k := a; k < b; k++ {
			v += cmplx.Abs(buf[k])
		}
		return v / float64(max(1, b-a))
	}
	b, m, t := band(20, 250), band(250, 2000), band(2000, math.Min(9000, float64(e.rate)/2))
	// Long-run averages (a few seconds), so levels are relative to the song.
	k := math.Min(1, dt/4)
	e.avgB += (b - e.avgB) * k
	e.avgM += (m - e.avgM) * k
	e.avgT += (t - e.avgT) * k
	rel := func(v, avg float64) float64 {
		if avg < 1e-4 {
			return 0
		}
		return math.Min(4, v/avg)
	}
	s := &e.st
	s.bass, s.mid, s.treb = rel(b, e.avgB), rel(m, e.avgM), rel(t, e.avgT)
	att := math.Min(1, dt*3)
	s.bassA += (s.bass - s.bassA) * att
	s.midA += (s.mid - s.midA) * att
	s.trA += (s.treb - s.trA) * att
	s.vol = math.Min(1, math.Sqrt(sum/vizFFT)*4)
	s.beat *= math.Pow(0.02, dt) // fades in about a second
	if s.bass > 1.45 && s.bass > s.bassA*1.15 && s.t-e.lastBeat > vizMinBeat && s.vol > 0.02 {
		s.beat, e.lastBeat = 1, s.t
		s.beats++
	}
	// Log-spaced spectrum bands for the bars and flowers.
	lo := 40.0
	hi := math.Min(11000, float64(e.rate)/2)
	for i := 0; i < vizBands; i++ {
		f0 := lo * math.Pow(hi/lo, float64(i)/vizBands)
		f1 := lo * math.Pow(hi/lo, float64(i+1)/vizBands)
		// A full-scale tone is about vizFFT/4; map 1/1000 of that .. full to 0..1.
		v := band(f0, f1) / (vizFFT / 4)
		lv := math.Max(0, math.Log10(v*1000+1e-9)/3)
		if lv > e.spectrum[i] {
			e.spectrum[i] = lv
		} else {
			e.spectrum[i] += (lv - e.spectrum[i]) * math.Min(1, dt*6)
		}
	}
}

// frame renders one frame dt seconds after the last into out (RGB24).
func (e *vizEngine) frame(dt float64, out []byte) {
	s := &e.st
	s.t += dt
	e.analyse(dt)
	e.maybeSwitch()

	p := &vizPresets[e.preset]
	m := p.motion(s)
	if e.blend < 1 {
		e.blend = math.Min(1, e.blend+dt/vizBlendS)
		m = lerpMotion(vizPresets[e.from].motion(s), m, smooth(e.blend))
	}
	e.prev, e.cur = e.cur, e.prev
	e.warp(m)
	e.hue += p.hueSpeed * dt * (1 + s.trA*0.5)

	// Draw: the new preset fades in while the old one fades out.
	wNew := 1.0
	if e.blend < 1 {
		wNew = smooth(e.blend)
		e.draw(&vizPresets[e.from], 1-wNew)
	}
	e.draw(p, wNew)

	mir := p.mirror
	if e.blend < 0.5 {
		mir = vizPresets[e.from].mirror
	}
	e.mirror(mir)
	e.output(out)
}

func smooth(x float64) float64 { return x * x * (3 - 2*x) }

func lerpMotion(a, b vizMotion, t float64) vizMotion {
	l := func(x, y float64) float64 { return x + (y-x)*t }
	return vizMotion{zoom: l(a.zoom, b.zoom), rot: l(a.rot, b.rot), dx: l(a.dx, b.dx), dy: l(a.dy, b.dy),
		cx: l(a.cx, b.cx), cy: l(a.cy, b.cy), warp: l(a.warp, b.warp), warpFreq: l(a.warpFreq, b.warpFreq),
		warpSpeed: l(a.warpSpeed, b.warpSpeed), decay: l(a.decay, b.decay), hueDrift: l(a.hueDrift, b.hueDrift)}
}

func (e *vizEngine) maybeSwitch() {
	manual := e.request.Swap(0) == 1
	if !manual && (e.fixed || e.switchEvery <= 0) {
		return
	}
	s := &e.st
	due := s.t >= e.nextSwitch && (s.beat > 0.95 || s.t >= e.nextSwitch+6)
	if !manual && (!due || e.blend < 1) {
		return
	}
	next := e.rng.Intn(len(vizPresets) - 1)
	if next >= e.preset {
		next++
	}
	if manual {
		next = (e.preset + 1) % len(vizPresets)
	}
	e.from, e.preset, e.blend = e.preset, next, 0
	e.nextSwitch = s.t + e.switchEvery
	if e.announce != nil {
		e.announce(vizPresets[next].name)
	}
}

// warp builds this frame from the last one, moved and faded.
func (e *vizEngine) warp(m vizMotion) {
	w, h := e.w, e.h
	asp := e.st.aspect
	cosR, sinR := math.Cos(m.rot), math.Sin(m.rot)
	zoom := m.zoom
	if zoom <= 0.01 {
		zoom = 1
	}
	decay := float32(m.decay)
	t := e.st.t * m.warpSpeed
	// Colour drift: rotate the trails' colours a little each frame.
	hd := m.hueDrift
	c0, c1 := float32(1-hd), float32(hd)
	for y := 0; y < h; y++ {
		v := (float64(y)+0.5)/float64(h)*2 - 1
		for x := 0; x < w; x++ {
			u := ((float64(x)+0.5)/float64(w)*2 - 1) * asp
			// Where did this pixel come from? Undo the zoom and rotation
			// around the centre, then the move and the ripple.
			du, dv := u-m.cx*asp, v-m.cy
			du, dv = du/zoom, dv/zoom
			su := du*cosR + dv*sinR + m.cx*asp - m.dx*asp
			sv := -du*sinR + dv*cosR + m.cy - m.dy
			if m.warp != 0 {
				su += m.warp * math.Sin(sv*m.warpFreq+t)
				sv += m.warp * math.Cos(su*m.warpFreq*0.9+t*1.1)
			}
			px := (su/asp+1)/2*float64(w) - 0.5
			py := (sv+1)/2*float64(h) - 0.5
			r, g, b := e.samplePrev(px, py)
			i := (y*w + x) * 3
			e.cur[i] = (c0*r + c1*b) * decay
			e.cur[i+1] = (c0*g + c1*r) * decay
			e.cur[i+2] = (c0*b + c1*g) * decay
		}
	}
}

// samplePrev reads the last frame between pixels; outside it is black.
func (e *vizEngine) samplePrev(x, y float64) (float32, float32, float32) {
	if x < -1 || y < -1 || x > float64(e.w) || y > float64(e.h) {
		return 0, 0, 0
	}
	x0, y0 := int(math.Floor(x)), int(math.Floor(y))
	fx, fy := float32(x-float64(x0)), float32(y-float64(y0))
	var r, g, b float32
	add := func(xi, yi int, wt float32) {
		if xi < 0 || yi < 0 || xi >= e.w || yi >= e.h || wt == 0 {
			return
		}
		i := (yi*e.w + xi) * 3
		r += e.prev[i] * wt
		g += e.prev[i+1] * wt
		b += e.prev[i+2] * wt
	}
	add(x0, y0, (1-fx)*(1-fy))
	add(x0+1, y0, fx*(1-fy))
	add(x0, y0+1, (1-fx)*fy)
	add(x0+1, y0+1, fx*fy)
	return r, g, b
}

// plot adds light at a point given in screen units (-aspect..aspect, -1..1).
func (e *vizEngine) plot(u, v float64, r, g, b float64) {
	x := (u/e.st.aspect+1)/2*float64(e.w) - 0.5
	y := (v+1)/2*float64(e.h) - 0.5
	x0, y0 := int(math.Floor(x)), int(math.Floor(y))
	fx, fy := x-float64(x0), y-float64(y0)
	put := func(xi, yi int, wt float64) {
		if xi < 0 || yi < 0 || xi >= e.w || yi >= e.h {
			return
		}
		i := (yi*e.w + xi) * 3
		e.cur[i] += float32(r * wt)
		e.cur[i+1] += float32(g * wt)
		e.cur[i+2] += float32(b * wt)
	}
	put(x0, y0, (1-fx)*(1-fy))
	put(x0+1, y0, fx*(1-fy))
	put(x0, y0+1, (1-fx)*fy)
	put(x0+1, y0+1, fx*fy)
}

// line draws from (u0,v0) to (u1,v1).
func (e *vizEngine) line(u0, v0, u1, v1, r, g, b float64) {
	du := (u1 - u0) / e.st.aspect * float64(e.w) / 2
	dv := (v1 - v0) * float64(e.h) / 2
	n := int(math.Max(math.Abs(du), math.Abs(dv))) + 1
	if n > 400 {
		n = 400
	}
	for i := 0; i <= n; i++ {
		t := float64(i) / float64(n)
		e.plot(u0+(u1-u0)*t, v0+(v1-v0)*t, r, g, b)
	}
}

// colour is the drawing colour now, at hue offset off.
func (e *vizEngine) colour(p *vizPreset, off, bright float64) (float64, float64, float64) {
	h := math.Mod(p.hueBase+e.hue+off, 1)
	if h < 0 {
		h++
	}
	r, g, b := hsv(h, p.sat, 1)
	return r * bright, g * bright, b * bright
}

func hsv(h, s, v float64) (float64, float64, float64) {
	i := math.Floor(h * 6)
	f := h*6 - i
	p, q, t := v*(1-s), v*(1-f*s), v*(1-(1-f)*s)
	switch int(i) % 6 {
	case 0:
		return v, t, p
	case 1:
		return q, v, p
	case 2:
		return p, v, t
	case 3:
		return p, q, v
	case 4:
		return t, p, v
	}
	return v, p, q
}

func (e *vizEngine) draw(p *vizPreset, weight float64) {
	if weight <= 0.01 {
		return
	}
	s := &e.st
	bright := weight * (0.3 + 0.45*s.vol + 0.3*s.beat)
	asp := s.aspect
	for wi, wave := range p.waves {
		off := float64(wi) * 0.33
		switch wave {
		case waveCircle:
			n := 96
			r0 := 0.32 + 0.12*math.Min(2, s.bassA) + 0.1*s.beat
			var pu, pv float64
			for i := 0; i <= n; i++ {
				a := float64(i) / float64(n) * 2 * math.Pi
				amp := e.sample(i*vizFFT/(n+1)) * 0.6
				rr := r0 + amp
				u, v := rr*math.Cos(a)*1.0, rr*math.Sin(a)
				if i > 0 {
					cr, cg, cb := e.colour(p, off+float64(i)/float64(n)*0.15, bright)
					e.line(pu, pv, u, v, cr, cg, cb)
				}
				pu, pv = u, v
			}
		case waveLine:
			n := 128
			var pu, pv float64
			for i := 0; i <= n; i++ {
				u := (float64(i)/float64(n)*2 - 1) * asp
				v := e.sample(i*(vizFFT-1)/n)*0.9 + 0.25*math.Sin(s.t*0.7+off*6)
				if i > 0 {
					cr, cg, cb := e.colour(p, off+float64(i)/float64(n)*0.2, bright)
					e.line(pu, pv, u, v, cr, cg, cb)
				}
				pu, pv = u, v
			}
		case waveSpectrum, waveBars:
			bw := 2 * asp / vizBands // each band's width
			for i := 0; i < vizBands; i++ {
				hgt := math.Min(1.9, e.spectrum[i]*1.7)
				u0 := float64(i)*bw - asp
				cr, cg, cb := e.colour(p, off+float64(i)/vizBands*0.5, bright*0.7)
				for k := 0.15; k < 0.85; k += 0.2 { // a few lines make a bar
					u := u0 + bw*k
					if wave == waveBars { // from the middle, both ways
						e.line(u, -hgt/2, u, hgt/2, cr*0.6, cg*0.6, cb*0.6)
					} else {
						e.line(u, 1, u, 1-hgt, cr, cg, cb)
					}
				}
			}
		case waveDots:
			// Particles: a burst on each beat, sparks with the treble.
			spawn := int(s.treb * 1.5)
			if s.beat == 1 {
				spawn += 24
			}
			for i := 0; i < spawn && len(e.dots) < 300; i++ {
				a := e.rng.Float64() * 2 * math.Pi
				sp := 0.2 + e.rng.Float64()*0.8
				e.dots = append(e.dots, vizDot{x: 0, y: 0, vx: math.Cos(a) * sp, vy: math.Sin(a) * sp, life: 1, hue: e.rng.Float64() * 0.3})
			}
			dt := 1 / e.fps
			alive := e.dots[:0]
			for _, d := range e.dots {
				d.x += d.vx * dt
				d.y += d.vy * dt
				d.life -= dt * 0.7
				if d.life > 0 && math.Abs(d.x) < asp+0.1 && math.Abs(d.y) < 1.1 {
					cr, cg, cb := e.colour(p, off+d.hue, bright*d.life*1.5)
					e.plot(d.x, d.y, cr, cg, cb)
					alive = append(alive, d)
				}
			}
			e.dots = alive
		case waveScope:
			// Sound against itself a moment later (or left vs right):
			// shapes that twist with the music.
			n := 256
			lag := 7 + int(3*math.Sin(s.t*0.3))
			rot := s.t * 0.2 * (1 + off)
			cs, sn := math.Cos(rot), math.Sin(rot)
			var pu, pv float64
			for i := 0; i < n; i++ {
				j := vizFFT - n - lag + i
				x, y := e.sample(j)*1.4, e.sampleR(j+lag)*1.4
				u, v := (x*cs-y*sn)*1.2, x*sn+y*cs
				if i > 0 {
					cr, cg, cb := e.colour(p, off+float64(i)/float64(n)*0.3, bright*0.3)
					e.line(pu, pv, u, v, cr, cg, cb)
				}
				pu, pv = u, v
			}
		case waveRings:
			if s.beat == 1 {
				e.rings = append(e.rings, 0.05)
			}
			alive := e.rings[:0]
			for _, r := range e.rings {
				r += 0.9 / e.fps
				if r < 2 {
					n := 72
					cr, cg, cb := e.colour(p, off+r*0.3, bright*(1-r/2))
					for i := 0; i < n; i++ {
						a0 := float64(i) / float64(n) * 2 * math.Pi
						a1 := float64(i+1) / float64(n) * 2 * math.Pi
						e.line(r*math.Cos(a0), r*math.Sin(a0), r*math.Cos(a1), r*math.Sin(a1), cr, cg, cb)
					}
					alive = append(alive, r)
				}
			}
			e.rings = alive
		case waveFlower:
			n := 120
			petals := 5 + (s.beats/8)%4
			var pu, pv float64
			for i := 0; i <= n; i++ {
				a := float64(i) / float64(n) * 2 * math.Pi
				bnd := int(math.Abs(math.Sin(a*float64(petals)/2)) * (vizBands - 1))
				rr := 0.2 + 0.5*math.Min(1.4, e.spectrum[bnd]) + 0.08*s.beat
				u, v := rr*math.Cos(a+s.t*0.3), rr*math.Sin(a+s.t*0.3)
				if i > 0 {
					cr, cg, cb := e.colour(p, off+float64(bnd)/vizBands*0.4, bright)
					e.line(pu, pv, u, v, cr, cg, cb)
				}
				pu, pv = u, v
			}
		}
	}
}

// mirror folds the picture: 1 = left half onto the right, 2 = four ways.
func (e *vizEngine) mirror(mode int) {
	if mode == 0 {
		return
	}
	w, h := e.w, e.h
	for y := 0; y < h; y++ {
		for x := w / 2; x < w; x++ {
			src := (y*w + (w - 1 - x)) * 3
			dst := (y*w + x) * 3
			copy(e.cur[dst:dst+3], e.cur[src:src+3])
		}
	}
	if mode == 2 {
		for y := h / 2; y < h; y++ {
			copy(e.cur[y*w*3:(y+1)*w*3], e.cur[(h-1-y)*w*3:(h-y)*w*3])
		}
	}
}

// output turns the light buffer into RGB24, keeping the buffer itself
// within range so trails don't grow without end.
func (e *vizEngine) output(out []byte) {
	for i, v := range e.cur {
		if v > 1.5 {
			v = 1.5
			e.cur[i] = v
		} else if v < 0 {
			v = 0
			e.cur[i] = 0
		}
		// Soft shoulder: bright stays colourful instead of clipping white.
		o := float64(v) / (1 + float64(v)*0.35) * 1.35
		if o > 1 {
			o = 1
		}
		out[i] = byte(math.Pow(o, 0.85) * 255)
	}
}

// fft is an in-place radix-2 FFT (len must be a power of two).
func fft(a []complex128) {
	n := len(a)
	for i, j := 1, 0; i < n; i++ {
		bit := n >> 1
		for ; j&bit != 0; bit >>= 1 {
			j ^= bit
		}
		j ^= bit
		if i < j {
			a[i], a[j] = a[j], a[i]
		}
	}
	for size := 2; size <= n; size <<= 1 {
		w := cmplx.Exp(complex(0, -2*math.Pi/float64(size)))
		for start := 0; start < n; start += size {
			wk := complex(1, 0)
			for k := 0; k < size/2; k++ {
				x, y := a[start+k], a[start+k+size/2]*wk
				a[start+k], a[start+k+size/2] = x+y, x-y
				wk *= w
			}
		}
	}
}
