package main

import (
	"os"
	"strings"
	"testing"
	"time"
)

func TestParseSeekTime(t *testing.T) {
	cases := map[string]string{
		"1:05:00": "=3900", "45:00": "=2700", "1:30": "=90", "90": "=5400", "90m": "=5400",
		"1h30m": "=5400", "45s": "=45", "1h": "=3600", "+10": "+600", "-5": "-300",
		"+30s": "+30", "-1:00": "-60", " 2 : 03 ": "=123", "0": "=0", "1.5": "=90",
	}
	for in, want := range cases {
		if got, ok := parseSeekTime(in); !ok || got != want {
			t.Errorf("parseSeekTime(%q) = %q, %v; want %q", in, got, ok, want)
		}
	}
	for _, bad := range []string{"", "+", "abc", "1:75", "1:2:3:4", "5x", "h", "-", "1::2"} {
		if got, ok := parseSeekTime(bad); ok {
			t.Errorf("parseSeekTime(%q) = %q, want an error", bad, got)
		}
	}
	if d := describeSeek("+300"); d != "5:00 ahead" {
		t.Errorf("describeSeek: %q", d)
	}
	if c := clockTime(3725); c != "1:02:05" {
		t.Errorf("clockTime: %q", c)
	}
}

func TestArrowKeysSeek(t *testing.T) {
	c := newControls(&Config{SeekStep: 5})
	c.key(keyRight)
	c.key(keyLeft)
	for _, want := range []string{"+300", "-300"} {
		a := <-c.actions
		if a.kind != "seek" || a.arg != want {
			t.Errorf("got %+v, want seek %s", a, want)
		}
	}
	c.key('j')
	for _, k := range []byte("1:05:00\r") {
		c.key(k)
	}
	if a := <-c.actions; a.kind != "seek" || a.arg != "=3900" {
		t.Errorf("J 1:05:00 gave %+v", a)
	}
}

func TestSeekInputArgs(t *testing.T) {
	f := t.TempDir() + "/movie.mkv"
	writeFile(t, f)
	c := &Config{Source: f, seekSec: 754.5}
	a, _, _, err := videoInputArgs(c, "ffmpeg")
	if err != nil {
		t.Fatal(err)
	}
	j := strings.Join(a, " ")
	if !strings.Contains(j, "-ss 754.500 -i "+f) {
		t.Errorf("no seek before the input: %s", j)
	}
	// The re-encoded copy starts at 600 s of the movie: 154.5 s into it.
	c.playFile, c.playOffset, c.growing = t.TempDir()+"/tmp.movie.ts", 600, true
	a, _, _, _ = videoInputArgs(c, "ffmpeg")
	j = strings.Join(a, " ")
	if !strings.Contains(j, "-follow 1") || !strings.Contains(j, "-ss 154.500 -i "+c.playFile) || strings.Contains(j, "stream_loop") {
		t.Errorf("copy input: %s", j)
	}
}

func TestSubtitlesAfterSeek(t *testing.T) {
	s := &Subtitles{mode: "sidecar", cues: []subCue{{start: 600, end: 603, text: "ten minutes in"}}}
	now := time.Now()
	s.startRun(now, 599)
	if got := s.Current(now.Add(1500 * time.Millisecond)); got != "ten minutes in" {
		t.Errorf("after a jump to 9:59, 1.5 s later: %q", got)
	}
}

func TestNoticePicture(t *testing.T) {
	words := []string{"Re-encoding", "Please wait", noticeProgress(35, 4*time.Minute)}
	if words[2] != "35% - 4 MIN" {
		t.Errorf("progress line %q", words[2])
	}
	for _, sz := range [][2]int{{80, 48}, {320, 192}} {
		w, h := sz[0], sz[1]
		pic := make([]byte, w*h*3)
		for i := range pic {
			pic[i] = 150
		}
		out := noticePicture(pic, w, h, words)
		white, minX, maxX := 0, w, 0
		for y := 0; y < h; y++ {
			for x := 0; x < w; x++ {
				if out[(y*w+x)*3] == 255 {
					white++
					minX, maxX = min(minX, x), max(maxX, x)
				}
			}
		}
		if white == 0 || minX < 2 || maxX > w-3 || (minX+maxX)/2 < w/2-3 || (minX+maxX)/2 > w/2+3 {
			t.Errorf("%dx%d: %d white pixels from x %d to %d (not centred, or missing)", w, h, white, minX, maxX)
		}
		if out[0] != 50 {
			t.Errorf("%dx%d: the picture behind isn't dimmed (%d)", w, h, out[0])
		}
		if s := noticeScale(w, h, words); s != w/80 {
			t.Errorf("%dx%d: letters %dx as big, want %d", w, h, s, w/80)
		}
	}
}

func TestReencodeArgs(t *testing.T) {
	c := &Config{ReencodeWidth: 720, ReencodeCRF: 23}
	j := strings.Join(reencodeArgs(c, "in.mkv", 1234.5, "out.ts", copy720, true), " ")
	for _, want := range []string{"-ss 1234.500 -i in.mkv", "-vf scale=720:-2 -pix_fmt yuv420p -c:v libx264 -crf 23 -c:a aac -f mpegts out.ts", "-progress pipe:1"} {
		if !strings.Contains(j, want) {
			t.Errorf("720: missing %q in %s", want, j)
		}
	}
	if strings.Contains(j, "-preset") {
		t.Errorf("a preset nobody asked for: %s", j)
	}
	j = strings.Join(reencodeArgs(c, "in.mkv", 0, "out.ts", copyHalf, true), " ")
	if !strings.Contains(j, "-i in.mkv -map 0:v:0 -map 0:a:0? -sn -dn -vf scale=trunc(iw/4)*2:trunc(ih/4)*2 -pix_fmt yuv420p -c:v libx264 -c:a copy -f mpegts out.ts") || strings.Contains(j, "-ss") {
		t.Errorf("half: %s", j)
	}
	c.ReencodePreset = "veryfast"
	j = strings.Join(reencodeArgs(c, "in.mkv", 0, "out.ts", copyHalf, false), " ")
	if !strings.Contains(j, "-c:v libx264 -preset veryfast -c:a aac") {
		t.Errorf("half, AAC sound, preset: %s", j)
	}
}

func TestCopyKey(t *testing.T) {
	c := newControls(&Config{SeekStep: 5})
	for _, k := range []byte("ex2") { // x: not a choice, ignored
		c.key(k)
	}
	if a := <-c.actions; a.kind != "reencode" || a.arg != "half" {
		t.Errorf("E 2 gave %+v", a)
	}
	c.key('e')
	c.key(27)
	c.key('1') // Esc cancelled: 1 is just a key now
	select {
	case a := <-c.actions:
		t.Errorf("Esc didn't cancel: %+v", a)
	default:
	}
}

func writeFile(t *testing.T, p string) {
	t.Helper()
	if err := os.WriteFile(p, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
}

func TestTailBufferReason(t *testing.T) {
	var tb tailBuffer
	tb.Write([]byte("Stream map '0:a:0' matches no streams.\nError opening output files: Invalid argument\n"))
	if got := tb.String(); got != "Stream map '0:a:0' matches no streams. / Error opening output files: Invalid argument" {
		t.Errorf("got %q", got)
	}
}
