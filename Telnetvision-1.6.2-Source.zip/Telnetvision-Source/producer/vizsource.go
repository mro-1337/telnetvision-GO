package main

// Playing music: ffmpeg decodes the sound; it goes to the server like any
// file's sound, and the visualizer (viz.go) turns it into the picture.
// Both are stamped on the same movie clock, so they stay together.

import (
	"bufio"
	"context"
	"fmt"
	"strings"
	"sync/atomic"
	"time"
)

var audioExts = map[string]bool{
	".mp3": true, ".flac": true, ".ogg": true, ".oga": true, ".opus": true, ".m4a": true, ".aac": true,
	".wav": true, ".wma": true, ".aiff": true, ".aif": true, ".alac": true, ".ape": true, ".wv": true,
	".mka": true, ".mpc": true, ".ac3": true, ".dts": true, ".mid": false,
}

// isVisualizerSource: SOURCE=visualizer shows the visualizer for the
// microphone / line-in (AUDIO_SOURCE).
func isVisualizerSource(s string) bool {
	l := strings.ToLower(strings.TrimSpace(s))
	return l == "visualizer" || l == "visualiser" || l == "viz" || strings.HasPrefix(l, "visualizer:")
}

// curViz is the visualizer on screen now (for the V key).
var curViz atomic.Pointer[vizEngine]

// vizNext switches the visualizer to its next look; false if none is on.
func vizNext() (string, bool) {
	e := curViz.Load()
	if e == nil {
		return "", false
	}
	e.Next()
	return e.PresetName(), true
}

// runVisualizer plays sound through ffmpeg (input = its input arguments)
// with the visualizer as the picture. media: stamp sound by movie time
// (a file or stream) rather than capture time (a microphone). sendSound:
// pass the sound on to the server. once: a file, which plays to its end.
func runVisualizer(ctx context.Context, v *VideoSource, ffmpeg string, input []string, cfg *Config, clock0 time.Time,
	snd *Sender, media, sendSound, once bool, logf func(string, ...any)) error {
	rate, ch := cfg.AudioRate, cfg.AudioChannels
	if rate <= 0 {
		rate = 22050
	}
	if ch < 1 || ch > 2 {
		ch = 1
	}
	fps := cfg.FPS
	if fps <= 0 {
		fps = 15
	}
	outW, outH := v.W, v.H
	if v.HiW > 0 {
		outW, outH = v.HiW, v.HiH
	}
	e := newVizEngine(outW, outH, rate, fps, cfg.Visualizer, cfg.VizSeconds)
	e.announce = func(name string) { logf("visualizer: %s", name) }
	curViz.Store(e)
	defer curViz.CompareAndSwap(e, nil)
	logf("visualizer: %s (V for the next one)", e.PresetName())

	if once {
		input = withoutLoop(input)
	}
	args := append([]string{"-hide_banner", "-loglevel", "error", "-nostdin"}, input...)
	args = append(args, "-map", soundMap(cfg), "-vn", "-sn", "-ac", fmt.Sprint(ch), "-ar", fmt.Sprint(rate), "-f", "s16le", "-")
	cb := chunkBytes(cfg)
	backoff := time.Second
	everWorked := false
	for ctx.Err() == nil {
		tail := &tailBuffer{}
		cmd := ffmpegCommand(ctx, ffmpeg, args...)
		cmd.Stderr = tail
		out, err := cmd.StdoutPipe()
		if err == nil {
			err = cmd.Start()
		}
		if err != nil {
			return fmt.Errorf("cannot run ffmpeg: %v", err)
		}
		var clk *mediaClock
		if media {
			clk = &mediaClock{clock0: clock0}
		}
		var st *audioStamper
		if sendSound && snd != nil {
			st = newAudioStamper(cfg, clock0, snd, clk)
		}
		deliver := func(buf []byte, pts int64) {
			if v.HiW > 0 {
				v.putHi(resizeArea(buf, outW, outH, v.W, v.H), buf, pts)
			} else {
				v.putPTS(buf, pts)
			}
		}
		pace := newFramePacer(fps, deliver)
		r := bufio.NewReaderSize(out, cb*2)
		var samples, frames int64
		got := 0
		for ctx.Err() == nil {
			pcm := make([]byte, cb)
			if err := readFull(r, pcm); err != nil {
				break
			}
			if st != nil {
				st.emit(pcm)
			}
			e.feed(pcm, ch)
			samples += int64(len(pcm) / (2 * ch))
			if cfg.onPos != nil {
				cfg.onPos.set(cfg.seekSec + float64(samples)/float64(rate))
			}
			got++
			everWorked = true
			backoff = time.Second
			// The frames this sound covers, each stamped with its moment.
			due := samples * int64(fps*1000) / int64(rate) / 1000
			for ; frames < due; frames++ {
				buf := make([]byte, outW*outH*3)
				e.frame(1/fps, buf)
				pts := int64(-1)
				if clk != nil {
					pts = clk.anchor() + int64(float64(frames)*1000/fps)
				}
				pace.add(buf, pts)
			}
		}
		pace.close(ctx.Err() != nil)
		cmd.Wait()
		if ctx.Err() != nil {
			return nil
		}
		why := tail.String()
		if why == "" {
			why = "source ended"
		}
		if once {
			if got == 0 {
				return fmt.Errorf("%s", why)
			}
			return nil
		}
		if !everWorked && backoff >= 4*time.Second {
			return fmt.Errorf("sound source failed: %s", why)
		}
		logf("sound stopped (%s); restarting in %ds", why, int(backoff.Seconds()))
		select {
		case <-ctx.Done():
			return nil
		case <-time.After(backoff):
		}
		backoff *= 2
		if backoff > 30*time.Second {
			backoff = 30 * time.Second
		}
	}
	return nil
}
