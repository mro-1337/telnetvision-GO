//go:build windows

package main

import (
	"sync"
	"syscall"
	"unsafe"
)

var (
	user32                            = syscall.NewLazyDLL("user32.dll")
	procEnumDisplayMonitors           = user32.NewProc("EnumDisplayMonitors")
	procGetMonitorInfoW               = user32.NewProc("GetMonitorInfoW")
	procSetProcessDpiAwarenessContext = user32.NewProc("SetProcessDpiAwarenessContext")
	procSetProcessDPIAware            = user32.NewProc("SetProcessDPIAware")
)

type winRect struct{ Left, Top, Right, Bottom int32 }

type monitorInfoEx struct {
	Size    uint32
	Monitor winRect
	Work    winRect
	Flags   uint32
	Device  [32]uint16
}

const monitorInfoPrimary = 1

var (
	dpiOnce      sync.Once
	enumMu       sync.Mutex
	enumFound    []screenInfo
	enumCallback = syscall.NewCallback(func(hmon, hdc, rc, lparam uintptr) uintptr {
		var mi monitorInfoEx
		mi.Size = uint32(unsafe.Sizeof(mi))
		if r, _, _ := procGetMonitorInfoW.Call(hmon, uintptr(unsafe.Pointer(&mi))); r != 0 {
			enumFound = append(enumFound, screenInfo{
				X: int(mi.Monitor.Left), Y: int(mi.Monitor.Top),
				W: int(mi.Monitor.Right - mi.Monitor.Left), H: int(mi.Monitor.Bottom - mi.Monitor.Top),
				Primary: mi.Flags&monitorInfoPrimary != 0,
				Device:  syscall.UTF16ToString(mi.Device[:]),
			})
		}
		return 1 // keep going
	})
)

// dpiAware makes Windows report real pixels (not ones scaled for 125% /
// 150% display settings), which is what screen capture works in.
func dpiAware() {
	dpiOnce.Do(func() {
		if procSetProcessDpiAwarenessContext.Find() == nil {
			// DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = (HANDLE)-4
			if r, _, _ := procSetProcessDpiAwarenessContext.Call(^uintptr(3)); r != 0 {
				return
			}
		}
		if procSetProcessDPIAware.Find() == nil {
			procSetProcessDPIAware.Call()
		}
	})
}

// listScreens lists the monitors: the main one first, then left to right.
func listScreens() []screenInfo {
	dpiAware()
	enumMu.Lock()
	defer enumMu.Unlock()
	enumFound = nil
	if procEnumDisplayMonitors.Find() != nil {
		return nil
	}
	procEnumDisplayMonitors.Call(0, 0, enumCallback, 0)
	out := append([]screenInfo(nil), enumFound...)
	orderScreens(out)
	return out
}

var (
	procEnumWindows     = user32.NewProc("EnumWindows")
	procGetWindowTextW  = user32.NewProc("GetWindowTextW")
	procIsWindowVisible = user32.NewProc("IsWindowVisible")
	winTitles           []string
	enumWindowsCallback = syscall.NewCallback(func(hwnd, lparam uintptr) uintptr {
		if v, _, _ := procIsWindowVisible.Call(hwnd); v == 0 {
			return 1
		}
		var buf [512]uint16
		n, _, _ := procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), uintptr(len(buf)))
		if n > 0 {
			winTitles = append(winTitles, syscall.UTF16ToString(buf[:n]))
		}
		return 1
	})
)

// windowTitles lists the titles of the visible windows, front to back.
func windowTitles() []string {
	enumMu.Lock()
	defer enumMu.Unlock()
	winTitles = nil
	if procEnumWindows.Find() != nil {
		return nil
	}
	procEnumWindows.Call(enumWindowsCallback, 0)
	return append([]string(nil), winTitles...)
}
