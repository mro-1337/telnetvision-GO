package main

// Keyboard controls for the camera window: picture adjustments, a typing
// line for choosing a new source or a message for viewers, playlist
// skipping, and a help overlay.

import (
	"fmt"
	"math"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

// The arrow keys, as the bytes readKeys delivers for them (codes nothing
// else types).
const (
	keyLeft  = 0x1C
	keyRight = 0x1D
)

type action struct{ kind, arg string } // "switch" | "add" | "next" | "prev" | "seek"

type controls struct {
	mu       sync.Mutex
	sat      float64
	con      float64
	bri      int
	mode     string
	ramp     string
	preview  bool
	captions bool
	shuffle  bool

	prompt string // "" | "source" | "add" | "message" | "list" | "seek"
	buf    []rune
	utf    []byte // a UTF-8 character split across reads

	message      string
	messageUntil time.Time // zero: stays until cleared
	messageSec   int
	helpOn       bool
	dirty        bool // something on screen needs redrawing now
	flash        string
	flashUntil   time.Time

	actions chan action

	seekStep int // minutes the arrow keys jump (SEEK_STEP)

	toggleList func() bool // O: viewers' playlist on/off (reports the new state)
	toggleChat func() bool // W: group chat on/off for everyone (reports the new state)

	// D: the cameras (set by main); the one picked, waiting for "make it
	// the default?"; and saving it as SOURCE.
	cameras     func() []string
	camNames    []string
	pendingCam  string
	saveDefault func(src string) error
	logf        func(string, ...any)

	// The L key: lister gives the playlist's names (set by main);
	// listPrint asks for the matches to be printed (no preview window).
	lister    func() []string
	listPrint bool
}

func newControls(cfg *Config) *controls {
	return &controls{sat: cfg.Saturation, con: cfg.Contrast, bri: cfg.Brightness,
		mode: cfg.Mode, ramp: cfg.Ramp, captions: true, shuffle: cfg.Shuffle, messageSec: cfg.MessageSec,
		actions: make(chan action, 8), seekStep: cfg.SeekStep}
}

func (c *controls) captionsOn() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.captions
}

func (c *controls) snapshot() (float64, float64, int, string, string, bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.sat, c.con, c.bri, c.mode, c.ramp, c.preview
}

// currentMessage is the typed message to show viewers now ("" for none).
func (c *controls) currentMessage(now time.Time) string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.message != "" && !c.messageUntil.IsZero() && now.After(c.messageUntil) {
		c.message, c.dirty = "", true
	}
	return c.message
}

// promptLine returns the typing line being edited, if any.
func (c *controls) promptLine() (label, text string, on bool) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if c.prompt == "" {
		return "", "", false
	}
	return promptLabels[c.prompt], string(c.buf), true
}

var promptLabels = map[string]string{
	"source":  "Play (file, folder, URL, .m3u, YouTube, camera, screen2, visualizer): ",
	"add":     "Add file, folder, channel list or YouTube link: ",
	"list":    "Channel (number or name, Enter plays): ",
	"message": "Message for viewers (empty = clear): ",
	"seek":    "Go to (1:05:00, 45:00, 90 = minutes, +10 / -5 = minutes from here): ",
	"copy":    "Re-encode to a temp file: 1 = 720 wide H.264, 2 = half size, 0 = original (Esc cancels) ",
	"camera":  "Camera number, then Enter (Esc cancels): ",
	"savecam": "Make it the default camera (SOURCE in telnetvision.ini)? Y = yes, any other key = no ",
}

// flashText is a short note shown on the status line after a key press.
func (c *controls) flashText() string {
	c.mu.Lock()
	defer c.mu.Unlock()
	if time.Now().After(c.flashUntil) {
		return ""
	}
	return c.flash
}

func (c *controls) helpShown() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.helpOn
}

// takeDirty reports (and clears) whether the screen needs redrawing.
func (c *controls) takeDirty() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	d := c.dirty
	c.dirty = false
	return d
}

func (c *controls) markDirty() {
	c.mu.Lock()
	c.dirty = true
	c.mu.Unlock()
}

func round1(v float64) float64 { return float64(int(v*10+0.5*sign(v))) / 10 }
func sign(v float64) float64 {
	if v < 0 {
		return -1
	}
	return 1
}

func (c *controls) send(a action) {
	select {
	case c.actions <- a:
	default:
	}
}

// key applies one input byte; returns true to quit.
func (c *controls) key(k byte) bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dirty = true
	if c.prompt != "" {
		c.typed(k)
		return false
	}
	switch k {
	case '+', '=':
		c.sat = round1(min(3, c.sat+0.1))
	case '-', '_':
		c.sat = round1(max(0, c.sat-0.1))
	case ']':
		c.con = round1(min(3, c.con+0.1))
	case '[':
		c.con = round1(max(0.1, c.con-0.1))
	case '.', '>':
		c.bri = min(128, c.bri+8)
	case ',', '<':
		c.bri = max(-128, c.bri-8)
	case 'm', 'M':
		c.mode = map[string]string{"half": "ramp", "ramp": "half"}[c.mode]
	case 'g', 'G':
		c.ramp = map[string]string{"ascii": "shades", "shades": "ascii"}[c.ramp]
	case '0':
		c.sat, c.con, c.bri = 1, 1, 0
	case 'p', 'P':
		c.preview = !c.preview
	case 'c', 'C':
		c.captions = !c.captions
	case 's', 'S':
		c.prompt, c.buf = "source", nil
	case 'l', 'L':
		if c.lister == nil || len(c.lister()) == 0 {
			c.flash, c.flashUntil = "the list (L) is for playlists: files, a folder, a channel list or YouTube", time.Now().Add(4*time.Second)
			break
		}
		c.prompt, c.buf, c.listPrint = "list", nil, true
	case 'a', 'A':
		c.prompt, c.buf = "add", nil
	case 't', 'T':
		c.prompt, c.buf = "message", []rune(c.message)
	case 'x', 'X':
		if c.message != "" {
			c.flash, c.flashUntil = "message cleared", time.Now().Add(3*time.Second)
		}
		c.message = ""
	case 'w', 'W':
		if c.toggleChat != nil {
			on := c.toggleChat()
			c.flash, c.flashUntil = map[bool]string{true: "group chat on: viewers can open the chat (N)", false: "group chat off for everyone"}[on], time.Now().Add(3*time.Second)
		}
	case 'o', 'O':
		if c.toggleList != nil {
			on := c.toggleList()
			c.flash, c.flashUntil = map[bool]string{true: "viewers can pick from the playlist (L)", false: "viewers' playlist off"}[on], time.Now().Add(3*time.Second)
		}
	case 'r', 'R':
		c.shuffle = !c.shuffle
		on := map[bool]string{true: "on", false: "off"}[c.shuffle]
		c.send(action{kind: "shuffle", arg: on})
		c.flash, c.flashUntil = "shuffle "+on, time.Now().Add(3*time.Second)
	case 'n', 'N':
		c.send(action{kind: "next"})
		c.flash, c.flashUntil = ">> skipping to the next video...", time.Now().Add(2*time.Second)
	case 'b', 'B':
		c.send(action{kind: "prev"})
		c.flash, c.flashUntil = "<< going back a video...", time.Now().Add(2*time.Second)
	case 'j', 'J':
		c.prompt, c.buf = "seek", nil
	case 'e', 'E':
		c.prompt, c.buf = "copy", nil
	case 'd', 'D':
		if c.cameras == nil {
			break
		}
		c.flash, c.flashUntil = "looking for cameras...", time.Now().Add(5*time.Second)
		go c.showCameras()
	case keyRight, keyLeft:
		step := max(1, c.seekStep)
		arg, word := fmt.Sprintf("+%d", step*60), "ahead"
		if k == keyLeft {
			arg, word = fmt.Sprintf("-%d", step*60), "back"
		}
		c.send(action{kind: "seek", arg: arg})
		c.flash, c.flashUntil = fmt.Sprintf("%s %d min...", word, step), time.Now().Add(2*time.Second)
	case 'v', 'V':
		c.send(action{kind: "viz"})
		c.flash, c.flashUntil = "visualizer: next look (music only)", time.Now().Add(3*time.Second)
	case 'h', 'H', '?':
		c.helpOn = !c.helpOn
	case 27: // Esc closes the help; it never quits, so a stray Esc can't end the broadcast
		c.helpOn = false
	case 'q', 'Q':
		if c.helpOn {
			c.helpOn = false // with the help open, Q just closes it
			return false
		}
		return true
	}
	return false
}

// paste takes a burst of typed text - a file or folder dropped on the
// window, or a paste - and reports whether it handled it. With a typing
// line open the text goes into it; otherwise it opens the Play line with
// the path filled in, ready for Enter (or Esc to cancel).
func (c *controls) paste(b []byte) bool {
	printable := 0
	for _, k := range b {
		if k >= 32 && k != 127 {
			printable++
		}
	}
	if printable < 4 { // a person typing: one or two keys at a time
		return false
	}
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dirty = true
	if c.prompt != "" {
		for _, k := range b {
			c.typed(k)
		}
		return true
	}
	text := strings.TrimSpace(strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return -1
		}
		return r
	}, string(b)))
	text = strings.Trim(text, `"`) // Explorer quotes paths with spaces
	if text == "" {
		return true
	}
	c.prompt, c.buf, c.utf = "source", []rune(text), nil
	c.flash, c.flashUntil = "Dropped: press Enter to play it now, Esc to cancel", time.Now().Add(6*time.Second)
	return true
}

// pasteText puts pasted text in: into the typing line if one is open,
// otherwise it opens the Play line with it, ready for Enter. Only the
// first line counts (a copied line often ends with a line break).
func (c *controls) pasteText(text string) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.dirty = true
	if i := strings.IndexAny(text, "\r\n"); i >= 0 {
		rest := strings.TrimSpace(text[i:])
		text = text[:i]
		if strings.TrimSpace(text) == "" {
			text = rest
			if j := strings.IndexAny(text, "\r\n"); j >= 0 {
				text = text[:j]
			}
		}
	}
	text = strings.Map(func(r rune) rune {
		if r < 32 || r == 127 {
			return -1
		}
		return r
	}, text)
	if strings.TrimSpace(text) == "" {
		c.flash, c.flashUntil = "nothing to paste: the clipboard has no text", time.Now().Add(3*time.Second)
		return
	}
	if c.prompt != "" {
		for _, r := range text {
			if len(c.buf) < 1000 {
				c.buf = append(c.buf, r)
			}
		}
		return
	}
	text = strings.Trim(strings.TrimSpace(text), `"`)
	c.prompt, c.buf, c.utf = "source", []rune(text), nil
	c.flash, c.flashUntil = "Pasted: press Enter to play it now, Esc to cancel", time.Now().Add(6*time.Second)
}

// typed edits the typing line. Called with c.mu held.
func (c *controls) typed(k byte) {
	c.utf = append(c.utf, k)
	for len(c.utf) > 0 {
		if !utf8.FullRune(c.utf) {
			return // wait for the rest of this character
		}
		r, size := utf8.DecodeRune(c.utf)
		c.utf = c.utf[size:]
		if c.prompt == "savecam" {
			// One key: Y saves, anything else doesn't.
			src := c.pendingCam
			c.prompt, c.buf, c.utf, c.pendingCam = "", nil, nil, ""
			if r != 'y' && r != 'Y' {
				c.flash, c.flashUntil = "not saved: "+src+" plays until telnetvision closes", time.Now().Add(4*time.Second)
				return
			}
			if err := c.saveDefault(src); err != nil {
				c.flash, c.flashUntil = "couldn't save it: "+err.Error(), time.Now().Add(6*time.Second)
				return
			}
			c.flash, c.flashUntil = "saved: SOURCE="+src+" (the default from now on)", time.Now().Add(5*time.Second)
			if c.logf != nil {
				go c.logf("saved SOURCE=%s in telnetvision.ini: it's the default from now on", src) // (not under c.mu)
			}
			return
		}
		if c.prompt == "copy" && r != 27 {
			// One key picks (no Enter needed).
			mode := map[rune]string{'1': "720", '2': "half", '0': "off"}[r]
			if mode == "" {
				continue
			}
			c.prompt, c.buf, c.utf = "", nil, nil
			c.send(action{kind: "reencode", arg: mode})
			c.flash, c.flashUntil = map[string]string{"720": "re-encoding to a 720-pixel copy...", "half": "re-encoding to a half-size copy...", "off": "back to the original file..."}[mode], time.Now().Add(3*time.Second)
			return
		}
		switch {
		case r == '\r' || r == '\n':
			c.commit()
			return
		case r == 27: // Esc: cancel
			c.prompt, c.buf, c.utf = "", nil, nil
			return
		case r == 8 || r == 127: // Backspace
			if len(c.buf) > 0 {
				c.buf = c.buf[:len(c.buf)-1]
			}
		case r == 21: // Ctrl+U: clear the line
			c.buf = nil
		case r == 9 && c.prompt == "list": // Tab: print the matches again
			c.listPrint = true
		case r == utf8.RuneError && size == 1, r < 32:
			// ignore other control keys
		default:
			if len(c.buf) < 1000 {
				c.buf = append(c.buf, r)
			}
		}
	}
}

// commit finishes the typing line. Called with c.mu held.
func (c *controls) commit() {
	text := strings.TrimSpace(string(c.buf))
	kind := c.prompt
	c.prompt, c.buf, c.utf = "", nil, nil
	switch kind {
	case "message":
		c.message = text
		c.messageUntil = time.Time{}
		if text != "" && c.messageSec > 0 {
			c.messageUntil = time.Now().Add(time.Duration(c.messageSec) * time.Second)
		}
		switch {
		case text == "":
			c.flash = "message cleared"
		case c.messageSec > 0:
			c.flash = fmt.Sprintf("message on viewers' screens for %d s (X clears)", c.messageSec)
		default:
			c.flash = "message on viewers' screens until you clear it (X)"
		}
		c.flashUntil = time.Now().Add(4 * time.Second)
	case "source":
		if text != "" {
			c.send(action{kind: "switch", arg: text})
		}
	case "add":
		if text != "" {
			c.send(action{kind: "add", arg: text})
		}
	case "camera":
		var n int
		if _, err := fmt.Sscan(text, &n); err != nil || n < 1 || n > len(c.camNames) {
			if text != "" {
				c.flash, c.flashUntil = fmt.Sprintf("there's no camera %q: type a number from the list (1-%d)", text, len(c.camNames)), time.Now().Add(4*time.Second)
			}
			return
		}
		src := "camera:" + c.camNames[n-1]
		c.send(action{kind: "switch", arg: src})
		if c.saveDefault != nil {
			c.prompt, c.pendingCam = "savecam", src // asked next: make it the default?
		}
		c.flash, c.flashUntil = ">> "+src, time.Now().Add(3*time.Second)
	case "seek":
		if text == "" {
			return
		}
		arg, ok := parseSeekTime(text)
		if !ok {
			c.flash, c.flashUntil = fmt.Sprintf("%q isn't a time: try 1:05:00, 45:00, 90 (minutes), +10 or -5", text), time.Now().Add(5*time.Second)
			return
		}
		c.send(action{kind: "seek", arg: arg})
		c.flash, c.flashUntil = "going to "+describeSeek(arg)+"...", time.Now().Add(3*time.Second)
	case "list":
		if text == "" || c.lister == nil {
			return
		}
		names := c.lister()
		i, ok := pickEntry(names, text)
		if !ok {
			c.flash, c.flashUntil = fmt.Sprintf("nothing in the list matches %q", text), time.Now().Add(4*time.Second)
			return
		}
		c.send(action{kind: "goto", arg: fmt.Sprint(i + 1)})
		c.flash, c.flashUntil = fmt.Sprintf(">> %d %s", i+1, names[i]), time.Now().Add(3*time.Second)
	}
}

// pickEntry is the entry a typed number or name means: a number is its
// place in the list; otherwise the first name containing all the words.
func pickEntry(names []string, text string) (int, bool) {
	t := strings.TrimSpace(text)
	if isDigits(t) {
		var n int
		fmt.Sscan(t, &n)
		return n - 1, n >= 1 && n <= len(names)
	}
	if m := matchEntries(names, t); len(m) > 0 {
		return m[0], true
	}
	return 0, false
}

// listLines is the L key's view: the entries matching what's typed so
// far, numbered, at most max of them.
func (c *controls) listLines(max int) []string {
	c.mu.Lock()
	on, q, lister := c.prompt == "list", string(c.buf), c.lister
	c.mu.Unlock()
	if !on || lister == nil {
		return nil
	}
	names := lister()
	var m []int
	if isDigits(strings.TrimSpace(q)) {
		if i, ok := pickEntry(names, q); ok {
			m = []int{i}
		}
	} else {
		m = matchEntries(names, q)
	}
	out := []string{fmt.Sprintf(" %d of %d - type to search, Enter plays, Esc cancels", len(m), len(names))}
	for k, i := range m {
		if k == max {
			out = append(out, fmt.Sprintf("   ... and %d more: type more of the name", len(m)-max))
			break
		}
		out = append(out, fmt.Sprintf(" %5d  %s", i+1, names[i]))
	}
	return out
}

// takeListPrint reports (and clears) whether the list should be printed.
func (c *controls) takeListPrint() bool {
	c.mu.Lock()
	defer c.mu.Unlock()
	p := c.listPrint && c.prompt == "list"
	c.listPrint = false
	return p
}

var helpLines = padLines([]string{
	" KEYS                                      H or Esc closes ",
	"",
	"  S    Play something else: file, folder, music, URL,",
	"       IPTV list (.m3u), YouTube, camera, screen1, screen2,",
	"       window:Title, visualizer (for the microphone)",
	"  A    Add to the end of the playlist",
	"  N    Next video / channel    B    Back one",
	"  L    List the playlist: pick by number or name",
	"  R    Shuffle on / off        V    Next visualizer look",
	"  O    Viewers' playlist (their L key) on / off",
	"  W    Group chat (viewers' chat, their N key) on / off",
	"  D    Cameras: list them, pick one, save it as the default",
	"  J    Jump to a time in the video (1:05:00, 45:00, +10)",
	"  <- ->  Back / ahead 5 minutes (SEEK_STEP)",
	"  E    Re-encode the movie to a temp file and play that",
	"       (1 = 720 wide H.264, 2 = half size, 0 = original)",
	"",
	"  T    Type a message for viewers (Enter shows it)",
	"  X    Clear the message",
	"",
	"  C    Captions on / off       P    Preview on / off",
	"  + -  Saturation              [ ]  Contrast",
	"  < >  Brightness              0    Reset the picture",
	"  M    Block / text style      G    Text characters",
	"",
	"  Q    Quit",
	"",
	"  Tip: drop a file or folder on this window, or paste",
	"  (Ctrl+V, Shift+Insert or right-click), then Enter.",
})

// padLines makes every line the same width, so the help box is even.
func padLines(l []string) []string {
	w := 0
	for _, s := range l {
		if len(s) > w {
			w = len(s)
		}
	}
	for i, s := range l {
		l[i] = s + strings.Repeat(" ", w+1-len(s))
	}
	return l
}

// combineCaption puts a typed message above the subtitles, keeping the
// whole caption to three lines.
func combineCaption(message string, caption []byte) []byte {
	if message == "" {
		return caption
	}
	if len(caption) == 0 {
		return []byte(message)
	}
	lines := strings.Split(string(caption), "\n")
	if len(lines) > 2 {
		lines = lines[len(lines)-2:]
	}
	return []byte(message + "\n" + strings.Join(lines, "\n"))
}

// parseSeekTime reads a time typed for J. It returns "=S" for a place in
// the video or "+S" / "-S" for a jump from where it is now, in seconds:
//
//	1:05:00  45:00  1:30     hours:minutes:seconds, minutes:seconds
//	90  90m  1h30m  45s  1h  a plain number is minutes
//	+10  -5  +30s  -1:00     from here (a plain number is minutes)
func parseSeekTime(text string) (string, bool) {
	t := strings.ToLower(strings.Join(strings.Fields(text), ""))
	sign := "="
	if strings.HasPrefix(t, "+") || strings.HasPrefix(t, "-") {
		sign, t = t[:1], t[1:]
	}
	if t == "" {
		return "", false
	}
	var secs float64
	switch {
	case strings.Contains(t, ":"):
		parts := strings.Split(t, ":")
		if len(parts) > 3 {
			return "", false
		}
		for i, p := range parts {
			n, err := strconv.ParseFloat(p, 64)
			if err != nil || n < 0 || p == "" || (i > 0 && n >= 60) {
				return "", false
			}
			secs = secs*60 + n
		}
	case strings.ContainsAny(t, "hms"):
		rest := t
		for rest != "" {
			i := strings.IndexAny(rest, "hms")
			if i <= 0 {
				return "", false
			}
			n, err := strconv.ParseFloat(rest[:i], 64)
			if err != nil || n < 0 {
				return "", false
			}
			secs += n * map[byte]float64{'h': 3600, 'm': 60, 's': 1}[rest[i]]
			rest = rest[i+1:]
		}
	default:
		n, err := strconv.ParseFloat(t, 64)
		if err != nil || n < 0 {
			return "", false
		}
		secs = n * 60 // a plain number is minutes
	}
	if math.IsInf(secs, 0) || math.IsNaN(secs) || secs > 1e7 {
		return "", false
	}
	return sign + strconv.FormatFloat(math.Round(secs*10)/10, 'f', -1, 64), true
}

// describeSeek says what parseSeekTime's answer means ("1:05:00",
// "5 min ahead").
func describeSeek(arg string) string {
	s, _ := strconv.ParseFloat(arg[1:], 64)
	switch arg[0] {
	case '+':
		return clockTime(s) + " ahead"
	case '-':
		return clockTime(s) + " back"
	}
	return clockTime(s)
}

// clockTime is seconds as h:mm:ss (or m:ss under an hour).
func clockTime(s float64) string {
	if s < 0 {
		s = 0
	}
	n := int(s + 0.5)
	if n >= 3600 {
		return fmt.Sprintf("%d:%02d:%02d", n/3600, n/60%60, n%60)
	}
	return fmt.Sprintf("%d:%02d", n/60, n%60)
}

// showCameras lists the cameras in the window and asks which one (D).
func (c *controls) showCameras() {
	names := c.cameras()
	c.mu.Lock()
	busy := c.prompt != ""
	if len(names) == 0 {
		c.flash, c.flashUntil = "no cameras found (telnetvision.exe --list-devices lists what Windows has)", time.Now().Add(5*time.Second)
	}
	c.mu.Unlock()
	if len(names) == 0 || busy {
		return // none, or busy typing something else meanwhile
	}
	if c.logf != nil {
		c.logf("cameras (type the number and Enter):")
		for i, n := range names {
			c.logf("  %d  %s", i+1, n)
		}
	}
	c.mu.Lock()
	if c.prompt == "" {
		c.camNames, c.prompt, c.buf, c.flash = names, "camera", nil, ""
	}
	c.dirty = true
	c.mu.Unlock()
}
