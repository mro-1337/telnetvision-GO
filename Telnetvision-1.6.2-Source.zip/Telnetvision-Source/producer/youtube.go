package main

// YouTube, through yt-dlp.exe (which must be next to telnetvision.exe or
// on PATH). A channel plays its live stream while it's on air, otherwise
// its recent uploads as a playlist; while the uploads play, the channel is
// checked every few minutes and the live stream takes over when it starts.
// A playlist link plays that playlist; a video link plays that video.
//
// yt-dlp is only used to find each video's stream address; ffmpeg plays
// it like any other stream. Addresses expire after a few hours, so they
// are looked up just before each video plays.

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"net/url"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

// ytLiveCheck is how often a channel is checked for going live.
var ytLiveCheck = 5 * time.Minute

const (
	ytMaxUploads = 50 // recent uploads to play from a channel

	// Picture and sound in one stream if the video has one at <=480p;
	// otherwise (most videos now) picture and sound as two streams, which
	// ffmpeg plays together. H.264 first: the cheapest to decode.
	ytFormat = "b[height<=480]" +
		"/bv*[height<=480][vcodec^=avc1]+ba" +
		"/bv*[height<=480]+ba" +
		"/bv*[height<=720]+ba" +
		"/b/bv*+ba/best"
	ytDownloadURL = "https://github.com/yt-dlp/yt-dlp/releases/latest"
)

var errNoYtDlp = errors.New("YouTube needs yt-dlp.exe. Download it from " + ytDownloadURL +
	" (yt-dlp.exe; on 32-bit Windows yt-dlp_x86.exe) and put it in the same folder as telnetvision.exe")

// findYtDlp finds yt-dlp next to this program or on PATH.
func findYtDlp() (string, error) {
	names := []string{"yt-dlp"}
	if runtime.GOOS == "windows" {
		names = []string{"yt-dlp.exe", "yt-dlp_x86.exe", "yt-dlp_win7.exe"}
	}
	for _, n := range names {
		if p := filepath.Join(exeDir(), n); fileExists(p) {
			return p, nil
		}
	}
	for _, n := range append(names, "yt-dlp") {
		if p, err := exec.LookPath(n); err == nil {
			return p, nil
		}
	}
	return "", errNoYtDlp
}

// isYouTubeURL reports whether s is a youtube.com or youtu.be link.
func isYouTubeURL(s string) bool {
	if !isURL(s) {
		return false
	}
	u, err := url.Parse(strings.TrimSpace(s))
	if err != nil {
		return false
	}
	h := strings.TrimPrefix(strings.ToLower(u.Hostname()), "www.")
	return h == "youtube.com" || h == "m.youtube.com" || h == "music.youtube.com" ||
		h == "youtu.be" || h == "youtube-nocookie.com"
}

// youTubeKind sorts a YouTube link: "channel" (base is the channel's
// address without a tab), "playlist", or "video".
func youTubeKind(s string) (kind, base string) {
	u, err := url.Parse(strings.TrimSpace(s))
	if err != nil {
		return "video", s
	}
	h := strings.TrimPrefix(strings.ToLower(u.Hostname()), "www.")
	// A video opened from a playlist (watch?v=...&list=..., youtu.be/x?list=)
	// plays the whole playlist, from that video on.
	if u.Query().Get("list") != "" {
		return "playlist", s
	}
	if h == "youtu.be" {
		return "video", s
	}
	parts := strings.Split(strings.Trim(u.Path, "/"), "/")
	first := ""
	if len(parts) > 0 {
		first = parts[0]
	}
	switch {
	case first == "watch" || first == "live" && len(parts) > 1 || first == "shorts" || first == "embed":
		return "video", s
	case first == "playlist":
		return "playlist", s
	case strings.HasPrefix(first, "@"):
		return "channel", "https://www.youtube.com/" + first
	case (first == "channel" || first == "c" || first == "user") && len(parts) > 1:
		return "channel", "https://www.youtube.com/" + first + "/" + parts[1]
	}
	return "video", s
}

// ytRun runs yt-dlp and returns its output lines, or its own error message.
func ytRun(ctx context.Context, timeout time.Duration, args ...string) ([]string, error) {
	ytdlp, err := findYtDlp()
	if err != nil {
		return nil, err
	}
	ctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()
	cmd := ffmpegCommand(ctx, ytdlp, append([]string{"--no-warnings", "--no-progress", "--ignore-config", "--encoding", "utf-8"}, args...)...)
	var out, errb bytes.Buffer
	cmd.Stdout, cmd.Stderr = &out, &errb
	runErr := cmd.Run()
	var lines []string
	for _, l := range strings.Split(strings.ReplaceAll(out.String(), "\r", ""), "\n") {
		if l = strings.TrimSpace(l); l != "" {
			lines = append(lines, l)
		}
	}
	if runErr != nil && len(lines) == 0 {
		if ctx.Err() == context.DeadlineExceeded {
			return nil, errors.New("yt-dlp took too long")
		}
		if ctx.Err() != nil {
			return nil, ctx.Err()
		}
		msg := lastLine(errb.String())
		if msg == "" {
			msg = runErr.Error()
		}
		return nil, errors.New(strings.TrimPrefix(msg, "ERROR: "))
	}
	return lines, nil
}

func lastLine(s string) string {
	lines := strings.Split(strings.TrimSpace(strings.ReplaceAll(s, "\r", "")), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		if l := strings.TrimSpace(lines[i]); l != "" {
			return l
		}
	}
	return ""
}

// ytList reads a channel tab or playlist without opening each video.
func ytList(ctx context.Context, listURL string, max int) ([]entry, error) {
	lines, err := ytRun(ctx, 90*time.Second, "--yes-playlist", "--flat-playlist", "--playlist-end", fmt.Sprint(max),
		"--print", "%(id)s\t%(title)s", listURL)
	if err != nil {
		return nil, err
	}
	var out []entry
	for _, l := range lines {
		id, title, _ := strings.Cut(l, "\t")
		if id == "" || id == "NA" || strings.HasPrefix(id, "UC") && len(id) == 24 {
			continue // not a video (a channel tab inside a channel page)
		}
		if title == "NA" {
			title = ""
		}
		out = append(out, entry{src: "https://www.youtube.com/watch?v=" + id, name: title, kind: entYouTube})
	}
	return out, nil
}

// ytLiveNow returns the channel's live stream, if it's on air now.
func ytLiveNow(ctx context.Context, channel string) (entry, bool) {
	lines, err := ytRun(ctx, 60*time.Second, "--no-playlist", "--print", "%(live_status)s\t%(id)s\t%(title)s", channel+"/live")
	if err != nil || len(lines) == 0 {
		return entry{}, false
	}
	f := strings.SplitN(lines[0], "\t", 3)
	if len(f) < 3 || f[0] != "is_live" {
		return entry{}, false
	}
	return entry{src: "https://www.youtube.com/watch?v=" + f[1], name: f[2], kind: entYouTube}, true
}

// expandYouTube turns a YouTube link into a playlist. channel is set for
// a channel link (it's checked for going live while its uploads play).
func expandYouTube(ctx context.Context, src string, logf func(string, ...any)) (list []entry, channel string, err error) {
	if _, err := findYtDlp(); err != nil {
		return nil, "", err
	}
	kind, base := youTubeKind(src)
	switch kind {
	case "channel":
		logf("YouTube: checking %s ...", base)
		live, isLive := ytLiveNow(ctx, base)
		ups, upErr := ytList(ctx, base+"/videos", ytMaxUploads)
		if len(ups) == 0 {
			if more, err := ytList(ctx, base+"/streams", ytMaxUploads); err == nil {
				ups = more
			}
		}
		if isLive {
			list = append(list, live)
		}
		list = append(list, ups...)
		if len(list) == 0 {
			if upErr != nil {
				return nil, "", fmt.Errorf("YouTube: %v", upErr)
			}
			return nil, "", fmt.Errorf("YouTube: %s isn't live and has no videos", base)
		}
		if isLive {
			logf("YouTube: the channel is live now: %s (%d uploads after it)", live.name, len(ups))
		} else {
			logf("YouTube: the channel isn't live; playing its %d most recent videos", len(ups))
		}
		return list, base, nil
	case "playlist":
		ups, err := ytList(ctx, src, 500)
		if err != nil {
			return nil, "", fmt.Errorf("YouTube: %v", err)
		}
		if len(ups) == 0 {
			return nil, "", errors.New("YouTube: the playlist is empty")
		}
		// Start at the video the link was opened on; the rest follow, and
		// the ones before it come round after the end.
		if v := ytVideoID(src); v != "" {
			for i, e := range ups {
				if strings.HasSuffix(e.src, "v="+v) && i > 0 {
					ups = append(ups[i:], ups[:i]...)
					break
				}
			}
		}
		logf("YouTube: playlist of %d videos", len(ups))
		return ups, "", nil
	}
	return []entry{{src: src, kind: entYouTube}}, "", nil
}

// ytResolve finds a video's stream address for ffmpeg (360p-480p is
// plenty for a terminal). audio is set when the sound is a separate stream.
func ytResolve(ctx context.Context, page string) (stream, audio, title string, live bool, err error) {
	lines, err := ytRun(ctx, 90*time.Second, "--no-playlist", "-f", ytFormat,
		"--print", "%(live_status)s\t%(title)s", "--print", "urls", page)
	if err != nil {
		msg := err.Error()
		if strings.Contains(msg, "format is not available") || strings.Contains(msg, "Sign in") ||
			strings.Contains(msg, "JavaScript") || strings.Contains(msg, "n challenge") {
			msg += " - update yt-dlp (run: yt-dlp.exe -U) and install Deno (winget install DenoLand.Deno); YouTube needs both now"
		}
		return "", "", "", false, fmt.Errorf("YouTube: %s", msg)
	}
	if len(lines) < 2 {
		return "", "", "", false, errors.New("YouTube: yt-dlp found no playable stream")
	}
	st, title, _ := strings.Cut(lines[0], "\t")
	if title == "NA" {
		title = ""
	}
	stream = lines[1]
	if !isURL(stream) {
		return "", "", "", false, errors.New("YouTube: yt-dlp gave no stream address")
	}
	if len(lines) > 2 && isURL(lines[2]) {
		audio = lines[2]
	}
	if strings.Contains(st, "upcoming") {
		return "", "", title, false, errors.New("YouTube: that stream hasn't started yet")
	}
	return stream, audio, title, st == "is_live", nil
}

// ytVideoID is the video a link points at (watch?v=ID or youtu.be/ID).
func ytVideoID(s string) string {
	u, err := url.Parse(strings.TrimSpace(s))
	if err != nil {
		return ""
	}
	if v := u.Query().Get("v"); v != "" {
		return v
	}
	if strings.EqualFold(strings.TrimPrefix(u.Hostname(), "www."), "youtu.be") {
		return strings.Trim(u.Path, "/")
	}
	return ""
}
