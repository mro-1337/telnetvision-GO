package main

import (
	"bufio"
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"math"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

// ffmpegCommand starts ffmpeg tied to ctx. When ctx ends, ffmpeg and
// anything it started are stopped (killTree), and Wait gives up on its
// output pipes after a few seconds, so skipping or switching sources can
// never hang - even with an ffmpeg.exe that is a launcher for another one
// (package-manager shims do that).
func ffmpegCommand(ctx context.Context, ffmpeg string, args ...string) *exec.Cmd {
	cmd := exec.CommandContext(ctx, ffmpeg, args...)
	hideWindow(cmd)
	cmd.Cancel = func() error { return killTree(cmd) }
	cmd.WaitDelay = 3 * time.Second
	return cmd
}

// findFFmpeg returns the ffmpeg to run: the configured path, else
// ffmpeg.exe next to this program, else the one on PATH.
func findFFmpeg(cfg *Config) (string, error) {
	if cfg.FFmpeg != "" {
		if _, err := os.Stat(cfg.FFmpeg); err == nil {
			return cfg.FFmpeg, nil
		}
		if p, err := exec.LookPath(cfg.FFmpeg); err == nil {
			return p, nil
		}
		return "", fmt.Errorf("FFMPEG=%s was not found", cfg.FFmpeg)
	}
	name := "ffmpeg"
	if runtime.GOOS == "windows" {
		name = "ffmpeg.exe"
	}
	local := filepath.Join(exeDir(), name)
	if _, err := os.Stat(local); err == nil {
		return local, nil
	}
	if p, err := exec.LookPath("ffmpeg"); err == nil {
		return p, nil
	}
	if _, err := os.Stat(jxlFFmpegPath()); err == nil {
		return jxlFFmpegPath(), nil // downloaded for JPEG XL
	}
	return "", errors.New("ffmpeg.exe was not found. Put ffmpeg.exe in the same folder as telnetvision.exe")
}

// Device is a DirectShow capture device.
type Device struct {
	Name string
	Kind string // "video" or "audio"
}

var quoted = regexp.MustCompile(`"([^"]+)"`)

// listDevices asks ffmpeg for the DirectShow device list (Windows only).
// Handles both the newer "name" (video) format and the older section-header
// format ("DirectShow video devices" / "DirectShow audio devices").
func listDevices(ffmpeg string) ([]Device, error) {
	if runtime.GOOS != "windows" {
		return nil, nil
	}
	cmd := exec.Command(ffmpeg, "-hide_banner", "-nostdin", "-list_devices", "true", "-f", "dshow", "-i", "dummy")
	hideWindow(cmd)
	out, _ := cmd.CombinedOutput() // always exits non-zero ("dummy" isn't a device)
	return parseDeviceList(out), nil
}

func parseDeviceList(out []byte) []Device {
	var devs []Device
	section := ""
	sc := bufio.NewScanner(bytes.NewReader(out))
	for sc.Scan() {
		line := sc.Text()
		low := strings.ToLower(line)
		switch {
		case strings.Contains(low, "directshow video devices"):
			section = "video"
			continue
		case strings.Contains(low, "directshow audio devices"):
			section = "audio"
			continue
		case strings.Contains(low, "alternative name"):
			continue
		}
		m := quoted.FindStringSubmatch(line)
		if m == nil {
			continue
		}
		kind := section
		if strings.Contains(low, "(video)") {
			kind = "video"
		} else if strings.Contains(low, "(audio)") {
			kind = "audio"
		} else if strings.Contains(low, "(none)") {
			continue
		}
		if kind == "" {
			continue
		}
		devs = append(devs, Device{Name: m[1], Kind: kind})
	}
	return devs
}

func firstDevice(devs []Device, kind string) string {
	for _, d := range devs {
		if d.Kind == kind {
			return d.Name
		}
	}
	return ""
}

// matchDevice resolves a full name or case-insensitive substring.
func matchDevice(devs []Device, kind, want string) string {
	for _, d := range devs {
		if d.Kind == kind && d.Name == want {
			return d.Name
		}
	}
	low := strings.ToLower(want)
	for _, d := range devs {
		if d.Kind == kind && strings.Contains(strings.ToLower(d.Name), low) {
			return d.Name
		}
	}
	return ""
}

func isURL(s string) bool {
	return strings.Contains(s, "://")
}

// videoInputArgs turns SOURCE into ffmpeg input arguments. It returns
// whether the image should be mirrored when FLIP=auto.
func videoInputArgs(cfg *Config, ffmpeg string) (args []string, autoFlip bool, desc string, err error) {
	src := strings.TrimSpace(cfg.Source)
	low := strings.ToLower(src)
	fps := strconv.FormatFloat(cfg.FPS, 'f', -1, 64)
	switch {
	case low == "camera" || strings.HasPrefix(low, "camera:") || isDigits(src):
		if runtime.GOOS != "windows" {
			if runtime.GOOS == "linux" {
				dev := "/dev/video0"
				if isDigits(src) {
					dev = "/dev/video" + src
				}
				return []string{"-f", "v4l2", "-i", dev}, low == "camera", "webcam " + dev, nil
			}
			return []string{"-f", "avfoundation", "-framerate", "30", "-i", "0"}, low == "camera", "webcam", nil
		}
		devs, _ := listDevices(ffmpeg)
		name := ""
		switch {
		case strings.HasPrefix(low, "camera:"):
			want := strings.TrimSpace(src[len("camera:"):])
			if name = matchDevice(devs, "video", want); name == "" {
				return nil, false, "", fmt.Errorf("no camera matching %q (run with --list-devices to see them)", want)
			}
		case isDigits(src):
			idx, _ := strconv.Atoi(src)
			var vids []string
			for _, d := range devs {
				if d.Kind == "video" {
					vids = append(vids, d.Name)
				}
			}
			if idx >= len(vids) {
				return nil, false, "", fmt.Errorf("camera #%s not found; %d camera(s) detected", src, len(vids))
			}
			name = vids[idx]
		default:
			if name = firstDevice(devs, "video"); name == "" {
				return nil, false, "", errors.New("no webcam or capture device was found")
			}
		}
		return []string{"-f", "dshow", "-rtbufsize", "32M", "-i", "video=" + name}, low == "camera", "camera \"" + name + "\"", nil
	case isScreenSource(src):
		ss, _ := parseScreenSource(src)
		var screens []screenInfo
		if ss.kind == "index" {
			screens = listScreens()
		}
		if ss.kind == "window" {
			if titles := windowTitles(); titles != nil {
				full := matchWindowTitle(titles, ss.title)
				if full == "" {
					return nil, false, "", fmt.Errorf("no open window has %q in its title", ss.title)
				}
				ss.title = full
			}
		}
		args, desc, err := screenCaptureArgs(ss, fps, runtime.GOOS, os.Getenv("DISPLAY"), screens)
		return args, false, desc, err
	case isURL(src):
		// -re: read at real speed. A recorded video would otherwise go as
		// fast as it downloads, and a live HLS stream (most IPTV and
		// YouTube live) arrives in bursts, a second of video at a time,
		// of which only the newest frame would be shown. -re only holds
		// ffmpeg back when it's ahead, so a live stream never falls behind.
		a := append(decodeArgs(cfg), inputOptsFor(src)...)
		a = append(a, httpReconnectArgs(ffmpeg, src)...)
		a = append(a, "-re")
		if cfg.realtime {
			// No "nobuffer" for a recorded video: it's for low delay on
			// live streams, and it stops ffmpeg reading an .mp4 over the web.
			a = append(a, "-fflags", "+discardcorrupt")
		} else {
			a = append(a, "-fflags", "+discardcorrupt+nobuffer")
		}
		seek := []string(nil)
		if cfg.seekSec > 0 { // picking up partway through
			seek = []string{"-ss", strconv.FormatFloat(cfg.seekSec, 'f', 2, 64)}
		}
		a = append(a, "-err_detect", "ignore_err")
		a = append(a, seek...)
		a = append(a, "-i", src)
		if cfg.audioURL != "" {
			// The sound, as a second input: downloaded by openWebStream and
			// read from ffmpeg's stdin.
			a = append(a, "-re")
			a = append(a, seek...)
			a = append(a, "-i", "pipe:0")
		}
		return a, false, src, nil
	default:
		if _, err := os.Stat(src); err != nil {
			return nil, false, "", fmt.Errorf("SOURCE %q is not a file, URL, camera, screen or test", src)
		}
		// Files play at real speed and loop forever (a playlist's files
		// play once: see withoutLoop).
		file := src
		if cfg.playFile != "" {
			file = cfg.playFile // a re-encoded copy
		}
		a := append(decodeArgs(cfg), "-re")
		if cfg.playFile != "" {
			// A re-encoded copy is light to play: plain decoding, and a
			// good look at the start of the file to find its sound.
			a = []string{"-probesize", "50M", "-analyzeduration", "20M", "-re"}
		}
		if cfg.growing {
			// Still being written: at its end, wait for more (up to 20 s).
			a = append(a, "-follow", "1", "-rw_timeout", "20000000")
		} else {
			a = append(a, "-stream_loop", "-1")
		}
		if s := cfg.seekSec - cfg.playOffset; s >= 0.05 {
			// Before -i: ffmpeg jumps near the spot, then decodes up to
			// exactly it (fast, and frame-accurate).
			a = append(a, "-ss", strconv.FormatFloat(s, 'f', 3, 64))
		}
		return append(a, "-i", file), false, "file " + filepath.Base(src), nil
	}
}

// decodeArgs make decoding a movie cheaper, since all we keep is a picture
// a few dozen characters wide:
//   - the graphics card decodes it when it can (HWACCEL=auto; ffmpeg falls
//     back to the processor by itself if it can't), and
//   - the decoder skips its smoothing (deblocking) pass and takes its fast
//     shortcuts (FAST_DECODE=1): about a quarter less work, and no
//     visible difference once shrunk to 80x48.
func decodeArgs(cfg *Config) []string {
	var a []string
	if hw := strings.ToLower(strings.TrimSpace(cfg.HWAccel)); hw != "" && hw != "off" && hw != "0" && hw != "no" {
		a = append(a, "-hwaccel", hw)
	}
	if cfg.FastDecode {
		a = append(a, "-skip_loop_filter", "all", "-flags2", "fast")
	}
	return a
}

func isDigits(s string) bool {
	if s == "" {
		return false
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return false
		}
	}
	return true
}

// VideoSource delivers RGB24 frames of cols x 2*rows pixels. Only the
// newest frame is kept, so a slow consumer never builds latency.
type VideoSource struct {
	W, H     int
	HiW, HiH int    // sharper copy for sixel viewers (0 = none)
	latestHi []byte // the sharper copy of latest
	// The sharper copy of the frame Next last handed out. Kept here because
	// the main loop paces itself between taking a frame and sending its
	// sharp copy, and a new frame often arrives in between.
	takenHi   []byte
	takenSeq  uint64
	Desc      string
	mu        sync.Mutex
	cond      *sync.Cond
	latest    []byte
	latestPTS int64 // the frame's place in the movie (ms on the shared clock), or -1
	seq       uint64
	err       error
	done      bool
}

func newVideoSource(w, h int) *VideoSource {
	v := &VideoSource{W: w, H: h}
	v.cond = sync.NewCond(&v.mu)
	return v
}

func (v *VideoSource) put(frame []byte) { v.putPTS(frame, -1) }

// putPTS stores a frame stamped with its time in the movie, so it stays in
// step with sound stamped the same way, however late it is delivered.
func (v *VideoSource) putPTS(frame []byte, pts int64) { v.putHi(frame, nil, pts) }

// snapshot returns the newest frame and its sharper copy (nil if none).
func (v *VideoSource) snapshot() (lo, hi []byte) {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.latest, v.latestHi
}

// putHi stores a frame with its sharper copy (nil if none).
func (v *VideoSource) putHi(frame, hi []byte, pts int64) {
	v.mu.Lock()
	v.latestHi = hi
	v.latest = frame
	v.latestPTS = pts
	v.seq++
	v.mu.Unlock()
	v.cond.Broadcast()
}

func (v *VideoSource) fail(err error, final bool) {
	v.mu.Lock()
	v.err = err
	if final {
		v.done = true
	}
	v.mu.Unlock()
	v.cond.Broadcast()
}

// Next blocks until a frame newer than lastSeq arrives (or the source ends).
func (v *VideoSource) Next(lastSeq uint64, timeout time.Duration) ([]byte, uint64, int64, error) {
	deadline := time.Now().Add(timeout)
	t := time.AfterFunc(timeout, v.cond.Broadcast)
	defer t.Stop()
	v.mu.Lock()
	defer v.mu.Unlock()
	for v.seq == lastSeq && !v.done && time.Now().Before(deadline) {
		v.cond.Wait()
	}
	if v.seq == lastSeq {
		if v.done {
			return nil, lastSeq, -1, v.err
		}
		return nil, lastSeq, -1, nil
	}
	out := make([]byte, len(v.latest))
	copy(out, v.latest)
	v.takenHi, v.takenSeq = v.latestHi, v.seq // each frame's sharp copy is its own slice
	return out, v.seq, v.latestPTS, nil
}

// Hi returns a copy of the sharper picture that goes with frame seq, if any.
func (v *VideoSource) Hi(seq uint64) []byte {
	v.mu.Lock()
	defer v.mu.Unlock()
	if v.takenSeq != seq || v.takenHi == nil {
		return nil
	}
	return append([]byte(nil), v.takenHi...)
}

// HasFrames reports whether any picture has been produced yet.
func (v *VideoSource) HasFrames() bool {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.seq > 0
}

func (v *VideoSource) LastError() error {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.err
}

// tailBuffer keeps the last few lines ffmpeg wrote to stderr for error messages.
type tailBuffer struct {
	mu    sync.Mutex
	lines []string
}

func (t *tailBuffer) Write(p []byte) (int, error) {
	t.mu.Lock()
	for _, l := range strings.Split(strings.ReplaceAll(string(p), "\r", "\n"), "\n") {
		if l = strings.TrimSpace(l); l != "" {
			t.lines = append(t.lines, l)
		}
	}
	if len(t.lines) > 6 {
		t.lines = t.lines[len(t.lines)-6:]
	}
	t.mu.Unlock()
	return len(p), nil
}

func (t *tailBuffer) String() string {
	t.mu.Lock()
	defer t.mu.Unlock()
	if len(t.lines) == 0 {
		return ""
	}
	last := t.lines[len(t.lines)-1]
	// ffmpeg's last words are often just "Error opening output files" or
	// "Conversion failed!": the reason is the line before.
	l := strings.ToLower(last)
	if len(t.lines) > 1 && (strings.HasPrefix(l, "error opening output file") || strings.HasPrefix(l, "conversion failed") ||
		strings.HasPrefix(l, "error opening input file") || strings.HasPrefix(l, "error while opening")) {
		return t.lines[len(t.lines)-2] + " / " + last
	}
	return last
}

// runFFmpegVideo runs ffmpeg in a loop, restarting it with backoff when the
// source drops (camera unplugged, stream hiccup). Stops when ctx ends.
// runFFmpegVideo plays one video source through ffmpeg.
//
// once=true is for files in a playlist: play to the end and return nil, or
// return an error if the file wouldn't play. once=false is for live
// sources and single looping files: restart with backoff when the source
// drops, until ctx ends; it returns an error only if the source never
// produced a picture after several tries (wrong device name, bad URL).
// avOut asks runFFmpegVideo to take the sound from the same ffmpeg as the
// picture, so both are stamped with the movie's own time.
type avOut struct {
	clock0 time.Time
	snd    *Sender
}

func runFFmpegVideo(ctx context.Context, v *VideoSource, ffmpeg string, input []string, flip bool, fps float64, subs *Subtitles, cfg *Config, once bool, av *avOut, logf func(string, ...any)) error {
	// With a sharper copy for sixel viewers, ffmpeg makes that one and the
	// usual small picture is averaged down from it here.
	outW, outH := v.W, v.H
	if v.HiW > 0 {
		outW, outH = v.HiW, v.HiH
	}
	vf := fmt.Sprintf("fps=%s,scale=%d:%d:flags=area", strconv.FormatFloat(fps, 'f', -1, 64), outW, outH)
	if flip {
		vf += ",hflip" // after shrinking: far less work
	}
	if once {
		input = withoutLoop(input)
	}
	frameBytes := outW * outH * 3
	backoff := time.Second
	everWorked := false
	for ctx.Err() == nil {
		// Subtitles ride the same ffmpeg run: video to our pipe, captions
		// as SRT to a local socket.
		in, vmap, subOut := input, []string(nil), []string(nil)
		var ln net.Listener
		if subs != nil {
			var err error
			if ln, err = net.Listen("tcp", "127.0.0.1:0"); err != nil {
				logf("subtitles: can't open a local port (%v); continuing without", err)
				subs = nil
			} else {
				in, vmap, subOut = subs.ffmpegArgs(cfg, input, ln.Addr().(*net.TCPAddr).Port)
			}
		}
		args := append([]string{"-hide_banner", "-loglevel", "error", "-nostdin"}, in...)
		args = append(args, vmap...)
		args = append(args, "-an", "-sn", "-vf", vf, "-pix_fmt", "rgb24", "-f", "rawvideo", "-")
		args = append(args, subOut...)

		// Sound from this same ffmpeg, as a second output on a local socket.
		var clk *mediaClock
		var aln net.Listener
		if av != nil {
			var err error
			if aln, err = net.Listen("tcp", "127.0.0.1:0"); err == nil {
				clk = &mediaClock{clock0: av.clock0}
				args = append(args, "-map", soundMap(cfg), "-vn", "-sn",
					"-ac", strconv.Itoa(cfg.AudioChannels), "-ar", strconv.Itoa(cfg.AudioRate),
					"-f", "s16le", fmt.Sprintf("tcp://127.0.0.1:%d?tcp_nodelay=1", aln.Addr().(*net.TCPAddr).Port))
			} else {
				logf("sound: can't open a local port (%v)", err)
			}
		}

		tail := &tailBuffer{}
		runCtx, stopRun := context.WithCancel(ctx)
		cmd := ffmpegCommand(runCtx, ffmpeg, args...)
		cmd.Stderr = tail
		var sound io.ReadCloser
		if cfg.audioURL != "" {
			sound = openWebStream(runCtx, cfg.audioURL, logf)
			cmd.Stdin = sound
		}
		out, err := cmd.StdoutPipe()
		if err == nil {
			err = cmd.Start()
		}
		if err != nil {
			stopRun()
			if ln != nil {
				ln.Close()
			}
			return fmt.Errorf("cannot run ffmpeg: %v", err)
		}
		audioDone := make(chan struct{})
		// When sound last came. When the sound is its own stream and that
		// stream ends early, ffmpeg keeps the connection open but quiet.
		var lastSound atomic.Int64
		lastSound.Store(time.Now().UnixNano())
		if aln != nil {
			go func() {
				defer close(audioDone)
				readMediaAudio(ctx, aln, cfg, newAudioStamper(cfg, av.clock0, av.snd, clk), func() {
					lastSound.Store(time.Now().UnixNano())
				})
			}()
		} else {
			close(audioDone)
		}
		if ln != nil {
			go func(ln net.Listener, s *Subtitles) {
				defer ln.Close()
				if tl, ok := ln.(*net.TCPListener); ok {
					tl.SetDeadline(time.Now().Add(60 * time.Second))
				}
				conn, err := ln.Accept()
				if err != nil {
					return
				}
				s.readSRT(conn, logf)
			}(ln, subs)
		}
		r := bufio.NewReaderSize(out, frameBytes*2)
		got := 0
		deliver := func(buf []byte, pts int64) {
			if v.HiW > 0 {
				v.putHi(resizeArea(buf, outW, outH, v.W, v.H), buf, pts)
			} else {
				v.putPTS(buf, pts)
			}
		}
		var pace *framePacer
		if isURL(cfg.Source) {
			// Web streams can arrive in clumps (HLS with sound comes a few
			// frames at a time, ~3 times a second); only the newest frame
			// of a clump would be shown. Even them out.
			pace = newFramePacer(fps, deliver)
			deliver = pace.add
		}
		lost := false
		for ctx.Err() == nil {
			buf := make([]byte, frameBytes)
			if err := readFull(r, buf); err != nil {
				break
			}
			// Sound that comes as its own stream (YouTube) stopped while the
			// picture goes on: stop here and let the caller pick it up again.
			if aln != nil && cfg.audioURL != "" && once && got > int(fps)*2 &&
				time.Since(time.Unix(0, lastSound.Load())) > 4*time.Second {
				lost = true
				stopRun()
				break
			}
			if got == 0 {
				subs.startRun(time.Now(), cfg.seekSec)
			}
			pts := int64(-1)
			if clk != nil {
				// Frame N of a constant-rate stream is N/fps into the movie.
				pts = clk.anchor() + int64(float64(got)*1000/fps)
			}
			deliver(buf, pts)
			got++
			if cfg.onPos != nil {
				cfg.onPos.set(cfg.seekSec + float64(got)/fps)
			}
			everWorked = true
			backoff = time.Second
		}
		if ctx.Err() == nil {
			io.Copy(io.Discard, out) // let ffmpeg finish cleanly
		}
		if pace != nil {
			pace.close(ctx.Err() != nil) // switching away: drop what's queued
		}
		cmd.Wait()
		stopRun()
		if sound != nil {
			sound.Close()
		}
		if ln != nil {
			ln.Close()
		}
		if aln != nil {
			aln.Close()
		}
		<-audioDone
		if ctx.Err() != nil {
			return nil
		}
		if lost {
			at := cfg.seekSec + float64(got)/fps - 5
			return &soundLostError{at: math.Max(0, at), why: tail.String()}
		}
		why := tail.String()
		if why == "" {
			why = "source ended"
		}
		if subs != nil && got == 0 {
			// Don't let a subtitle problem take the picture down with it.
			logf("subtitles: couldn't read them from this source (%s); continuing without", why)
			subs = nil
			continue
		}
		if once {
			if got == 0 {
				return errors.New(why)
			}
			return nil // played to the end
		}
		if !everWorked && got == 0 && backoff >= 4*time.Second {
			return fmt.Errorf("video source failed: %s", why)
		}
		v.fail(fmt.Errorf("video: %s", why), false)
		if subs != nil && subs.mode == "cc" && fileExists(cfg.Source) && why == "source ended" {
			continue // captioned files play through and restart (no loop option there)
		}
		logf("video source stopped (%s); restarting in %ds", why, int(backoff.Seconds()))
		select {
		case <-ctx.Done():
			return nil
		case <-time.After(backoff):
		}
		backoff *= 2
		if backoff > 30*time.Second {
			backoff = 30 * time.Second
		}
	}
	return nil
}

// readMediaAudio receives the sound ffmpeg writes to the local socket and
// sends it on, stamped by movie time.
func readMediaAudio(ctx context.Context, ln net.Listener, cfg *Config, st *audioStamper, onChunk func()) {
	if tl, ok := ln.(*net.TCPListener); ok {
		tl.SetDeadline(time.Now().Add(60 * time.Second))
	}
	conn, err := ln.Accept()
	if err != nil {
		return
	}
	defer conn.Close()
	stop := context.AfterFunc(ctx, func() { conn.Close() })
	defer stop()
	cb := chunkBytes(cfg)
	r := bufio.NewReaderSize(conn, cb*2)
	for ctx.Err() == nil {
		pcm := make([]byte, cb)
		if err := readFull(r, pcm); err != nil {
			return
		}
		st.emit(pcm)
		if onChunk != nil {
			onChunk()
		}
	}
}

// withoutLoop drops "-stream_loop -1" so a playlist file plays once.
func withoutLoop(in []string) []string {
	out := make([]string, 0, len(in))
	for i := 0; i < len(in); i++ {
		if in[i] == "-stream_loop" && i+1 < len(in) {
			i++
			continue
		}
		out = append(out, in[i])
	}
	return out
}

// runTestPattern generates the animated test card at the configured fps.
func runTestPattern(ctx context.Context, v *VideoSource, cols, rows int, fps float64) {
	tick := time.NewTicker(time.Duration(float64(time.Second) / fps))
	defer tick.Stop()
	n := 0
	for {
		buf := make([]byte, cols*2*rows*3)
		testFrame(buf, cols, rows, n)
		v.put(buf)
		n++
		select {
		case <-ctx.Done():
			return
		case <-tick.C:
		}
	}
}

// runStdin reads raw rgb24 frames of inW x inH from stdin and downscales.
func runStdin(ctx context.Context, v *VideoSource, inW, inH int) {
	r := bufio.NewReaderSize(os.Stdin, inW*inH*3)
	for ctx.Err() == nil {
		buf := make([]byte, inW*inH*3)
		if err := readFull(r, buf); err != nil {
			v.fail(errors.New("stdin ended"), true)
			return
		}
		v.put(resizeArea(buf, inW, inH, v.W, v.H))
	}
}

// resizeArea is a box-filter downscale (like cv2.INTER_AREA) for RGB24.
func resizeArea(src []byte, sw, sh, dw, dh int) []byte {
	if sw == dw && sh == dh {
		return src
	}
	dst := make([]byte, dw*dh*3)
	for dy := 0; dy < dh; dy++ {
		y0, y1 := dy*sh/dh, (dy+1)*sh/dh
		if y1 <= y0 {
			y1 = y0 + 1
		}
		for dx := 0; dx < dw; dx++ {
			x0, x1 := dx*sw/dw, (dx+1)*sw/dw
			if x1 <= x0 {
				x1 = x0 + 1
			}
			var r, g, b, n int
			for y := y0; y < y1 && y < sh; y++ {
				for x := x0; x < x1 && x < sw; x++ {
					i := (y*sw + x) * 3
					r += int(src[i])
					g += int(src[i+1])
					b += int(src[i+2])
					n++
				}
			}
			o := (dy*dw + dx) * 3
			if n > 0 {
				dst[o], dst[o+1], dst[o+2] = byte(r/n), byte(g/n), byte(b/n)
			}
		}
	}
	return dst
}

// readCaption returns the last non-empty line (max 240 chars) of a file.
func readCaption(path string) []byte {
	if path == "" {
		return nil
	}
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	if st, err := f.Stat(); err == nil && st.Size() > 512 {
		f.Seek(st.Size()-512, io.SeekStart)
	}
	tail, _ := io.ReadAll(io.LimitReader(f, 512))
	lines := strings.Split(strings.ReplaceAll(string(tail), "\r", ""), "\n")
	for i := len(lines) - 1; i >= 0; i-- {
		l := strings.TrimSpace(lines[i])
		if l == "" {
			continue
		}
		l = strings.ToValidUTF8(l, "?")
		if r := []rune(l); len(r) > 240 {
			l = string(r[:240])
		}
		return []byte(l)
	}
	return nil
}

// Seq counts the frames delivered so far.
func (v *VideoSource) Seq() uint64 {
	v.mu.Lock()
	defer v.mu.Unlock()
	return v.seq
}

// framePacer hands frames on one per frame interval, from a short queue
// (at most about half a second; older frames are dropped when it's full).
type framePacer struct {
	q       chan pacedFrame
	done    chan struct{}
	discard atomic.Bool
}

type pacedFrame struct {
	buf []byte
	pts int64
}

func newFramePacer(fps float64, put func([]byte, int64)) *framePacer {
	n := int(fps/2) + 1
	p := &framePacer{q: make(chan pacedFrame, n), done: make(chan struct{})}
	tick := time.Duration(float64(time.Second) / fps)
	go func() {
		defer close(p.done)
		next := time.Now()
		for f := range p.q {
			if p.discard.Load() {
				continue
			}
			if d := time.Until(next); d > 0 {
				time.Sleep(d)
			}
			put(f.buf, f.pts)
			now := time.Now()
			if next = next.Add(tick); next.Before(now.Add(-tick)) {
				next = now // fell behind (a pause in the stream): don't rush to catch up
			}
		}
	}()
	return p
}

// add queues a frame; only the reader calls it.
func (p *framePacer) add(buf []byte, pts int64) {
	f := pacedFrame{buf, pts}
	for {
		select {
		case p.q <- f:
			return
		default:
			select { // full: drop the oldest
			case <-p.q:
			default:
			}
		}
	}
}

// close lets the queued frames out (or drops them) and waits.
func (p *framePacer) close(discard bool) {
	p.discard.Store(discard)
	close(p.q)
	<-p.done
}

// soundMap picks the sound stream: the second input's when the sound
// comes separately, else the first input's.
func soundMap(cfg *Config) string {
	if cfg.audioURL != "" {
		return "1:a:0"
	}
	return "0:a:0"
}

// soundLostError: the separate sound stream stopped partway through.
type soundLostError struct {
	at  float64 // seconds into the video to pick up from
	why string  // what ffmpeg said
}

func (e *soundLostError) Error() string {
	return fmt.Sprintf("the sound stopped at %.0f s (%s)", e.at, e.why)
}

var reconnectOK = struct {
	sync.Mutex
	m map[string]bool
}{m: map[string]bool{}}

// httpReconnectArgs: for a web address, ask ffmpeg to reconnect by itself
// when the connection drops (if this ffmpeg knows how).
func httpReconnectArgs(ffmpeg, src string) []string {
	low := strings.ToLower(src)
	if !strings.HasPrefix(low, "http://") && !strings.HasPrefix(low, "https://") {
		return nil
	}
	reconnectOK.Lock()
	ok, known := reconnectOK.m[ffmpeg]
	reconnectOK.Unlock()
	if !known {
		cmd := exec.Command(ffmpeg, "-hide_banner", "-h", "protocol=http")
		hideWindow(cmd)
		out, _ := cmd.Output()
		ok = strings.Contains(string(out), "reconnect_on_network_error")
		reconnectOK.Lock()
		reconnectOK.m[ffmpeg] = ok
		reconnectOK.Unlock()
	}
	if !ok {
		return nil
	}
	return []string{"-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_on_network_error", "1", "-reconnect_delay_max", "5"}
}
