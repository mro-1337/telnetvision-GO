package main

import (
	"archive/zip"
	"bytes"
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"sort"
	"testing"
)

func TestDownloadFFmpeg(t *testing.T) {
	var zb bytes.Buffer
	zw := zip.NewWriter(&zb)
	for _, n := range []string{"ff-gpl-shared/bin/ffmpeg.exe", "ff-gpl-shared/bin/avcodec-62.dll", "ff-gpl-shared/bin/ffplay.exe",
		"ff-gpl-shared/bin/ffprobe.exe", "ff-gpl-shared/doc/ffmpeg.html", "ff-gpl-shared/lib/avcodec.dll"} {
		w, _ := zw.Create(n)
		w.Write([]byte("data of " + n))
	}
	zw.Close()
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/ok.zip" {
			http.NotFound(w, r)
			return
		}
		w.Write(zb.Bytes())
	}))
	defer srv.Close()

	root := t.TempDir()
	dir := filepath.Join(root, jxlFolder)
	var last int64
	if err := downloadFFmpeg(context.Background(), srv.URL+"/ok.zip", dir, func(d, tot int64) { last = d }); err != nil {
		t.Fatal(err)
	}
	if last != int64(zb.Len()) {
		t.Errorf("progress ended at %d of %d", last, zb.Len())
	}
	ents, _ := os.ReadDir(dir)
	var names []string
	for _, e := range ents {
		names = append(names, e.Name())
	}
	sort.Strings(names)
	if got := filepath.Join(names...); got != filepath.Join("avcodec-62.dll", "ffmpeg.exe") {
		t.Errorf("extracted %v, want avcodec-62.dll and ffmpeg.exe only", names)
	}
	if b, _ := os.ReadFile(filepath.Join(dir, "ffmpeg.exe")); string(b) != "data of ff-gpl-shared/bin/ffmpeg.exe" {
		t.Errorf("ffmpeg.exe holds %q", b)
	}
	left, _ := os.ReadDir(root)
	if len(left) != 1 {
		t.Errorf("left behind: %v", left)
	}

	// A failed download leaves nothing.
	dir2 := filepath.Join(root, "other")
	if err := downloadFFmpeg(context.Background(), srv.URL+"/missing.zip", dir2, nil); err == nil {
		t.Error("no error for a missing download")
	}
	if _, err := os.Stat(dir2); err == nil {
		t.Error("a failed download left its folder")
	}
}

// TestDownloadFFmpegReal fetches the real build (about 90 MB):
// TV_REAL_DOWNLOAD=1 go test -run Real
func TestDownloadFFmpegReal(t *testing.T) {
	if os.Getenv("TV_REAL_DOWNLOAD") == "" {
		t.Skip("set TV_REAL_DOWNLOAD=1")
	}
	dir := filepath.Join(t.TempDir(), jxlFolder)
	url := btbnBase + "ffmpeg-master-latest-win64-gpl-shared.zip"
	if err := downloadFFmpeg(context.Background(), url, dir, consoleProgress()); err != nil {
		t.Fatal(err)
	}
	ents, _ := os.ReadDir(dir)
	for _, e := range ents {
		fi, _ := e.Info()
		t.Logf("%s %d", e.Name(), fi.Size())
	}
	b, err := os.ReadFile(filepath.Join(dir, "avcodec-63.dll"))
	if err != nil {
		matches, _ := filepath.Glob(filepath.Join(dir, "avcodec-*.dll"))
		if len(matches) == 0 {
			t.Fatal("no avcodec dll")
		}
		b, _ = os.ReadFile(matches[0])
	}
	if !bytes.Contains(b, []byte("libjxl")) {
		t.Error("the downloaded avcodec has no libjxl")
	}
}
