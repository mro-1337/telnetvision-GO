package main

// JPEG XL pictures for viewers whose terminal can show them (SyncTERM 1.10
// and terminals that copy its "DrawJXLBlob" command). Full colour, and far
// smaller than sixel for the same picture.
//
// Each frame is encoded once here, on the camera PC, by ffmpeg's libjxl
// encoder, and the server hands the same picture to every JXL viewer. The
// encoder only runs while the server says someone watches in JXL
// (WANT_JXL). One ffmpeg process stays open: raw frames go in on its
// stdin, and it writes one .jxl file per frame into a temp folder (each
// written whole, then renamed, so a file that's there is complete). Frames
// come out in the order they went in, so each one's time stamp is known.

import (
	"bytes"
	"context"
	"encoding/binary"
	"fmt"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"sync"
	"time"
)

const (
	msgFrameJXL      = 0x15 // 0x15 | u16 w | u16 h | u64 pts | JPEG XL codestream (High detail)
	msgFrameJXLLevel = 0x16 // 0x16 | u8 level | u16 w | u16 h | u64 pts | codestream (1 = Medium, 2 = Low)
	msgWantJXL       = 0x22 // server -> producer: u8 bits 0-2 = which levels to make (0 = none)
	capJXL           = 0x02 // hello caps: this producer can send FRAME_JXL
	capJXLLevels     = 0x04 // hello caps: ... at three detail levels (WANT_JXL is a set of levels)
	jxlLevels        = 3    // High, Medium, Low
)

// jxlLevel is one detail level's picture size and quality.
type jxlLevel struct{ width, quality int }

// jxlLevelsOf gives the High, Medium and Low settings from telnetvision.ini.
func jxlLevelsOf(cfg *Config) [jxlLevels]jxlLevel {
	return [jxlLevels]jxlLevel{{cfg.JXLWidth, cfg.JXLQuality}, {cfg.JXLMediumWidth, cfg.JXLMediumQuality}, {cfg.JXLLowWidth, cfg.JXLLowQuality}}
}

// ffmpegHasJXL reports whether this ffmpeg can encode JPEG XL.
func ffmpegHasJXL(ffmpeg string) bool {
	if ffmpeg == "" {
		return false
	}
	cmd := exec.Command(ffmpeg, "-hide_banner", "-h", "encoder=libjxl")
	hideWindow(cmd)
	out, _ := cmd.Output()
	return bytes.Contains(out, []byte("Encoder libjxl"))
}

// jxlDistance turns JXL_QUALITY (1-100, like cjxl's -q) into libjxl's
// distance: 90 = 1.0 (very good), 75 = 2.35, 50 = 4.6.
func jxlDistance(q int) float64 {
	switch {
	case q >= 100:
		return 0.1
	case q >= 30:
		return 0.1 + float64(100-q)*0.09
	case q < 1:
		q = 1
	}
	return math.Min(15, 6.4+float64(30-q)*0.29)
}

func jxlPayload(level, w, h int, ptsMs uint64, data []byte) []byte {
	p := make([]byte, 0, 14+len(data))
	if level == 0 {
		p = append(p, msgFrameJXL) // what a 1.3.0 tvserver understands
	} else {
		p = append(p, msgFrameJXLLevel, byte(level))
	}
	p = binary.BigEndian.AppendUint16(p, uint16(w))
	p = binary.BigEndian.AppendUint16(p, uint16(h))
	p = binary.BigEndian.AppendUint64(p, ptsMs)
	p = append(p, data...)
	return framed(p)
}

type jxlFrame struct {
	rgb  []byte
	w, h int
	pts  uint64
}

// jxlEncoder keeps one ffmpeg running while JXL is wanted.
type jxlEncoder struct {
	ffmpeg  string
	level   int // 0 High, 1 Medium, 2 Low
	quality int
	send    func([]byte)
	logf    func(string, ...any)

	mu      sync.Mutex
	in      chan jxlFrame // newest frame only
	cancel  context.CancelFunc
	running bool
	w, h    int
}

func newJXLEncoder(ffmpeg string, level, quality int, send func([]byte), logf func(string, ...any)) *jxlEncoder {
	return &jxlEncoder{ffmpeg: ffmpeg, level: level, quality: quality, send: send, logf: logf}
}

// push offers a frame. It never waits: if the encoder is still busy with
// the last one, the older frame waiting is replaced.
func (e *jxlEncoder) push(rgb []byte, w, h int, pts uint64) {
	e.mu.Lock()
	if e.running && (w != e.w || h != e.h) {
		e.stopLocked() // the picture size changed: start over
	}
	if !e.running {
		e.startLocked(w, h)
	}
	in := e.in
	e.mu.Unlock()
	f := jxlFrame{rgb: rgb, w: w, h: h, pts: pts}
	for {
		select {
		case in <- f:
			return
		default:
			select {
			case <-in:
			default:
			}
		}
	}
}

// stop ends the encoder (no one watches in JXL any more).
func (e *jxlEncoder) stop() {
	e.mu.Lock()
	e.stopLocked()
	e.mu.Unlock()
}

func (e *jxlEncoder) stopLocked() {
	if e.running {
		e.cancel()
		e.running = false
	}
}

func (e *jxlEncoder) startLocked(w, h int) {
	ctx, cancel := context.WithCancel(context.Background())
	e.cancel, e.running, e.w, e.h = cancel, true, w, h
	e.in = make(chan jxlFrame, 1)
	in := e.in
	go func() {
		if err := e.run(ctx, in, w, h); err != nil && ctx.Err() == nil {
			e.logf("JPEG XL: %v", err)
			e.mu.Lock()
			if e.in == in {
				e.running = false
			}
			e.mu.Unlock()
		}
	}()
}

func (e *jxlEncoder) run(ctx context.Context, in chan jxlFrame, w, h int) error {
	dir, err := os.MkdirTemp("", "telnetvision-jxl-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dir)
	args := []string{"-hide_banner", "-loglevel", "error", "-nostdin",
		"-f", "rawvideo", "-pix_fmt", "rgb24", "-s", fmt.Sprintf("%dx%d", w, h), "-framerate", "15", "-i", "pipe:0",
		"-fps_mode", "passthrough",
		"-c:v", "libjxl", "-distance", strconv.FormatFloat(jxlDistance(e.quality), 'f', 2, 64), "-effort", "3",
		"-f", "image2", "-atomic_writing", "1", filepath.Join(dir, "f%09d.jxl")}
	// The -nostdin above stops ffmpeg reading keys; pipe:0 is still its input.
	cmd := ffmpegCommand(ctx, e.ffmpeg, args...)
	tail := &tailBuffer{}
	cmd.Stderr = tail
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	if err := cmd.Start(); err != nil {
		return fmt.Errorf("can't run ffmpeg: %v", err)
	}
	e.logf("JPEG XL: making %s %dx%d pictures for JXL viewers (quality %d)", jxlLevelName[e.level], w, h, e.quality)
	defer func() {
		stdin.Close()
		cmd.Wait()
	}()
	var pending []uint64 // time stamps of frames given to ffmpeg, in order
	next := 1            // the next file ffmpeg will write
	for ctx.Err() == nil {
		// Hand ffmpeg a frame only when it has caught up with the last
		// one, so a slow PC skips frames instead of falling behind.
		if len(pending) == 0 {
			select {
			case f := <-in:
				if _, err := stdin.Write(f.rgb); err != nil {
					return fmt.Errorf("ffmpeg stopped (%s)", tail.String())
				}
				pending = append(pending, f.pts)
			case <-ctx.Done():
				return nil
			}
		}
		// Wait for its picture.
		name := filepath.Join(dir, fmt.Sprintf("f%09d.jxl", next))
		deadline := time.Now().Add(5 * time.Second)
		var data []byte
		for ctx.Err() == nil {
			if b, err := os.ReadFile(name); err == nil {
				data = b
				break
			}
			if time.Now().After(deadline) {
				return fmt.Errorf("ffmpeg made no picture (%s)", tail.String())
			}
			time.Sleep(3 * time.Millisecond)
		}
		if data == nil {
			return nil
		}
		os.Remove(name)
		next++
		pts := pending[0]
		pending = pending[1:]
		e.send(jxlPayload(e.level, w, h, pts, data))
	}
	return nil
}

var jxlLevelName = [jxlLevels]string{"High", "Medium", "Low"}

// sizedPicture shrinks a picture to width (keeping its shape) if it's wider.
func sizedPicture(rgb []byte, w, h, width int) ([]byte, int, int) {
	if width <= 0 || width >= w {
		return rgb, w, h
	}
	nh := width * h / w
	return resizeArea(rgb, w, h, width, nh), width, nh
}
