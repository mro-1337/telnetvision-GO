package main

// A sturdy download for a web video's separate sound stream (YouTube).
//
// ffmpeg reads a web file as one long download at playing speed; YouTube's
// servers drop such slow connections now and then ("Error during
// demuxing: I/O error") and the sound stops. Instead the sound is fetched
// here the way yt-dlp does it: in 1 MB pieces, each its own short request,
// as fast as the network allows (up to 32 MB ahead), each retried if it
// fails. ffmpeg reads it from a pipe. A whole song is usually in memory
// within seconds, so a hiccup in the network is never heard.

import (
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"
)

const (
	webPiece   = 1 << 20 // bytes per request
	webAhead   = 32      // pieces downloaded ahead of the reader
	webRetries = 8
)

var webUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"

// openWebStream starts downloading u and returns the bytes as a stream.
// Closing it (or ctx ending) stops the download.
func openWebStream(ctx context.Context, u string, logf func(string, ...any)) io.ReadCloser {
	ctx, cancel := context.WithCancel(ctx)
	pr, pw := io.Pipe()
	pieces := make(chan []byte, webAhead)
	// Writer: hands the pieces to the reader in order.
	go func() {
		for p := range pieces {
			if _, err := pw.Write(p); err != nil {
				cancel()
				for range pieces { // let the downloader finish
				}
				return
			}
		}
		pw.Close()
	}()
	// Downloader.
	go func() {
		defer close(pieces)
		err := downloadPieces(ctx, u, pieces, logf)
		if err != nil && ctx.Err() == nil {
			logf("sound download: %v", err)
			pw.CloseWithError(err)
		}
	}()
	return &webStream{PipeReader: pr, cancel: cancel}
}

type webStream struct {
	*io.PipeReader
	cancel context.CancelFunc
}

func (w *webStream) Close() error {
	w.cancel()
	return w.PipeReader.Close()
}

func downloadPieces(ctx context.Context, u string, out chan<- []byte, logf func(string, ...any)) error {
	var off int64
	total := int64(-1)
	fails := 0
	for total < 0 || off < total {
		if ctx.Err() != nil {
			return nil
		}
		data, size, ranged, err := fetchPiece(ctx, u, off)
		if err != nil {
			if ctx.Err() != nil {
				return nil
			}
			fails++
			if fails > webRetries {
				return fmt.Errorf("gave up after %d tries: %v", fails, err)
			}
			if fails == 3 { // one or two misses are normal and quietly retried
				logf("sound download: %v; still trying", err)
			}
			select {
			case <-ctx.Done():
				return nil
			case <-time.After(time.Duration(fails) * 500 * time.Millisecond):
			}
			continue
		}
		fails = 0
		if size >= 0 {
			total = size
		}
		if len(data) > 0 {
			select {
			case out <- data:
			case <-ctx.Done():
				return nil
			}
			off += int64(len(data))
		}
		if !ranged || len(data) == 0 {
			return nil // the server sent it all at once (or nothing more)
		}
	}
	return nil
}

// fetchPiece gets up to webPiece bytes from off. size is the whole file's
// size (-1 if unknown); ranged is false when the server ignored the range
// and sent the whole file.
func fetchPiece(ctx context.Context, u string, off int64) (data []byte, size int64, ranged bool, err error) {
	rctx, cancel := context.WithTimeout(ctx, 30*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(rctx, "GET", u, nil)
	if err != nil {
		return nil, -1, false, err
	}
	req.Header.Set("User-Agent", webUserAgent)
	req.Header.Set("Range", fmt.Sprintf("bytes=%d-%d", off, off+webPiece-1))
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, -1, false, err
	}
	defer resp.Body.Close()
	switch resp.StatusCode {
	case http.StatusPartialContent:
		size = -1
		if cr := resp.Header.Get("Content-Range"); cr != "" { // bytes a-b/total
			if i := strings.LastIndexByte(cr, '/'); i >= 0 {
				if n, err := strconv.ParseInt(cr[i+1:], 10, 64); err == nil {
					size = n
				}
			}
		}
		data, err = io.ReadAll(io.LimitReader(resp.Body, webPiece))
		return data, size, true, err
	case http.StatusOK:
		if off > 0 {
			return nil, -1, false, errors.New("the server doesn't support resuming")
		}
		data, err = io.ReadAll(io.LimitReader(resp.Body, 512<<20))
		return data, int64(len(data)), false, err
	case http.StatusRequestedRangeNotSatisfiable:
		return nil, off, true, nil // past the end
	}
	return nil, -1, false, fmt.Errorf("the server answered %s", resp.Status)
}
