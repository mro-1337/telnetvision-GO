package main

// YouTube prefetching (YOUTUBE_PREFETCH=1, the default): each video is
// downloaded completely by yt-dlp before it plays, and while it plays the
// next one in the playlist downloads - one download at a time. Played from
// the PC's own disk, nothing on the network can interrupt it. Live streams
// can't be downloaded ahead; they are streamed as before.
//
// Downloads go to a telnetvision-youtube folder in the Windows temp folder
// and are deleted once played (and when the program starts).

import (
	"bufio"
	"context"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

type ytJob struct {
	page   string
	done   chan struct{}
	path   string // the downloaded file ("" for a live stream)
	title  string
	err    error
	pct    float64 // progress, 0..100
	cancel context.CancelFunc
}

type ytCache struct {
	dir    string
	ffmpeg string
	logf   func(string, ...any)
	mu     sync.Mutex
	jobs   map[string]*ytJob
	active *ytJob // the one download running now
}

func newYTCache(ffmpeg string, logf func(string, ...any)) *ytCache {
	base := filepath.Join(os.TempDir(), "telnetvision-youtube")
	// Leftovers from earlier runs (each run has its own folder, so two
	// copies running at once don't delete each other's downloads).
	if old, err := os.ReadDir(base); err == nil {
		for _, d := range old {
			if info, err := d.Info(); err == nil && time.Since(info.ModTime()) > 12*time.Hour {
				os.RemoveAll(filepath.Join(base, d.Name()))
			}
		}
	}
	dir := filepath.Join(base, strconv.Itoa(os.Getpid()))
	os.MkdirAll(dir, 0o755)
	return &ytCache{dir: dir, ffmpeg: ffmpeg, logf: logf, jobs: map[string]*ytJob{}}
}

// start begins downloading page unless it's done or under way. Only one
// download runs at a time: a new one waits for the running one, unless
// urgent, which cancels the other (it's needed now: it's what's playing).
func (c *ytCache) start(ctx context.Context, page string, urgent bool) *ytJob {
	c.mu.Lock()
	defer c.mu.Unlock()
	if j, ok := c.jobs[page]; ok {
		select {
		case <-j.done:
			if j.err == nil && (j.path == "" || fileExists(j.path)) {
				return j
			}
			// failed or deleted: try again
		default:
			return j // under way
		}
	}
	if a := c.active; a != nil && a.page != page {
		select {
		case <-a.done:
		default:
			if !urgent {
				return nil // one at a time: the next one waits its turn
			}
			c.logf("YouTube: stopping the download of the next video; this one is wanted now")
			a.cancel()
			delete(c.jobs, a.page)
		}
	}
	jctx, cancel := context.WithCancel(ctx)
	j := &ytJob{page: page, done: make(chan struct{}), cancel: cancel}
	c.jobs[page] = j
	c.active = j
	go func() {
		defer close(j.done)
		defer cancel()
		j.path, j.title, j.err = c.download(jctx, j)
	}()
	return j
}

// wait downloads page now (if it isn't already) and waits for it,
// reporting progress. path "" with no error means: stream it (live).
func (c *ytCache) wait(ctx context.Context, page string, progress func(float64)) (path, title string, err error) {
	j := c.start(ctx, page, true)
	tick := time.NewTicker(500 * time.Millisecond)
	defer tick.Stop()
	for {
		select {
		case <-j.done:
			return j.path, j.title, j.err
		case <-ctx.Done():
			return "", "", ctx.Err()
		case <-tick.C:
			c.mu.Lock()
			pct := j.pct
			c.mu.Unlock()
			progress(pct)
		}
	}
}

// forget deletes a played video's file.
func (c *ytCache) forget(page string) {
	c.mu.Lock()
	j, ok := c.jobs[page]
	if ok {
		select {
		case <-j.done:
			delete(c.jobs, page)
		default:
			ok = false // still downloading (asked for again): leave it
		}
	}
	c.mu.Unlock()
	if ok && j.path != "" {
		for i := 0; i < 10; i++ { // Windows: ffmpeg may still hold it a moment
			if err := os.Remove(j.path); err == nil || os.IsNotExist(err) {
				return
			}
			time.Sleep(300 * time.Millisecond)
		}
	}
}

// clear deletes everything (when the program ends).
func (c *ytCache) clear() {
	c.mu.Lock()
	for _, j := range c.jobs {
		j.cancel()
	}
	c.mu.Unlock()
	time.Sleep(200 * time.Millisecond)
	os.RemoveAll(c.dir)
}

func (c *ytCache) download(ctx context.Context, j *ytJob) (path, title string, err error) {
	ytdlp, err := findYtDlp()
	if err != nil {
		return "", "", err
	}
	args := []string{"--no-warnings", "--ignore-config", "--encoding", "utf-8", "--no-playlist",
		"--no-simulate", "--progress", "--newline", "--no-color", "--no-mtime",
		"-f", ytFormat, "--merge-output-format", "mkv",
		// Live streams (and ones that haven't started) aren't downloaded.
		"--match-filter", "!is_live & live_status!=?is_upcoming",
		"-o", filepath.Join(c.dir, "%(id)s.%(ext)s"),
		"--progress-template", "download:PROG %(progress._percent_str)s",
		"--print", "TITLE %(title)s",
		"--print", "after_move:FILE %(filepath)s",
	}
	if c.ffmpeg != "" {
		args = append(args, "--ffmpeg-location", c.ffmpeg)
	}
	args = append(args, j.page)
	cmd := ffmpegCommand(ctx, ytdlp, args...)
	out, err := cmd.StdoutPipe()
	if err != nil {
		return "", "", err
	}
	errTail := &tailBuffer{}
	cmd.Stderr = errTail
	if err := cmd.Start(); err != nil {
		return "", "", err
	}
	parts, last := 0, 0.0
	sc := bufio.NewScanner(out)
	sc.Buffer(make([]byte, 64<<10), 1<<20)
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		switch {
		case strings.HasPrefix(line, "PROG "):
			v, perr := strconv.ParseFloat(strings.TrimSuffix(strings.TrimSpace(line[5:]), "%"), 64)
			if perr != nil {
				continue
			}
			if v+5 < last { // picture done, now the sound: show it as one bar
				parts++
			}
			last = v
			total := v
			if parts > 0 {
				total = 85 + v*0.15 // the sound is the small part
			} else {
				total = v * 0.85
			}
			c.mu.Lock()
			j.pct = total
			c.mu.Unlock()
		case strings.HasPrefix(line, "TITLE "):
			title = strings.TrimSpace(line[6:])
		case strings.HasPrefix(line, "FILE "):
			path = strings.TrimSpace(line[5:])
		}
	}
	io.Copy(io.Discard, out)
	werr := cmd.Wait()
	if ctx.Err() != nil {
		return "", "", ctx.Err()
	}
	if path != "" && fileExists(path) {
		return path, title, nil
	}
	if werr != nil {
		msg := lastLine(errTail.String())
		if msg == "" {
			msg = werr.Error()
		}
		return "", title, errors.New(strings.TrimPrefix(msg, "ERROR: "))
	}
	return "", title, nil // filtered out: a live stream, to be streamed
}
