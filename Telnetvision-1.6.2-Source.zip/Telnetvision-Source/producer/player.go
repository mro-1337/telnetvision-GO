package main

// The player decides what is on air. A source is one of:
//   - a folder: every video in it and its subfolders becomes a playlist
//   - a video file: a one-item playlist
//   - an IPTV channel list (.m3u): every channel becomes a playlist entry;
//     a channel plays until N/B/L picks another (see m3u.go)
//   - a YouTube channel, playlist or video (see youtube.go)
//   - something live: camera, camera:<name>, a number, screen, test, a URL
//
// Playlists loop (and re-scan their folders for new files each time
// round), unplayable files are skipped, and each file's own sound and
// subtitles follow it. Sources can be switched, added to, and skipped
// through while running, from the keyboard.

import (
	"context"
	"errors"
	"fmt"
	"io/fs"
	"math"
	"math/rand"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"sync/atomic"
	"time"
	"unicode"
)

var videoExts = map[string]bool{
	".mp4": true, ".m4v": true, ".mkv": true, ".avi": true, ".mov": true, ".wmv": true,
	".asf": true, ".flv": true, ".f4v": true, ".webm": true, ".mpg": true, ".mpeg": true,
	".mpe": true, ".m2v": true, ".ts": true, ".m2ts": true, ".mts": true, ".vob": true,
	".3gp": true, ".3g2": true, ".ogv": true, ".ogm": true, ".divx": true, ".xvid": true,
	".rm": true, ".rmvb": true, ".dv": true, ".y4m": true,
}

func isVideoFile(p string) bool { return videoExts[strings.ToLower(filepath.Ext(p))] }

// isMediaFile: a video or a song (songs play with the visualizer).
func isMediaFile(p string) bool {
	e := strings.ToLower(filepath.Ext(p))
	return videoExts[e] || audioExts[e]
}

func isDir(p string) bool {
	st, err := os.Stat(p)
	return err == nil && st.IsDir()
}

// cleanPath tidies a typed or dragged-in path: Windows wraps paths with
// spaces in quotes when you drag a file or folder onto the window.
func cleanPath(s string) string {
	s = strings.TrimSpace(s)
	if len(s) >= 2 && (s[0] == '"' && s[len(s)-1] == '"' || s[0] == '\'' && s[len(s)-1] == '\'') {
		s = strings.TrimSpace(s[1 : len(s)-1])
	}
	return s
}

// scanFolder lists every video under root, in natural order.
func scanFolder(root string) ([]string, error) {
	var out []string
	err := filepath.WalkDir(root, func(p string, d fs.DirEntry, err error) error {
		if err != nil {
			if p == root {
				return err
			}
			return nil // unreadable subfolder: skip it, keep going
		}
		name := d.Name()
		if d.IsDir() {
			if p != root && (strings.HasPrefix(name, ".") || strings.HasPrefix(name, "$") ||
				strings.EqualFold(name, "System Volume Information")) {
				return filepath.SkipDir
			}
			return nil
		}
		if strings.HasPrefix(name, "._") || !isMediaFile(name) {
			return nil
		}
		out = append(out, p)
		return nil
	})
	sort.SliceStable(out, func(i, j int) bool { return naturalLess(out[i], out[j]) })
	return out, err
}

// naturalLess orders "Episode 2" before "Episode 10", ignoring case.
func naturalLess(a, b string) bool {
	ar, br := []rune(strings.ToLower(a)), []rune(strings.ToLower(b))
	i, j := 0, 0
	for i < len(ar) && j < len(br) {
		if unicode.IsDigit(ar[i]) && unicode.IsDigit(br[j]) {
			si := i
			for i < len(ar) && unicode.IsDigit(ar[i]) {
				i++
			}
			sj := j
			for j < len(br) && unicode.IsDigit(br[j]) {
				j++
			}
			na := strings.TrimLeft(string(ar[si:i]), "0")
			nb := strings.TrimLeft(string(br[sj:j]), "0")
			if len(na) != len(nb) {
				return len(na) < len(nb)
			}
			if na != nb {
				return na < nb
			}
			continue
		}
		if ar[i] != br[j] {
			// Path separators sort first so a folder's files stay together.
			if ar[i] == '/' || ar[i] == '\\' {
				return true
			}
			if br[j] == '/' || br[j] == '\\' {
				return false
			}
			return ar[i] < br[j]
		}
		i++
		j++
	}
	return len(ar)-i < len(br)-j
}

// isLiveSource reports whether s is a camera / screen / test / URL source.
func isLiveSource(s string) bool {
	l := strings.ToLower(strings.TrimSpace(s))
	return l == "camera" || strings.HasPrefix(l, "camera:") || isDigits(l) ||
		isScreenSource(s) || l == "test" || isVisualizerSource(s) || isURL(s)
}

type playerCmd struct {
	kind string // "switch" | "add" | "next" | "prev" | "goto" | "shuffle" | "golive" | "seek" | "reencode"
	arg  string

	// Filled in before the command is carried out (reading a folder, an
	// IPTV list or a YouTube channel can take a while, and is done while
	// the current video keeps playing).
	ready bool
	res   expanded
	ent   entry // golive: the channel's live stream
}

// expanded is what a typed source turned out to be.
type expanded struct {
	src     string  // as typed (cleaned)
	live    string  // a single live source, or
	list    []entry // a playlist
	channel string  // a YouTube channel (checked for going live)
}

type Player struct {
	base   *Config
	ffmpeg string
	v      *VideoSource
	snd    *Sender
	clock0 time.Time
	logf   func(string, ...any)

	cmds   chan playerCmd
	runCtx context.Context

	mu        sync.Mutex
	roots     []string // what the playlist is built from (folders, files, lists, YouTube links)
	items     []entry  // in playing order
	ordered   []entry  // the same in list order (for turning shuffle off)
	shuffle   bool
	pos       int
	live      string // live source when not playing a playlist
	ytChannel string // the playlist is this YouTube channel's
	nowDesc   string
	nowTitle  string // the title viewers see ("" = the TITLE setting)

	subs atomic.Pointer[Subtitles]
	yt   *ytCache // YouTube downloads (YOUTUBE_PREFETCH)

	// Audio that isn't tied to one file (a microphone) keeps running
	// across items; the file's own sound restarts with each file.
	audioKey    string
	audioCancel context.CancelFunc
	audioDone   chan struct{}

	// Where the video is (seconds into it), its length, and whether it
	// can be jumped around in (files and recorded videos, not live ones).
	posBits   atomic.Uint64
	sink      posSink
	dur       float64 // under mu
	seekable  bool    // under mu
	itemStart time.Time
	// The next run of the item playing should start here (a jump, or a
	// re-encoded copy taking over).
	resume *resumePoint // under mu
	// The playing movie's re-encoded copy (REENCODE=1), and movies whose
	// copy couldn't be made (not tried again).
	re       *reencoder // under mu
	reFailed map[string]bool
	copyMode map[string]string      // movies that play from a copy, and which kind (played again: copy at once)
	notice   atomic.Pointer[string] // for viewers: "please wait" while the copy is made

	// Up next: entries a viewer tagged (by src), played in this order
	// before the playlist carries on.
	upNext []string // under mu

	viewerList atomic.Bool // viewers may pick from the playlist (VIEWER_PLAYLIST, O)
}

// resumePoint: play item src from at (seconds); copy = via a re-encoded
// copy of that kind (copy720, copyHalf), "off" = the original again.
type resumePoint struct {
	src  string
	at   float64
	copy string
}

func NewPlayer(cfg *Config, ffmpeg string, v *VideoSource, snd *Sender, clock0 time.Time, logf func(string, ...any)) *Player {
	p := &Player{base: cfg, ffmpeg: ffmpeg, v: v, snd: snd, clock0: clock0, logf: logf, cmds: make(chan playerCmd, 8), shuffle: cfg.Shuffle, reFailed: map[string]bool{}, copyMode: map[string]string{}}
	p.sink.set = p.setPos
	p.viewerList.Store(cfg.ViewerPlaylist)
	return p
}

func (p *Player) setPos(sec float64) { p.posBits.Store(math.Float64bits(sec)) }

// Position is how far into the video it is, in seconds.
func (p *Player) Position() float64 { return math.Float64frombits(p.posBits.Load()) }

// PositionText is "12:34 / 1:45:00" for the status line ("" for live
// sources).
func (p *Player) PositionText() string {
	p.mu.Lock()
	ok, dur := p.seekable, p.dur
	p.mu.Unlock()
	if !ok {
		return ""
	}
	if dur > 0 {
		return clockTime(p.Position()) + " / " + clockTime(dur)
	}
	return clockTime(p.Position())
}

// Notice is the please-wait notice for viewers ("" = none).
func (p *Player) Notice() string {
	if s := p.notice.Load(); s != nil {
		return *s
	}
	return ""
}

func (p *Player) setNotice(s string) {
	if s == "" {
		p.notice.Store(nil)
	} else {
		p.notice.Store(&s)
	}
}

// CanReencode reports whether the movie playing now could be re-encoded
// (REENCODE=1, a video file on this PC that isn't already a copy, and
// hasn't failed to copy before).
func (p *Player) CanReencode() bool {
	if !p.base.Reencode {
		return false
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.live != "" || p.pos < 0 || p.pos >= len(p.items) || !p.seekable || time.Since(p.itemStart) < 8*time.Second {
		return false
	}
	e := p.items[p.pos]
	if e.kind != entFile || p.reFailed[e.src] || p.copyMode[e.src] != "" || (p.re != nil && p.re.src == e.src) || p.resume != nil {
		return false
	}
	st := probeStreams(context.Background(), p.ffmpeg, e.src) // cached
	return st.hasVideo
}

// takeResume returns where item src should start (0 = the beginning),
// and whether to switch to a copy ("" = no change).
func (p *Player) takeResume(src string) (float64, string) {
	p.mu.Lock()
	defer p.mu.Unlock()
	r := p.resume
	p.resume = nil
	if r == nil || r.src != src {
		return 0, ""
	}
	return r.at, r.copy
}

// dropReencode stops and deletes the re-encoded copy, if there is one
// (unless it's for keep, the movie that's still playing).
func (p *Player) dropReencode(keep string) {
	p.mu.Lock()
	re := p.re
	if re != nil && re.src != keep {
		p.re = nil
	} else {
		re = nil
	}
	p.mu.Unlock()
	if re != nil {
		re.close()
	}
}

func (p *Player) Command(kind, arg string) {
	select {
	case p.cmds <- playerCmd{kind: kind, arg: arg}:
	default:
	}
}

func (p *Player) Subs() *Subtitles { return p.subs.Load() }

// Title is the name for viewers' title bar: the movie's or channel's name,
// otherwise the TITLE setting.
func (p *Player) Title() string {
	if !p.base.ShowTitle {
		return ""
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.nowTitle != "" {
		return p.nowTitle
	}
	return p.base.Title
}

// tidyTitle makes a readable name from a file: no folder or extension, and
// dots or underscores used as spaces become spaces.
func tidyTitle(path string) string {
	name := filepath.Base(path)
	name = strings.TrimSuffix(name, filepath.Ext(name))
	if !strings.Contains(name, " ") {
		name = strings.NewReplacer(".", " ", "_", " ").Replace(name)
	}
	return strings.Join(strings.Fields(name), " ")
}

func entryTitle(e entry) string {
	if e.name != "" {
		return e.name
	}
	if e.kind == entFile {
		return tidyTitle(e.src)
	}
	return ""
}

// NowPlaying is a short label for the status line.
func (p *Player) NowPlaying() string {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.nowDesc
}

// Names lists the playlist for the L key: each entry's name, and its
// IPTV group in brackets.
func (p *Player) Names() []string {
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.live != "" {
		return nil
	}
	out := make([]string, len(p.items))
	for i, e := range p.items {
		out[i] = e.label()
		if e.group != "" {
			out[i] += "  [" + e.group + "]"
		}
	}
	return out
}

// expand works out what a typed source is. It can take a while (an IPTV
// list to download, a YouTube channel to look up).
func (p *Player) expand(ctx context.Context, src string) (expanded, error) {
	src = cleanPath(src)
	r := expanded{src: src}
	switch {
	case src == "":
		return r, errors.New("nothing entered")
	case isYouTubeURL(src):
		list, ch, err := expandYouTube(ctx, src, p.logf)
		r.list, r.channel = list, ch
		return r, err
	case looksLikeM3U(src) && (isURL(src) || fileExists(src)):
		if isURL(src) {
			p.logf("reading the channel list %s ...", src)
		}
		list, live, err := loadM3U(ctx, src)
		r.list, r.live = list, live
		return r, err
	case isLiveSource(src):
		r.live = src
		return r, nil
	case isDir(src):
		found, err := scanFolder(src)
		if err != nil {
			return r, fmt.Errorf("can't read folder %s: %v", src, err)
		}
		if len(found) == 0 {
			return r, fmt.Errorf("no video or music files in %s or its subfolders", src)
		}
		for _, f := range found {
			r.list = append(r.list, entry{src: f, kind: entFile})
		}
		return r, nil
	case fileExists(src):
		r.list = []entry{{src: src, kind: entFile}}
		return r, nil
	}
	return r, fmt.Errorf("can't find %q (not a file, folder, channel list, URL, camera, screen or test)", src)
}

// install puts an expanded source on: a new playlist or live source, or
// (add) more entries at the end of the playlist.
func (p *Player) install(r expanded, add bool) error {
	if r.live != "" {
		if add {
			return errors.New("only files, folders, channel lists and YouTube links can be added to the playlist; use S to switch to " + r.src)
		}
		p.mu.Lock()
		p.live, p.roots, p.items, p.ordered, p.pos, p.ytChannel = r.live, nil, nil, nil, 0, ""
		p.mu.Unlock()
		return nil
	}
	p.mu.Lock()
	defer p.mu.Unlock()
	order := append([]entry(nil), r.list...)
	found := append([]entry(nil), r.list...)
	if p.shuffle {
		shuffled(found)
	}
	if add && p.live == "" && len(p.items) > 0 {
		p.roots = append(p.roots, r.src)
		p.items = append(p.items, found...)
		p.ordered = append(p.ordered, order...)
		return nil
	}
	p.live, p.roots, p.items, p.ordered, p.pos, p.ytChannel = "", []string{r.src}, found, order, 0, r.channel
	return nil
}

// load expands and installs a source in one go.
func (p *Player) load(ctx context.Context, src string, add bool) error {
	r, err := p.expand(ctx, src)
	if err != nil {
		return err
	}
	return p.install(r, add)
}

// rescan rebuilds the playlist from what it was made from: new files in
// the folders, an updated channel list, a YouTube channel's new uploads
// (and its live stream, if it's on now).
func (p *Player) rescan(ctx context.Context) {
	p.mu.Lock()
	roots := append([]string(nil), p.roots...)
	p.mu.Unlock()
	var all []entry
	for _, r := range roots {
		if isDir(r) {
			if f, err := scanFolder(r); err == nil {
				for _, x := range f {
					all = append(all, entry{src: x, kind: entFile})
				}
			}
		} else if fileExists(r) && !looksLikeM3U(r) {
			all = append(all, entry{src: r, kind: entFile})
		} else if res, err := p.expand(ctx, r); err == nil && res.live == "" {
			all = append(all, res.list...)
		}
	}
	if len(all) == 0 {
		return // gone for now: keep the old list
	}
	p.mu.Lock()
	p.ordered = append([]entry(nil), all...)
	if p.shuffle {
		shuffled(all) // a fresh order every time round
	}
	p.items = all
	p.mu.Unlock()
}

func shuffled(s []entry) {
	rand.Shuffle(len(s), func(i, j int) { s[i], s[j] = s[j], s[i] })
}

// setShuffle turns shuffle on or off without interrupting the video that's
// playing: on, the rest of the playlist is put in random order; off, it
// carries on in list order from the current video.
func (p *Player) setShuffle(on bool) {
	p.mu.Lock()
	defer p.mu.Unlock()
	p.shuffle = on
	if p.live != "" || len(p.items) == 0 {
		return
	}
	var cur entry
	has := p.pos >= 0 && p.pos < len(p.items)
	if has {
		cur = p.items[p.pos]
	}
	if on {
		rest := make([]entry, 0, len(p.items))
		for i, it := range p.items {
			if i != p.pos {
				rest = append(rest, it)
			}
		}
		shuffled(rest)
		if has {
			p.items = append([]entry{cur}, rest...)
		} else {
			p.items = rest
		}
		p.pos = 0
	} else {
		p.items = append([]entry(nil), p.ordered...)
		p.pos = 0
		for i, it := range p.items {
			if it.src == cur.src {
				p.pos = i
				break
			}
		}
	}
	if has {
		p.nowDesc = fmt.Sprintf("%d/%d %s", p.pos+1, len(p.items), cur.label())
	}
}

// Shuffling reports whether the playlist plays in random order.
// ViewerPlaylist reports whether viewers may pick from the playlist.
func (p *Player) ViewerPlaylist() bool { return p.viewerList.Load() }

// ToggleViewerPlaylist switches viewers' picking on or off (O) and reports
// which it is now.
func (p *Player) ToggleViewerPlaylist() bool {
	on := !p.viewerList.Load()
	p.viewerList.Store(on)
	if on {
		p.logf("viewers can pick from the playlist (L) again")
	} else {
		p.logf("viewers' playlist turned off: viewers can't see or pick from it (O turns it on)")
	}
	return on
}

func (p *Player) Shuffling() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.shuffle
}

// itemConfig is the base settings with this item as the source.
func (p *Player) itemConfig(src string) *Config {
	c := *p.base
	c.Source = src
	c.onPos = &p.sink
	return &c
}

// setAudio makes sure the right sound is running for this item.
func (p *Player) setAudio(ctx context.Context, c *Config, perFile bool) {
	if !p.base.Audio {
		return
	}
	args, desc, err := audioInputArgs(c, p.ffmpeg)
	key := strings.Join(args, "\x00")
	if err == nil && !perFile && key == p.audioKey && p.audioCancel != nil {
		return // the same microphone keeps running
	}
	p.stopAudio()
	if err != nil {
		p.logf("sound: %v", err)
		return
	}
	// A file's own sound ends with the file; a microphone keeps going
	// across videos, so it hangs off the player, not this one item.
	parent := ctx
	if !perFile {
		parent = p.runCtx
	}
	actx, cancel := context.WithCancel(parent)
	done := make(chan struct{})
	p.audioKey, p.audioCancel, p.audioDone = key, cancel, done
	if !perFile {
		p.logf("sound: %s", desc)
	}
	go func() {
		defer close(done)
		runAudio(actx, c, p.ffmpeg, args, p.clock0, p.snd, p.logf)
	}()
}

func (p *Player) stopAudio() {
	if p.audioCancel != nil {
		p.audioCancel()
		<-p.audioDone
		p.audioCancel, p.audioKey = nil, ""
	}
}

// audioFollowsFile: with AUDIO_SOURCE=auto a file plays its own sound.
func (p *Player) audioFollowsFile() bool {
	a := strings.ToLower(strings.TrimSpace(p.base.AudioSource))
	return a == "" || a == "auto"
}

// playInfo tells Run how an item ended.
type playInfo struct {
	ytLive   bool // a YouTube live stream
	recorded bool // a web video with an end (plays once, like a file)
}

// playOne runs one item until it ends (files, recorded videos) or ctx is
// cancelled. It returns nil when a file played through.
func (p *Player) playOne(ctx context.Context, e entry) (playInfo, error) {
	var info playInfo
	src, audioURL := e.src, ""
	// Where to start: the beginning, or where a jump (or a re-encoded
	// copy taking over) left it.
	at, switchTo := p.takeResume(e.src)
	p.setPos(at)
	p.mu.Lock()
	p.seekable, p.dur, p.itemStart = false, 0, time.Now()
	switch switchTo {
	case "":
	case "off":
		delete(p.copyMode, e.src)
	default:
		p.copyMode[e.src] = switchTo
		delete(p.reFailed, e.src) // asked for: try again
	}
	// A movie that plays from a copy keeps doing so (after a jump, or when
	// the playlist comes round to it again).
	copyMode := p.copyMode[e.src]
	if p.reFailed[e.src] {
		copyMode = ""
	}
	p.mu.Unlock()
	if switchTo == "off" {
		p.dropReencode("")
	}
	if e.kind == entYouTube && p.base.YTPrefetch {
		path, title, err := p.downloadYouTube(ctx, e)
		if ctx.Err() != nil {
			return info, nil
		}
		switch {
		case err != nil:
			p.logf("YouTube: couldn't download it (%v); streaming it instead", err)
		case path != "":
			// Play the download like a file; the next one downloads meanwhile.
			// (Kept while jumping around in it.)
			orig := e.src
			defer func() {
				if !p.resuming(orig) {
					p.yt.forget(orig)
				}
			}()
			p.prefetchAfter(e)
			name := e.name
			if name == "" {
				name = title
			}
			e = entry{src: path, name: name, kind: entFile}
			src = path
			p.mu.Lock()
			p.nowTitle = name
			p.mu.Unlock()
		}
	}
	if e.kind == entYouTube {
		stream, aud, title, live, err := ytResolve(ctx, e.src)
		audioURL = aud
		if ctx.Err() != nil {
			return info, nil
		}
		if err != nil {
			return info, err
		}
		src, info.ytLive, info.recorded = stream, live, !live
		if title != "" && e.name == "" {
			p.mu.Lock()
			p.nowTitle = title
			p.nowDesc = strings.TrimSuffix(p.nowDesc, e.src) + title
			p.mu.Unlock()
		}
	}
	c := p.itemConfig(src)
	c.audioURL = audioURL
	c.seekSec = at
	if strings.EqualFold(src, "test") {
		p.subs.Store(nil)
		p.setAudio(ctx, c, false)
		runTestPattern(ctx, p.v, c.Cols, c.Rows, c.FPS)
		return info, nil
	}
	if isVisualizerSource(src) {
		// The visualizer for the microphone / line-in: this sound is the
		// broadcast's sound too, so no separate microphone runs.
		p.subs.Store(nil)
		p.stopAudio()
		ain, desc, err := audioInputArgs(c, p.ffmpeg)
		if err != nil {
			return info, err
		}
		p.logf("visualizer: listening to %s", desc)
		return info, runVisualizer(ctx, p.v, p.ffmpeg, ain, c, p.clock0, p.snd, false, p.base.Audio, false, p.logf)
	}
	file := e.kind == entFile
	media := file || isURL(src)
	// A web video with an end (an .mp4 link, a finished show, a YouTube
	// upload, an IPTV list's movie) is read at real speed, like a file;
	// a live stream already comes at real speed.
	if isURL(src) && e.kind != entYouTube {
		if st := probeStreams(ctx, p.ffmpeg, src); st.duration > 0 {
			info.recorded = true
		}
		if ctx.Err() != nil {
			return info, nil
		}
	}
	c.realtime = info.recorded
	once := file || info.recorded || info.ytLive
	if file || info.recorded {
		p.mu.Lock()
		p.seekable = true // it has an end: J and the arrow keys can jump in it
		p.mu.Unlock()
	}
	// Sound without a picture (a song, internet radio): the visualizer.
	if media {
		st := probeStreams(ctx, p.ffmpeg, src)
		if ctx.Err() != nil {
			return info, nil
		}
		if file || info.recorded {
			p.mu.Lock()
			p.dur = st.duration
			p.mu.Unlock()
		}
		if st.hasAudio && !st.hasVideo {
			return info, p.playMusic(ctx, c, e, st, once)
		}
	}
	if e.kind == entLive && !info.recorded {
		once = false
	}
	// A movie this PC couldn't decode fast enough: play its re-encoded copy
	// (made now, if it isn't already).
	if file && copyMode != "" {
		p.waitForCopy(ctx, c, src, copyMode)
		if ctx.Err() != nil {
			return info, nil
		}
	}
	input, autoFlip, _, err := videoInputArgs(c, p.ffmpeg)
	if err != nil {
		return info, err
	}
	flip := autoFlip
	if c.Flip == "1" {
		flip = true
	} else if c.Flip == "0" {
		flip = false
	}
	var subs *Subtitles
	if media {
		subs = setupSubtitles(ctx, c, p.ffmpeg, p.logf)
		if ctx.Err() != nil {
			return info, nil // skipped while checking the file
		}
		if subs != nil && subs.mode == "cc" && c.playFile != "" {
			// Closed captions ride in the original's picture, which a
			// re-encoded copy doesn't carry.
			p.logf("subtitles: the closed captions can't be shown while playing the re-encoded copy")
			subs = nil
		}
	}
	p.subs.Store(subs)

	// Picture and sound from ONE ffmpeg whenever they belong together, so
	// they're stamped by the same clock and can't drift apart:
	//   - a file or stream with its own sound (AUDIO_SOURCE=auto), and
	//   - a camera with a microphone (Windows: one DirectShow input).
	var av *avOut
	if p.base.Audio && p.base.SyncCapture {
		switch {
		case media && p.audioFollowsFile() && (subs == nil || subs.mode != "cc"):
			has := c.audioURL != "" || probeStreams(ctx, p.ffmpeg, src).hasAudio
			if has && c.playFile != "" && !probeStreams(ctx, p.ffmpeg, c.playFile).hasAudio {
				// A copy without the sound (ffmpeg couldn't convert it):
				// the sound comes from the original, from the same place.
				p.logf("the re-encoded copy has no sound track; playing the sound from the original file")
				has = false
			}
			if has {
				av = &avOut{clock0: p.clock0, snd: p.snd}
			}
			if ctx.Err() != nil {
				return info, nil
			}
		case !media:
			if ain, adesc, err := audioInputArgs(c, p.ffmpeg); err == nil {
				if merged, ok := mergeDshow(input, ain); ok {
					input = merged
					av = &avOut{clock0: p.clock0, snd: p.snd}
					p.logf("sound: %s, captured together with the picture", adesc)
				}
			}
		}
	}
	if av != nil {
		p.stopAudio() // this item brings its own sound
	} else {
		p.setAudio(ctx, c, media && p.audioFollowsFile())
	}
	err = p.runVideo(ctx, input, flip, subs, c, once, av)
	if c.playFile != "" && err != nil && ctx.Err() == nil {
		// The copy wouldn't play: play the original from the same place
		// rather than skip the movie.
		pos := p.Position()
		p.logf("the re-encoded copy wouldn't play (%v); playing the original from %s instead", err, clockTime(pos))
		p.mu.Lock()
		p.reFailed[src] = true
		delete(p.copyMode, src)
		p.mu.Unlock()
		p.dropReencode("")
		c.playFile, c.playOffset, c.growing, c.seekSec = "", 0, false, pos
		if input, _, _, err = videoInputArgs(c, p.ffmpeg); err != nil {
			return info, err
		}
		err = p.runVideo(ctx, input, flip, subs, c, once, av)
	}
	// A re-encoded copy still being made ran out before the end of the
	// movie: wait for more of it, then carry on from there.
	for c.playFile != "" && c.growing && err == nil && ctx.Err() == nil {
		pos := p.Position()
		if p.atEnd(pos) {
			break
		}
		c.seekSec = pos
		c.playFile, c.growing = "", false
		p.waitForCopy(ctx, c, src, copyMode)
		if ctx.Err() != nil {
			return info, nil
		}
		if input, _, _, err = videoInputArgs(c, p.ffmpeg); err != nil {
			return info, err
		}
		err = p.runVideo(ctx, input, flip, subs, c, once, av)
	}
	// YouTube's separate sound stream can stop partway (the link expires
	// or the server drops it): get fresh links and carry on from there.
	for tries := 0; tries < 5 && e.kind == entYouTube && ctx.Err() == nil; tries++ {
		var lost *soundLostError
		if !errors.As(err, &lost) {
			break
		}
		p.logf("YouTube: %v; picking up again from there", lost)
		stream, aud, _, _, rerr := ytResolve(ctx, e.src)
		if rerr != nil {
			if ctx.Err() == nil {
				p.logf("%v", rerr)
			}
			return info, nil // played most of it: go on to the next
		}
		c.Source, c.audioURL, c.seekSec = stream, aud, lost.at
		if input, _, _, err = videoInputArgs(c, p.ffmpeg); err != nil {
			return info, err
		}
		err = runFFmpegVideo(ctx, p.v, p.ffmpeg, input, flip, c.FPS, nil, c, once, av, p.logf)
	}
	var lost *soundLostError
	if errors.As(err, &lost) {
		p.logf("YouTube: %v; going on to the next video", lost)
		return info, nil
	}
	return info, err
}

// downloadYouTube gets a YouTube video onto this PC, showing progress on
// the status line. path "" (no error): a live stream, to be streamed.
func (p *Player) downloadYouTube(ctx context.Context, e entry) (path, title string, err error) {
	p.mu.Lock()
	if p.yt == nil {
		p.yt = newYTCache(p.ffmpeg, p.logf)
	}
	desc := p.nowDesc
	p.mu.Unlock()
	started := time.Now()
	// Viewers see the last picture, dimmed, with DOWNLOADING FROM YOUTUBE
	// and how far it's got (and the link to the server stays busy).
	var pctBits atomic.Uint64
	pctBits.Store(math.Float64bits(-1))
	stop := make(chan struct{})
	shown := make(chan struct{})
	go func() {
		defer close(shown)
		lo, hi := p.v.snapshot()
		t := time.NewTicker(time.Second)
		defer t.Stop()
		for first := true; ; first = false {
			if !first {
				select {
				case <-stop:
					return
				case <-ctx.Done():
					return
				case <-t.C:
				}
			}
			if time.Since(started) < 2*time.Second {
				continue // already downloaded (or nearly): no notice
			}
			last := "PLEASE WAIT"
			if v := math.Float64frombits(pctBits.Load()); v >= 0 {
				last = fmt.Sprintf("%.0f%%", v)
			}
			words := []string{"Downloading", "from YouTube", last}
			var hiPic []byte
			if p.v.HiW > 0 {
				hiPic = noticePicture(hi, p.v.HiW, p.v.HiH, words)
			}
			p.v.putHi(noticePicture(lo, p.v.W, p.v.H, words), hiPic, -1)
		}
	}()
	path, title, err = p.yt.wait(ctx, e.src, func(pct float64) {
		pctBits.Store(math.Float64bits(pct))
		p.mu.Lock()
		p.nowDesc = fmt.Sprintf("downloading %.0f%%: %s", pct, desc) // the status line is short: progress first
		p.mu.Unlock()
	})
	close(stop)
	<-shown
	p.mu.Lock()
	p.nowDesc = desc
	p.mu.Unlock()
	if err == nil && path != "" && time.Since(started) > 2*time.Second {
		p.logf("YouTube: downloaded in %.0f s", time.Since(started).Seconds())
	}
	return path, title, err
}

// prefetchAfter starts downloading the YouTube video after e, if any.
func (p *Player) prefetchAfter(e entry) {
	p.mu.Lock()
	var next entry
	for i, it := range p.items {
		if it.src == e.src {
			if i+1 < len(p.items) {
				next = p.items[i+1]
			} else if p.base.Loop && len(p.items) > 1 {
				next = p.items[0]
			}
			break
		}
	}
	p.mu.Unlock()
	if next.kind == entYouTube && next.src != e.src {
		p.yt.start(p.runCtx, next.src, false)
	}
}

// playMusic plays a song or a sound stream with the visualizer.
func (p *Player) playMusic(ctx context.Context, c *Config, e entry, st ffmpegStreams, once bool) error {
	if t := musicTitle(st, e); t != "" {
		p.mu.Lock()
		p.nowTitle = t
		p.mu.Unlock()
	}
	input, _, _, err := videoInputArgs(c, p.ffmpeg)
	if err != nil {
		return err
	}
	p.subs.Store(nil)
	own := p.audioFollowsFile()
	if own {
		p.stopAudio() // the song is the sound
	} else {
		p.setAudio(ctx, c, false) // AUDIO_SOURCE is something else: keep it
	}
	return runVisualizer(ctx, p.v, p.ffmpeg, input, c, p.clock0, p.snd, true, p.base.Audio && own, once, p.logf)
}

// musicTitle is "Artist - Title" from the song's tags, or its entry name.
func musicTitle(st ffmpegStreams, e entry) string {
	switch {
	case st.title != "" && st.artist != "":
		return st.artist + " - " + st.title
	case st.title != "":
		return st.title
	}
	return entryTitle(e)
}

// mergeDshow combines a DirectShow camera and microphone into one input
// ("video=Camera:audio=Mic"), which ffmpeg keeps in sync with each other.
func mergeDshow(video, audio []string) ([]string, bool) {
	isDshow := func(a []string) bool {
		for i := 0; i+1 < len(a); i++ {
			if a[i] == "-f" && a[i+1] == "dshow" {
				return true
			}
		}
		return false
	}
	inputOf := func(a []string) (int, string) {
		for i := 0; i+1 < len(a); i++ {
			if a[i] == "-i" {
				return i + 1, a[i+1]
			}
		}
		return -1, ""
	}
	if !isDshow(video) || !isDshow(audio) {
		return nil, false
	}
	vi, vname := inputOf(video)
	_, aname := inputOf(audio)
	if vi < 0 || !strings.HasPrefix(vname, "video=") || !strings.HasPrefix(aname, "audio=") {
		return nil, false
	}
	out := append([]string(nil), video[:vi-1]...)
	out = append(out, "-audio_buffer_size", "50", "-i", vname+":"+aname)
	out = append(out, video[vi+1:]...)
	return out, true
}

// Run plays sources until ctx ends. startup is the SOURCE setting; if it
// can't play at all the program stops, as it always has. Later problems
// (a bad file, a dead channel, a switch to a camera that isn't there) are
// logged and the player moves on or goes back to what it was playing.
func (p *Player) Run(ctx context.Context, startup string) {
	p.runCtx = ctx
	defer p.stopAudio()
	defer p.dropReencode("") // never leave a re-encoded copy behind
	if p.base.Reencode {
		cleanReencodeFolder(p.base)
	}
	defer func() {
		if p.yt != nil {
			p.yt.clear()
		}
	}()
	if err := p.load(ctx, startup, false); err != nil {
		p.v.fail(err, true)
		return
	}
	everPlayed := false
	var prevLive string
	var prevRoots []string
	failsInRow := 0
	var checking atomic.Bool // a YouTube "is it live?" check is running
	liveDrops := 0           // quick drops of a YouTube live stream in a row

	for ctx.Err() == nil {
		p.mu.Lock()
		live, n := p.live, len(p.items)
		var item entry
		if live == "" && n > 0 {
			if p.pos >= n {
				p.pos = 0
			}
			if p.pos < 0 {
				p.pos = n - 1
			}
			item = p.items[p.pos]
			p.nowDesc = fmt.Sprintf("%d/%d %s", p.pos+1, n, item.label())
			p.nowTitle = entryTitle(item)
		} else {
			item = entry{src: live, kind: entLive}
			p.nowDesc = live
			p.nowTitle = ""
		}
		pos, ytChannel := p.pos, p.ytChannel
		p.mu.Unlock()
		p.dropReencode(item.src) // a copy of the movie before this one is done with

		if live == "" {
			p.logf("playing %d/%d: %s", pos+1, n, item.label())
		} else {
			p.logf("playing: %s", item.src)
		}
		itemCtx, cancel := context.WithCancel(ctx)
		type result struct {
			info playInfo
			err  error
		}
		done := make(chan result, 1)
		started := time.Now()
		framesBefore := p.v.Seq()
		go func() {
			info, err := p.playOne(itemCtx, item)
			done <- result{info, err}
		}()

		// While a YouTube channel's uploads play, check now and then
		// whether the channel has gone live.
		var liveTick <-chan time.Time
		var ticker *time.Ticker
		if ytChannel != "" && item.kind == entYouTube {
			ticker = time.NewTicker(ytLiveCheck)
			liveTick = ticker.C
		}

		var cmd *playerCmd
		var res result
	wait:
		for {
			select {
			case res = <-done:
				break wait
			case <-liveTick:
				if checking.CompareAndSwap(false, true) {
					go func(ch string, playing string) {
						defer checking.Store(false)
						if e, ok := ytLiveNow(ctx, ch); ok && e.src != playing {
							select {
							case p.cmds <- playerCmd{kind: "golive", ready: true, ent: e}:
							default:
							}
						}
					}(ytChannel, item.src)
				}
			case c := <-p.cmds:
				// Commands that don't change what's on screen are handled
				// without interrupting it.
				if c.kind == "shuffle" {
					p.handle(ctx, c, &prevLive, &prevRoots)
					continue
				}
				// A jump, or a re-encoded copy taking over: the same item
				// starts again from another place.
				if c.kind == "seek" || c.kind == "reencode" {
					if c.kind == "seek" && !p.prepareJump(c, item) {
						continue
					}
					if c.kind == "reencode" && !p.prepareCopy(c.arg, item) {
						continue
					}
					cmd = &c
					cancel()
					res = <-done
					break wait
				}
				if (c.kind == "next" || c.kind == "prev" || c.kind == "goto") && live != "" {
					p.logf("next/back/list only work when playing a playlist (files, a folder, a channel list or YouTube)")
					continue
				}
				// Look a new source up before stopping the current one, so
				// a typo (or a slow channel list) doesn't interrupt what's
				// playing.
				if (c.kind == "switch" || c.kind == "add") && !c.ready {
					r, err := p.expand(ctx, c.arg)
					if err != nil {
						if ctx.Err() == nil {
							p.logf("%v", err)
						}
						continue
					}
					c.res, c.ready = r, true
				}
				if c.kind == "add" && live == "" && n > 0 && c.res.live == "" {
					p.handle(ctx, c, &prevLive, &prevRoots)
					continue
				}
				if c.kind == "golive" && (live != "" || ytChannel == "" || item.src == c.ent.src) {
					continue // not a channel's playlist any more, or already on it
				}
				cmd = &c
				cancel()
				res = <-done
				break wait
			case <-ctx.Done():
				cancel()
				<-done
				return
			}
		}
		cancel()
		if ticker != nil {
			ticker.Stop()
		}
		err := res.err
		if live == "" && p.audioFollowsFile() {
			p.stopAudio() // this item's sound ends with it
		}

		if cmd != nil {
			p.handle(ctx, *cmd, &prevLive, &prevRoots)
			failsInRow = 0
			continue
		}
		gotFrames := p.v.Seq() != framesBefore
		p.dropReencode("") // the movie is done: its re-encoded copy goes

		// A YouTube channel's live stream ended (or dropped): carry on with
		// it if it's still on air, otherwise go on with the uploads.
		if res.info.ytLive && live == "" && ytChannel != "" {
			if time.Since(started) > time.Minute {
				liveDrops = 0
			}
			if e, ok := ytLiveNow(ctx, ytChannel); ok && e.src == item.src && gotFrames && liveDrops < 4 {
				liveDrops++
				wait := time.Duration(1<<liveDrops) * time.Second // 2, 4, 8, 16 s
				p.logf("YouTube: the live stream dropped; reconnecting in %d s", int(wait.Seconds()))
				p.pause(ctx, wait, &prevLive, &prevRoots)
				continue
			}
			if liveDrops >= 4 {
				p.logf("YouTube: the live stream keeps dropping; playing the channel's videos and trying it again in a few minutes")
			} else {
				p.logf("YouTube: the live stream has ended; back to the channel's videos")
			}
			liveDrops = 0
			if !p.removeAt(pos) {
				p.waitForChannel(ctx, &prevLive, &prevRoots)
			}
			continue
		}

		if err != nil {
			failsInRow++
			if p.v.HasFrames() {
				everPlayed = true // something has been on screen: never quit over this
			}
			if !everPlayed && (live != "" || failsInRow >= n) {
				p.v.fail(err, true) // the SOURCE setting never worked
				return
			}
			if live != "" {
				p.logf("couldn't play %s (%v); going back to what was playing", live, err)
				p.restore(ctx, prevLive, prevRoots)
				continue
			}
			if item.kind == entStream {
				p.logf("channel %s isn't working (%v); going to the next one", item.label(), err)
			} else {
				p.logf("skipping %s (%v)", item.label(), err)
			}
			if failsInRow >= n {
				p.logf("none of the %d items would play; press S to choose another source", n)
				p.idleUntilCommand(ctx, &prevLive, &prevRoots)
				failsInRow = 0
				continue
			}
		} else {
			failsInRow = 0
			if time.Since(started) > 2*time.Second {
				everPlayed = true
			}
		}
		if live != "" {
			continue // live sources only stop on a command
		}
		everPlayed = true
		if p.takeUpNext() {
			continue // a viewer tagged what plays next
		}
		p.mu.Lock()
		p.pos++
		wrapped := p.pos >= len(p.items)
		p.mu.Unlock()
		if wrapped {
			if !p.base.Loop {
				p.logf("playlist finished; press S to choose another source")
				p.idleUntilCommand(ctx, &prevLive, &prevRoots)
				continue
			}
			p.rescan(ctx)
			p.mu.Lock()
			p.pos = 0
			p.mu.Unlock()
		}
	}
}

// removeAt takes one entry out of the playlist (a live stream that has
// ended); the next one moves into its place. False if the list is empty.
func (p *Player) removeAt(i int) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	if i < 0 || i >= len(p.items) {
		return len(p.items) > 0
	}
	gone := p.items[i].src
	p.items = append(p.items[:i:i], p.items[i+1:]...)
	for j, e := range p.ordered {
		if e.src == gone {
			p.ordered = append(p.ordered[:j:j], p.ordered[j+1:]...)
			break
		}
	}
	return len(p.items) > 0
}

// waitForChannel is for a YouTube channel with no videos whose live stream
// ended: look again every couple of minutes until it's back (or a key is
// pressed).
func (p *Player) waitForChannel(ctx context.Context, prevLive *string, prevRoots *[]string) {
	p.mu.Lock()
	p.nowDesc = "(waiting for the channel to go live)"
	p.mu.Unlock()
	p.logf("YouTube: nothing to play; checking the channel again every 2 minutes (or press S)")
	for ctx.Err() == nil {
		select {
		case c := <-p.cmds:
			p.handle(ctx, c, prevLive, prevRoots)
			return
		case <-ctx.Done():
			return
		case <-time.After(2 * time.Minute):
			p.rescan(ctx)
			p.mu.Lock()
			n := len(p.items)
			p.pos = 0
			p.mu.Unlock()
			if n > 0 {
				return
			}
		}
	}
}

// pause waits d, or less if a command comes in (it's carried out).
func (p *Player) pause(ctx context.Context, d time.Duration, prevLive *string, prevRoots *[]string) {
	select {
	case c := <-p.cmds:
		p.handle(ctx, c, prevLive, prevRoots)
	case <-ctx.Done():
	case <-time.After(d):
	}
}

func (p *Player) idleUntilCommand(ctx context.Context, prevLive *string, prevRoots *[]string) {
	p.mu.Lock()
	p.nowDesc = "(nothing playing)"
	p.nowTitle = ""
	p.mu.Unlock()
	select {
	case c := <-p.cmds:
		p.handle(ctx, c, prevLive, prevRoots)
	case <-ctx.Done():
	}
}

// restore goes back to what was playing before a failed switch.
func (p *Player) restore(ctx context.Context, live string, roots []string) {
	if live == "" && len(roots) == 0 {
		return
	}
	if live != "" {
		p.install(expanded{src: live, live: live}, false)
		return
	}
	p.mu.Lock()
	p.live, p.roots = "", roots
	p.mu.Unlock()
	p.rescan(ctx)
}

func (p *Player) handle(ctx context.Context, c playerCmd, prevLive *string, prevRoots *[]string) {
	p.mu.Lock()
	*prevLive, *prevRoots = p.live, append([]string(nil), p.roots...)
	p.mu.Unlock()
	if (c.kind == "switch" || c.kind == "add") && !c.ready {
		r, err := p.expand(ctx, c.arg)
		if err != nil {
			p.logf("%v", err)
			return
		}
		c.res, c.ready = r, true
	}
	switch c.kind {
	case "switch":
		if err := p.install(c.res, false); err != nil {
			p.logf("%v", err)
			return
		}
		if n := len(c.res.list); n > 1 {
			p.logf("new playlist: %d items from %s", n, c.res.src)
		}
	case "add":
		p.mu.Lock()
		before := len(p.items)
		wasLive := p.live != "" || before == 0
		p.mu.Unlock()
		if err := p.install(c.res, true); err != nil {
			p.logf("%v", err)
			return
		}
		if wasLive {
			p.logf("playlist started with %d item(s) from %s", len(c.res.list), c.res.src)
		} else {
			p.logf("added %d item(s) to the end of the playlist", len(c.res.list))
		}
	case "shuffle":
		on := c.arg == "on"
		p.setShuffle(on)
		p.mu.Lock()
		live, n := p.live, len(p.items)
		p.mu.Unlock()
		switch {
		case live != "":
			p.logf("shuffle %s (it applies when playing a playlist)", map[bool]string{true: "on", false: "off"}[on])
		case on:
			p.logf("shuffle on: the other %d item(s) will play in random order", n-1)
		default:
			p.logf("shuffle off: playing in list order from here")
		}
	case "next", "prev", "goto":
		p.mu.Lock()
		defer p.mu.Unlock()
		if p.live != "" || len(p.items) == 0 {
			p.logf("next/back/list only work when playing a playlist (files, a folder, a channel list or YouTube)")
			return
		}
		switch c.kind {
		case "next":
			if !p.takeUpNextLocked() { // tagged entries come first
				p.pos++
			}
		case "prev":
			p.pos--
		default:
			var i int
			if _, err := fmt.Sscan(c.arg, &i); err == nil && i >= 1 && i <= len(p.items) {
				p.pos = i - 1
				p.untagLocked(p.items[i-1].src) // playing now: no longer up next
			}
		}
	case "golive":
		// The channel went live while its uploads played: the live stream
		// goes in front of the interrupted video, which plays again after.
		p.mu.Lock()
		defer p.mu.Unlock()
		if p.live != "" || p.ytChannel == "" {
			return
		}
		for i, e := range p.items {
			if e.src == c.ent.src {
				p.pos = i
				return
			}
		}
		if p.pos < 0 || p.pos > len(p.items) {
			p.pos = 0
		}
		p.items = append(p.items[:p.pos:p.pos], append([]entry{c.ent}, p.items[p.pos:]...)...)
		p.ordered = append([]entry{c.ent}, p.ordered...)
		p.logf("YouTube: the channel just went live: %s", c.ent.name)
	}
}

// resuming reports whether item src is about to start again from another
// place (a jump), without taking the resume point.
func (p *Player) resuming(src string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.resume != nil && p.resume.src == src
}

// atEnd reports whether pos is the end of the movie playing.
func (p *Player) atEnd(pos float64) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.dur > 0 && pos >= p.dur-3
}

// runVideo plays the video. When it plays a re-encoded copy that's still
// being made, it stops at the end of the movie by itself (ffmpeg would
// otherwise wait at the end of the file for more that never comes).
func (p *Player) runVideo(ctx context.Context, input []string, flip bool, subs *Subtitles, c *Config, once bool, av *avOut) error {
	if c.playFile == "" || !c.growing {
		return runFFmpegVideo(ctx, p.v, p.ffmpeg, input, flip, c.FPS, subs, c, once, av, p.logf)
	}
	p.mu.Lock()
	re := p.re
	p.mu.Unlock()
	rctx, stop := context.WithCancel(ctx)
	defer stop()
	go func() {
		t := time.NewTicker(250 * time.Millisecond)
		defer t.Stop()
		for {
			select {
			case <-rctx.Done():
				return
			case <-t.C:
			}
			if re == nil {
				continue
			}
			enc, done, _ := re.state()
			if done && p.Position() >= re.start+enc-0.3 {
				stop() // the whole copy has played
				return
			}
		}
	}()
	return runFFmpegVideo(rctx, p.v, p.ffmpeg, input, flip, c.FPS, subs, c, once, av, p.logf)
}

// waitForCopy gets the re-encoded copy of movie src ready to play from
// c.seekSec: it starts making one (from that place) if there's none that
// covers it, and waits - viewers see the last picture dimmed, with a
// please-wait notice - until enough of it is made. Then c plays the copy.
// If the copy can't be made, c plays the original as before.
func (p *Player) waitForCopy(ctx context.Context, c *Config, src, mode string) {
	at := c.seekSec
	p.mu.Lock()
	re, dur := p.re, p.dur
	p.mu.Unlock()
	if re != nil && (re.src != src || re.mode != mode || !re.has(at)) {
		p.dropReencode("") // a copy of something else, another kind, or another part
		re = nil
	}
	fail := func(err error) {
		p.logf("re-encoding: %v; playing the original from %s instead", err, clockTime(at))
		p.mu.Lock()
		p.reFailed[src] = true
		p.mu.Unlock()
		p.dropReencode("")
	}
	if re == nil {
		r, err := startReencode(p.runCtx, p.ffmpeg, c, src, mode, at, dur, p.logf)
		if err != nil {
			fail(err)
			return
		}
		p.mu.Lock()
		p.re = r
		p.mu.Unlock()
		re = r
	}
	if ok, _ := re.ready(at); !ok {
		p.mu.Lock()
		desc := p.nowDesc
		p.mu.Unlock()
		lo, hi := p.v.snapshot()
		p.logf("playback stopped; viewers see a please-wait notice until the copy is made")
		defer func() {
			p.setNotice("")
			p.mu.Lock()
			p.nowDesc = desc
			p.mu.Unlock()
		}()
		p.subs.Store(nil)
		tick := time.NewTicker(500 * time.Millisecond)
		defer tick.Stop()
		for {
			if _, _, err := re.state(); err != nil {
				fail(err)
				return
			}
			ok, eta := re.ready(at)
			if ok {
				break
			}
			pct := ""
			if v := re.percent(); v >= 0 {
				pct = fmt.Sprintf(" %.0f%%", v)
			}
			if a := aboutText(eta); a != "" {
				pct += ", " + a
			}
			p.setNotice("Re-encoding this video so it plays smoothly. Please wait..." + pct)
			p.mu.Lock()
			p.nowDesc = "re-encoding" + pct + " - please wait"
			p.mu.Unlock()
			// The notice, in big letters in the middle of the picture.
			words := []string{"Re-encoding", "Please wait", noticeProgress(re.percent(), eta)}
			var hiPic []byte
			if p.v.HiW > 0 {
				hiPic = noticePicture(hi, p.v.HiW, p.v.HiH, words)
			}
			p.v.putHi(noticePicture(lo, p.v.W, p.v.H, words), hiPic, -1)
			select {
			case <-ctx.Done():
				return
			case <-tick.C:
			}
		}
	}
	_, done, _ := re.state()
	c.playFile, c.playOffset, c.growing = re.path, re.start, !done
}

// prepareJump works out where a "seek" command goes and sets the item to
// start again from there. False if the item can't be jumped in.
func (p *Player) prepareJump(c playerCmd, item entry) bool {
	p.mu.Lock()
	ok, dur := p.seekable, p.dur
	p.mu.Unlock()
	if !ok {
		p.logf("jumping (J, arrow keys) only works in videos and songs that have an end, not live sources")
		return false
	}
	target := p.Position()
	apply := func(arg string) {
		if len(arg) < 2 {
			return
		}
		s, err := strconv.ParseFloat(arg[1:], 64)
		if err != nil {
			return
		}
		switch arg[0] {
		case '+':
			target += s
		case '-':
			target -= s
		default:
			target = s
		}
	}
	apply(c.arg)
	// Several arrow presses in a row: one jump to where they add up to.
	var other []playerCmd
	for more := true; more; {
		select {
		case n := <-p.cmds:
			if n.kind == "seek" {
				apply(n.arg)
			} else {
				other = append(other, n)
			}
		default:
			more = false
		}
	}
	for _, o := range other {
		select {
		case p.cmds <- o:
		default:
		}
	}
	if dur > 0 && target > dur-2 {
		target = max(0, dur-2)
	}
	target = max(0, target)
	p.mu.Lock()
	p.resume = &resumePoint{src: item.src, at: target}
	p.mu.Unlock()
	if dur > 0 {
		p.logf("jumping to %s of %s", clockTime(target), clockTime(dur))
	} else {
		p.logf("jumping to %s", clockTime(target))
	}
	return true
}

// PlaylistInfo is the playlist for viewers: what's playing (-1 = none),
// the entries tagged to play next (in order), and every entry's name.
// Nothing for a live source.
func (p *Player) PlaylistInfo() (cur int, upNext []int, names []string) {
	names = p.Names()
	p.mu.Lock()
	defer p.mu.Unlock()
	if p.live != "" || len(p.items) == 0 {
		return -1, nil, nil
	}
	cur = p.pos
	for _, src := range p.upNext {
		for i, e := range p.items {
			if e.src == src {
				upNext = append(upNext, i)
				break
			}
		}
	}
	return cur, upNext, names
}

// ToggleUpNext tags entry i to play next (after any already tagged), or
// untags it. It reports whether it's tagged now.
func (p *Player) ToggleUpNext(i int) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	if i < 0 || i >= len(p.items) {
		return false
	}
	src := p.items[i].src
	for k, s := range p.upNext {
		if s == src {
			p.upNext = append(p.upNext[:k], p.upNext[k+1:]...)
			return false
		}
	}
	p.upNext = append(p.upNext, src)
	return true
}

// takeUpNext moves to the first tagged entry still in the playlist, if
// any, and untags it. It reports whether it did.
func (p *Player) takeUpNext() bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	return p.takeUpNextLocked()
}

func (p *Player) untagLocked(src string) {
	for k, s := range p.upNext {
		if s == src {
			p.upNext = append(p.upNext[:k], p.upNext[k+1:]...)
			return
		}
	}
}

func (p *Player) takeUpNextLocked() bool {
	for len(p.upNext) > 0 {
		src := p.upNext[0]
		p.upNext = p.upNext[1:]
		for i, e := range p.items {
			if e.src == src {
				p.pos = i
				return true
			}
		}
	}
	return false
}

// prepareCopy sets the item to start again from where it is, via a
// re-encoded copy: arg "" = by itself (REENCODE=1, too slow), copy720 /
// copyHalf = asked for with E, "off" = back to the original. False if
// that can't be done now.
func (p *Player) prepareCopy(arg string, item entry) bool {
	at := p.Position()
	mode := arg
	if arg == "" {
		if !p.CanReencode() {
			return false
		}
		mode = copy720
		if strings.EqualFold(strings.TrimSpace(p.base.ReencodeMode), copyHalf) {
			mode = copyHalf
		}
		p.logf("this PC can't decode it fast enough; making a %s and playing it from %s (REENCODE=1)", copyName(mode), clockTime(at))
	} else {
		p.mu.Lock()
		ok := p.live == "" && item.kind == entFile && p.seekable
		cur := p.copyMode[item.src]
		p.mu.Unlock()
		switch {
		case !ok || !probeStreams(context.Background(), p.ffmpeg, item.src).hasVideo:
			p.logf("re-encoding (E) only works for video files on this PC")
			return false
		case arg == "off" && cur == "":
			p.logf("this movie is already playing from its original file")
			return false
		case arg == cur:
			p.logf("this movie is already playing from a %s", copyName(arg))
			return false
		case arg == "off":
			p.logf("back to the original file, from %s", clockTime(at))
		default:
			p.logf("making a %s and playing it from %s", copyName(arg), clockTime(at))
		}
	}
	p.mu.Lock()
	p.resume = &resumePoint{src: item.src, at: at, copy: mode}
	p.mu.Unlock()
	return true
}

// noticeProgress is the please-wait picture's last line: "35% - 4 MIN".
func noticeProgress(pct float64, eta time.Duration) string {
	s := ""
	if pct >= 0 {
		s = fmt.Sprintf("%.0f%%", pct)
	}
	left := ""
	switch {
	case eta <= 0:
	case eta < 90*time.Second:
		left = "1 MIN"
	case eta < 90*time.Minute:
		left = fmt.Sprintf("%d MIN", int(eta.Minutes()+0.5))
	default:
		left = fmt.Sprintf("%.1f HRS", eta.Hours())
	}
	switch {
	case s != "" && left != "":
		return s + " - " + left
	case s != "":
		return s
	}
	return left
}
