//go:build !windows

package main

// listScreens: monitors can't be listed here (Windows only); screen and
// screen:X,Y,WxH still work.
func listScreens() []screenInfo { return nil }

func windowTitles() []string { return nil }
