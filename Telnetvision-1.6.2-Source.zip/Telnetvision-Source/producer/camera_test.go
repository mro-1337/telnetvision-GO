package main

import (
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestCameraPicker(t *testing.T) {
	c := newControls(&Config{})
	c.cameras = func() []string { return []string{"Logitech C920", "OBS Virtual Camera"} }
	saved := ""
	c.saveDefault = func(src string) error { saved = src; return nil }
	c.key('d')
	for i := 0; i < 100; i++ {
		c.mu.Lock()
		p := c.prompt
		c.mu.Unlock()
		if p == "camera" {
			break
		}
		time.Sleep(10 * time.Millisecond)
	}
	for _, k := range []byte("2\r") {
		c.key(k)
	}
	if a := <-c.actions; a.kind != "switch" || a.arg != "camera:OBS Virtual Camera" {
		t.Fatalf("picked %+v", a)
	}
	c.key('y')
	if saved != "camera:OBS Virtual Camera" {
		t.Errorf("saved %q", saved)
	}
	// N: plays, but isn't saved.
	saved = ""
	c.key('d')
	time.Sleep(100 * time.Millisecond)
	for _, k := range []byte("1\rn") {
		c.key(k)
	}
	<-c.actions
	if saved != "" {
		t.Errorf("saved %q after N", saved)
	}
}

func TestSaveDefaultSource(t *testing.T) {
	path := filepath.Join(t.TempDir(), "telnetvision.ini")
	c := defaultConfig()
	c.Host, c.Token, c.Source, c.FPS = "bbs.example", "secret", "C:\\Movies", 12
	if err := c.save(path); err != nil {
		t.Fatal(err)
	}
	if err := saveDefaultSource(path, &c, "camera:Logitech C920"); err != nil {
		t.Fatal(err)
	}
	b, _ := os.ReadFile(path)
	s := string(b)
	for _, want := range []string{"SOURCE=camera:Logitech C920", "BBS_HOST=bbs.example", "TOKEN=secret", "FPS=12"} {
		if !strings.Contains(s, want) {
			t.Errorf("missing %q", want)
		}
	}
	if strings.Contains(s, "SOURCE=C:\\Movies") {
		t.Error("the old SOURCE is still there")
	}
}
