//go:build !windows

package main

import (
	"bytes"
	"os"
	"os/exec"
	"syscall"
)

// Non-Windows builds exist for development and testing.

type consoleState struct{ raw bool }

func isConsole() bool {
	a, err1 := os.Stdin.Stat()
	b, err2 := os.Stdout.Stat()
	return err1 == nil && err2 == nil && a.Mode()&os.ModeCharDevice != 0 && b.Mode()&os.ModeCharDevice != 0
}

func setupConsole() (*consoleState, bool) { return &consoleState{}, true }

func (st *consoleState) rawInput() {
	cmd := exec.Command("stty", "-icanon", "-echo", "min", "1")
	cmd.Stdin = os.Stdin
	st.raw = cmd.Run() == nil
}

func (st *consoleState) restore() {
	if st != nil && st.raw {
		cmd := exec.Command("stty", "icanon", "echo")
		cmd.Stdin = os.Stdin
		cmd.Run()
	}
}

func setTitle(string)             {}
func launchedByDoubleClick() bool { return false }

// hideWindow (non-Windows): give ffmpeg its own process group so
// killTree can stop it together with anything it starts.
func hideWindow(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{Setpgid: true}
}

// readKeys delivers raw input bytes (non-Windows builds, for development).
func readKeys(deliver func([]byte) bool) {
	buf := make([]byte, 256)
	for {
		n, err := os.Stdin.Read(buf)
		if err != nil || n == 0 {
			return
		}
		b := append([]byte(nil), buf[:n]...)
		// Arrow keys come as escape sequences in a terminal.
		b = bytes.ReplaceAll(b, []byte("\x1b[D"), []byte{keyLeft})
		b = bytes.ReplaceAll(b, []byte("\x1b[C"), []byte{keyRight})
		if !deliver(b) {
			return
		}
	}
}

// killTree stops ffmpeg and anything it started (its process group).
func killTree(cmd *exec.Cmd) error {
	if cmd.Process == nil {
		return nil
	}
	syscall.Kill(-cmd.Process.Pid, syscall.SIGKILL)
	return cmd.Process.Kill()
}

// pasteMark: Windows marks pastes it reads off the clipboard with it;
// terminals elsewhere paste by typing, which controls.paste handles.
const pasteMark = 0x16
