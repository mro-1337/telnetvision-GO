package main

// Screen capture sources:
//
//	screen            every monitor together (the whole desktop)
//	screen1, screen2  one monitor: 1 is the main one, then left to right
//	screen:X,Y,WxH    a region (pixels, from the main monitor's top left)
//	window:Title      one window, by (the start of) its title
//
// "screen 2", "screen:2", "monitor2" and "display2" mean screen2 too.

import (
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

// screenInfo is one monitor (or a region) in desktop pixels.
type screenInfo struct {
	X, Y, W, H int
	Primary    bool
	Device     string // \\.\DISPLAY2 on Windows
}

func (s screenInfo) String() string {
	p := ""
	if s.Primary {
		p = ", main"
	}
	return fmt.Sprintf("%dx%d at %d,%d%s", s.W, s.H, s.X, s.Y, p)
}

// screenSource is a parsed screen-capture SOURCE.
type screenSource struct {
	kind   string // "all" | "index" | "region" | "window"
	index  int    // 1-based, for "index"
	region screenInfo
	title  string // for "window"
}

var (
	reScreenN      = regexp.MustCompile(`^(?:screen|monitor|display|desktop)[ :#]?(\d+)$`)
	reScreenRegion = regexp.MustCompile(`^(?:screen|desktop):\s*(-?\d+)\s*,\s*(-?\d+)\s*,\s*(\d+)\s*x\s*(\d+)$`)
)

// parseScreenSource recognises the screen sources above.
func parseScreenSource(src string) (screenSource, bool) {
	s := strings.TrimSpace(src)
	low := strings.ToLower(s)
	switch {
	case low == "screen" || low == "desktop" || low == "screens" || low == "screen:all":
		return screenSource{kind: "all"}, true
	case strings.HasPrefix(low, "window:"):
		t := strings.TrimSpace(s[len("window:"):])
		return screenSource{kind: "window", title: t}, t != ""
	}
	if m := reScreenN.FindStringSubmatch(low); m != nil {
		n, _ := strconv.Atoi(m[1])
		return screenSource{kind: "index", index: n}, n >= 1
	}
	if m := reScreenRegion.FindStringSubmatch(low); m != nil {
		x, _ := strconv.Atoi(m[1])
		y, _ := strconv.Atoi(m[2])
		w, _ := strconv.Atoi(m[3])
		h, _ := strconv.Atoi(m[4])
		return screenSource{kind: "region", region: screenInfo{X: x, Y: y, W: w, H: h}}, w > 0 && h > 0
	}
	return screenSource{}, false
}

func isScreenSource(src string) bool {
	_, ok := parseScreenSource(src)
	return ok
}

// orderScreens puts the main monitor first, then the rest left to right
// (top to bottom when they're stacked).
func orderScreens(s []screenInfo) {
	sort.SliceStable(s, func(i, j int) bool {
		if s[i].Primary != s[j].Primary {
			return s[i].Primary
		}
		if s[i].X != s[j].X {
			return s[i].X < s[j].X
		}
		return s[i].Y < s[j].Y
	})
}

// screenCaptureArgs makes ffmpeg's input arguments for a screen source.
func screenCaptureArgs(ss screenSource, fps string, goos string, display string, screens []screenInfo) ([]string, string, error) {
	if goos == "windows" {
		base := []string{"-f", "gdigrab", "-framerate", fps, "-draw_mouse", "1"}
		region := func(r screenInfo) []string {
			// gdigrab measures from the main monitor's top left, so a
			// monitor to its left has a negative X - just what Windows says.
			w, h := r.W&^1, r.H&^1 // even sizes keep every encoder happy
			return append(base, "-offset_x", strconv.Itoa(r.X), "-offset_y", strconv.Itoa(r.Y),
				"-video_size", fmt.Sprintf("%dx%d", w, h), "-i", "desktop")
		}
		switch ss.kind {
		case "all":
			return append(base, "-i", "desktop"), "screen capture (all screens)", nil
		case "window":
			return append(base, "-i", "title="+ss.title), "window \"" + ss.title + "\"", nil
		case "region":
			return region(ss.region), "screen region " + ss.region.String(), nil
		case "index":
			if len(screens) == 0 {
				return nil, "", fmt.Errorf("couldn't list the monitors; use screen (all of them) or screen:X,Y,WxH")
			}
			if ss.index > len(screens) {
				return nil, "", fmt.Errorf("there's no screen%d: this PC has %d screen(s) (telnetvision.exe --list-devices lists them)", ss.index, len(screens))
			}
			sc := screens[ss.index-1]
			return region(sc), fmt.Sprintf("screen%d (%s)", ss.index, sc), nil
		}
	}
	base := []string{"-f", "x11grab", "-framerate", fps, "-draw_mouse", "1"}
	switch ss.kind {
	case "all":
		return append(base, "-i", display), "screen capture", nil
	case "region":
		r := ss.region
		return append(base, "-video_size", fmt.Sprintf("%dx%d", r.W&^1, r.H&^1), "-i", fmt.Sprintf("%s+%d,%d", display, r.X, r.Y)), "screen region " + r.String(), nil
	case "window":
		return nil, "", fmt.Errorf("window: capture works on Windows only")
	}
	if len(screens) >= ss.index {
		r := screens[ss.index-1]
		return append(base, "-video_size", fmt.Sprintf("%dx%d", r.W&^1, r.H&^1), "-i", fmt.Sprintf("%s+%d,%d", display, r.X, r.Y)), fmt.Sprintf("screen%d", ss.index), nil
	}
	return nil, "", fmt.Errorf("picking a screen by number works on Windows; here use screen:X,Y,WxH")
}

// matchWindowTitle finds the full title of the window whose title is or
// contains part (any case), front-most first. ffmpeg needs it exactly.
func matchWindowTitle(titles []string, part string) string {
	p := strings.ToLower(strings.TrimSpace(part))
	for _, t := range titles {
		if strings.ToLower(t) == p {
			return t
		}
	}
	for _, t := range titles {
		if strings.Contains(strings.ToLower(t), p) {
			return t
		}
	}
	return ""
}
