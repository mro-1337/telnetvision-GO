package main

import (
	"context"
	"os"
	"path/filepath"
	"reflect"
	"sync"
	"testing"
	"time"
)

const sampleM3U = "\ufeff#EXTM3U x-tvg-url=\"http://epg\"\n" +
	"#EXTINF:-1 tvg-id=\"cnn.us\" tvg-name=\"CNN\" tvg-logo=\"http://l/cnn.png\" group-title=\"News, US\",CNN HD\n" +
	"http://iptv.example/live/u/p/101.ts\n" +
	"\n" +
	"#EXTINF:-1 group-title=\"Sports\",ESPN\n" +
	"#EXTVLCOPT:http-user-agent=Mozilla/5.0 Test\n" +
	"#EXTVLCOPT:http-referrer=http://ref.example/\n" +
	"http://iptv.example/live/u/p/202.m3u8\n" +
	"#EXTINF:-1 tvg-name=\"Only Tvg Name\",\n" +
	"http://iptv.example/x.ts|User-Agent=Kodi%2F20&Referer=http://r/&X-Token=abc\n" +
	"#EXTINF:0,Relative\n" +
	"chunks/stream.m3u8\n" +
	"#EXTGRP:Music\n" +
	"#EXTINF:-1,Video\n" +
	"https://www.youtube.com/watch?v=abc123\n"

func TestParseM3U(t *testing.T) {
	list := parseM3U([]byte(sampleM3U), "http://iptv.example/get.php?u=1&type=m3u_plus")
	if len(list) != 5 {
		t.Fatalf("got %d entries: %+v", len(list), list)
	}
	want := []entry{
		{src: "http://iptv.example/live/u/p/101.ts", name: "CNN HD", group: "News, US", kind: entStream},
		{src: "http://iptv.example/live/u/p/202.m3u8", name: "ESPN", group: "Sports", kind: entStream},
		{src: "http://iptv.example/x.ts", name: "Only Tvg Name", kind: entStream},
		{src: "http://iptv.example/chunks/stream.m3u8", name: "Relative", kind: entStream},
		{src: "https://www.youtube.com/watch?v=abc123", name: "Video", group: "Music", kind: entYouTube},
	}
	if !reflect.DeepEqual(list, want) {
		t.Fatalf("got  %+v\nwant %+v", list, want)
	}
	if got := inputOptsFor(want[1].src); !reflect.DeepEqual(got, []string{"-user_agent", "Mozilla/5.0 Test", "-referer", "http://ref.example/"}) {
		t.Errorf("EXTVLCOPT options %q", got)
	}
	if got := inputOptsFor(want[2].src); !reflect.DeepEqual(got, []string{"-user_agent", "Kodi/20", "-referer", "http://r/", "-headers", "X-Token: abc\r\n"}) {
		t.Errorf("pipe options %q", got)
	}
	if inputOptsFor(want[0].src) != nil {
		t.Error("CNN has no options")
	}
}

func TestM3UOnDisk(t *testing.T) {
	d := t.TempDir()
	os.MkdirAll(filepath.Join(d, "shows"), 0o755)
	os.WriteFile(filepath.Join(d, "shows", "ep1.mp4"), []byte("x"), 0o644)
	list := filepath.Join(d, "mine.m3u")
	os.WriteFile(list, []byte("#EXTM3U\n#EXTINF:12,Episode One\nshows/ep1.mp4\nshows/missing.mp4\nrtsp://cam/1\n"), 0o644)
	p := &Player{logf: func(string, ...any) {}}
	r, err := p.expand(context.Background(), `"`+list+`"`)
	if err != nil {
		t.Fatal(err)
	}
	if r.live != "" || len(r.list) != 2 || r.list[0].kind != entFile || r.list[0].name != "Episode One" ||
		r.list[1].src != "rtsp://cam/1" || r.list[1].kind != entStream {
		t.Fatalf("%+v", r)
	}
	// An HLS stream saved as .m3u8 is one stream, not a list.
	hls := filepath.Join(d, "one.m3u8")
	os.WriteFile(hls, []byte("#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:6\n#EXTINF:6.0,\nseg0.ts\n"), 0o644)
	if r, err := p.expand(context.Background(), hls); err != nil || r.live != hls {
		t.Fatalf("HLS file: %+v %v", r, err)
	}
	empty := filepath.Join(d, "empty.m3u")
	os.WriteFile(empty, []byte("#EXTM3U\n"), 0o644)
	if _, err := p.expand(context.Background(), empty); err == nil {
		t.Fatal("an empty list should be an error")
	}
}

func TestLooksLikeM3U(t *testing.T) {
	for s, want := range map[string]bool{
		"http://h/list.m3u":                         true,
		"http://h/live/x.M3U8?token=1":              true,
		"http://h/get.php?username=a&type=m3u_plus": true,
		`C:\TV\channels.m3u`:                        true,
		"http://h/stream.ts":                        false,
		"rtsp://cam/1":                              false,
		`C:\Movies\a.mp4`:                           false,
	} {
		if looksLikeM3U(s) != want {
			t.Errorf("%s: want %v", s, want)
		}
	}
}

func TestYouTubeKind(t *testing.T) {
	for in, want := range map[string][2]string{
		"https://www.youtube.com/@NASA":                          {"channel", "https://www.youtube.com/@NASA"},
		"https://youtube.com/@NASA/videos":                       {"channel", "https://www.youtube.com/@NASA"},
		"https://www.youtube.com/@NASA/live":                     {"channel", "https://www.youtube.com/@NASA"},
		"https://m.youtube.com/channel/UC_x5XG1OV2P6uZZ5FSM9Ttw": {"channel", "https://www.youtube.com/channel/UC_x5XG1OV2P6uZZ5FSM9Ttw"},
		"https://www.youtube.com/c/Name/streams":                 {"channel", "https://www.youtube.com/c/Name"},
		"https://www.youtube.com/user/old":                       {"channel", "https://www.youtube.com/user/old"},
		"https://www.youtube.com/watch?v=abc&t=10":               {"video", "https://www.youtube.com/watch?v=abc&t=10"},
		"https://youtu.be/abc":                                   {"video", "https://youtu.be/abc"},
		"https://www.youtube.com/live/abc":                       {"video", "https://www.youtube.com/live/abc"},
		"https://www.youtube.com/playlist?list=PL1":              {"playlist", "https://www.youtube.com/playlist?list=PL1"},
		"https://www.youtube.com/watch?v=abc&list=PL1&index=3":   {"playlist", "https://www.youtube.com/watch?v=abc&list=PL1&index=3"},
		"https://youtu.be/abc?list=PL1":                          {"playlist", "https://youtu.be/abc?list=PL1"},
	} {
		k, b := youTubeKind(in)
		if k != want[0] || b != want[1] {
			t.Errorf("%s: got %s %s", in, k, b)
		}
	}
	if ytVideoID("https://www.youtube.com/watch?v=abc&list=PL1") != "abc" || ytVideoID("https://youtu.be/xyz?list=P") != "xyz" {
		t.Error("ytVideoID")
	}
	if !isYouTubeURL("https://youtu.be/x") || isYouTubeURL("https://notyoutube.com/x") || isYouTubeURL("youtube.com/@x") {
		t.Error("isYouTubeURL")
	}
}

func TestPickEntryAndList(t *testing.T) {
	names := []string{"CNN HD  [News]", "BBC One  [UK]", "BBC News  [News]", "ESPN  [Sports]"}
	for q, want := range map[string]int{"2": 1, "bbc news": 2, "news": 0, "ESPN": 3, " 4 ": 3} {
		if i, ok := pickEntry(names, q); !ok || i != want {
			t.Errorf("%q: got %d %v", q, i, ok)
		}
	}
	for _, q := range []string{"9", "0", "fox"} {
		if _, ok := pickEntry(names, q); ok {
			t.Errorf("%q should not match", q)
		}
	}
	c := newControls(&Config{})
	c.lister = func() []string { return names }
	c.key('l')
	if l, _, on := c.promptLine(); !on || l == "" {
		t.Fatal("L should open the list line")
	}
	if !c.takeListPrint() || c.takeListPrint() {
		t.Fatal("opening the list prints it once")
	}
	for _, b := range []byte("bbc") {
		c.key(b)
	}
	if ll := c.listLines(10); len(ll) != 3 {
		t.Fatalf("list lines %q", ll)
	}
	c.key('\t')
	if !c.takeListPrint() {
		t.Fatal("Tab prints the matches")
	}
	c.key('\r')
	select {
	case a := <-c.actions:
		if a.kind != "goto" || a.arg != "2" {
			t.Fatalf("%+v", a)
		}
	case <-time.After(time.Second):
		t.Fatal("Enter should pick the first match")
	}
	// Without a playlist, L just says so.
	c2 := newControls(&Config{})
	c2.lister = func() []string { return nil }
	c2.key('L')
	if _, _, on := c2.promptLine(); on || c2.flashText() == "" {
		t.Fatal("L without a playlist")
	}
}

func TestGoLiveAndRemove(t *testing.T) {
	p := &Player{logf: func(string, ...any) {}, ytChannel: "https://www.youtube.com/@x"}
	up := func(id string) entry { return entry{src: "https://www.youtube.com/watch?v=" + id, kind: entYouTube} }
	p.items = []entry{up("a"), up("b"), up("c")}
	p.ordered = append([]entry(nil), p.items...)
	p.pos = 1
	var pl string
	var pr []string
	liveE := up("LIVE")
	liveE.name = "Live now"
	p.handle(context.Background(), playerCmd{kind: "golive", ready: true, ent: liveE}, &pl, &pr)
	if p.pos != 1 || p.items[1].src != liveE.src || p.items[2].src != up("b").src || len(p.items) != 4 {
		t.Fatalf("golive: pos %d %+v", p.pos, p.items)
	}
	// The same live stream again just goes to it.
	p.pos = 3
	p.handle(context.Background(), playerCmd{kind: "golive", ready: true, ent: liveE}, &pl, &pr)
	if p.pos != 1 || len(p.items) != 4 {
		t.Fatal("golive twice")
	}
	// When it ends it comes out, and the interrupted video is next.
	if !p.removeAt(1) || len(p.items) != 3 || p.items[1].src != up("b").src || len(p.ordered) != 3 {
		t.Fatalf("remove: %+v", p.items)
	}
	p.items, p.ordered = []entry{liveE}, []entry{liveE}
	if p.removeAt(0) {
		t.Fatal("empty list after removing the only entry")
	}
}

func TestGotoCommand(t *testing.T) {
	p := &Player{logf: func(string, ...any) {}, items: make([]entry, 5)}
	var pl string
	var pr []string
	p.handle(context.Background(), playerCmd{kind: "goto", arg: "4"}, &pl, &pr)
	if p.pos != 3 {
		t.Fatalf("pos %d", p.pos)
	}
	p.handle(context.Background(), playerCmd{kind: "goto", arg: "99"}, &pl, &pr)
	if p.pos != 3 {
		t.Fatal("out of range goto is ignored")
	}
}

func TestFramePacer(t *testing.T) {
	var mu sync.Mutex
	var at []time.Time
	p := newFramePacer(20, func(b []byte, pts int64) {
		mu.Lock()
		at = append(at, time.Now())
		mu.Unlock()
	})
	// A clump of 6 frames at once comes out evenly, 50 ms apart.
	for i := 0; i < 6; i++ {
		p.add([]byte{byte(i)}, int64(i))
	}
	p.close(false)
	if len(at) != 6 {
		t.Fatalf("%d frames", len(at))
	}
	for i := 1; i < len(at); i++ {
		if d := at[i].Sub(at[i-1]); d < 35*time.Millisecond || d > 90*time.Millisecond {
			t.Errorf("gap %d: %s", i, d)
		}
	}
	// The queue holds about half a second; a big clump keeps the newest.
	var got []int64
	p = newFramePacer(10, func(b []byte, pts int64) { got = append(got, pts) })
	for i := 0; i < 40; i++ {
		p.add(nil, int64(i))
	}
	p.close(false)
	if len(got) > 8 || got[len(got)-1] != 39 {
		t.Fatalf("kept %v", got)
	}
	// Switching away drops what's queued.
	n := 0
	p = newFramePacer(10, func([]byte, int64) { n++ })
	for i := 0; i < 5; i++ {
		p.add(nil, 0)
	}
	start := time.Now()
	p.close(true)
	if n > 1 || time.Since(start) > 150*time.Millisecond {
		t.Fatalf("discard: %d frames, %s", n, time.Since(start))
	}
}
