package main

// IPTV channel lists (.m3u / .m3u8 files or links). Each #EXTINF entry
// becomes a channel in the playlist; N/B step through them and L lists
// them. HLS stream playlists (also .m3u8, but one stream cut into pieces)
// are told apart by their #EXT-X- tags and played as a single stream.

import (
	"bufio"
	"bytes"
	"context"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// entry kinds
const (
	entFile    = iota // a video file on this PC
	entStream         // a stream URL (an IPTV channel, a web video)
	entYouTube        // a YouTube video or live stream, opened with yt-dlp
	entLive           // a single live source (camera, screen, test, URL)
)

// entry is one item in the playlist.
type entry struct {
	src   string // file path or URL
	name  string // name to show ("" = made from the file name)
	group string // the IPTV list's group-title (News, Sports, ...)
	kind  int
}

// label is the entry's name for lists and the status line.
func (e entry) label() string {
	if e.name != "" {
		return e.name
	}
	if e.kind == entFile {
		return filepath.Base(e.src)
	}
	return e.src
}

// streamOpts holds ffmpeg input options an IPTV list asks for per stream
// (a user agent or referrer some providers require), by stream URL.
var streamOpts = struct {
	sync.Mutex
	m map[string][]string
}{m: map[string][]string{}}

func setStreamOpts(u string, opts []string) {
	streamOpts.Lock()
	defer streamOpts.Unlock()
	if len(opts) == 0 {
		delete(streamOpts.m, u)
		return
	}
	streamOpts.m[u] = opts
}

// inputOptsFor is the ffmpeg options to put before "-i src".
func inputOptsFor(src string) []string {
	streamOpts.Lock()
	defer streamOpts.Unlock()
	return append([]string(nil), streamOpts.m[src]...)
}

// looksLikeM3U reports whether src names a .m3u/.m3u8 file or link, or an
// IPTV provider's list link (get.php?...&type=m3u_plus and the like).
func looksLikeM3U(src string) bool {
	low := strings.ToLower(src)
	if isURL(src) {
		u, err := url.Parse(src)
		if err != nil {
			return false
		}
		p := strings.ToLower(u.Path)
		return strings.HasSuffix(p, ".m3u") || strings.HasSuffix(p, ".m3u8") ||
			strings.Contains(strings.ToLower(u.RawQuery), "m3u")
	}
	return strings.HasSuffix(low, ".m3u") || strings.HasSuffix(low, ".m3u8")
}

// isHLS reports whether a playlist's text is one stream (HLS) rather than
// a list of channels.
func isHLS(text []byte) bool {
	for _, tag := range []string{"#EXT-X-TARGETDURATION", "#EXT-X-STREAM-INF", "#EXT-X-MEDIA-SEQUENCE", "#EXT-X-MEDIA:", "#EXT-X-ENDLIST"} {
		if bytes.Contains(text, []byte(tag)) {
			return true
		}
	}
	return false
}

const listUserAgent = "VLC/3.0.20 LibVLC/3.0.20" // IPTV providers expect a player

// readM3U gets a list's text from a file or a link.
func readM3U(ctx context.Context, src string) ([]byte, error) {
	const limit = 64 << 20
	if !isURL(src) {
		f, err := os.Open(src)
		if err != nil {
			return nil, err
		}
		defer f.Close()
		return io.ReadAll(io.LimitReader(f, limit))
	}
	ctx, cancel := context.WithTimeout(ctx, 45*time.Second)
	defer cancel()
	req, err := http.NewRequestWithContext(ctx, "GET", src, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", listUserAgent)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("the list's server answered %s", resp.Status)
	}
	return io.ReadAll(io.LimitReader(resp.Body, limit))
}

// loadM3U reads an IPTV list. live is set instead when src turns out to
// be a single HLS stream.
func loadM3U(ctx context.Context, src string) (list []entry, live string, err error) {
	text, err := readM3U(ctx, src)
	if err != nil {
		if isURL(src) && strings.HasSuffix(strings.ToLower(strings.SplitN(src, "?", 2)[0]), ".m3u8") {
			return nil, src, nil // couldn't look inside: let ffmpeg try it as a stream
		}
		return nil, "", fmt.Errorf("can't read the list %s: %v", src, err)
	}
	if isHLS(text) {
		return nil, src, nil
	}
	base := src
	if !isURL(src) {
		base = filepath.Dir(src)
	}
	list = parseM3U(text, base)
	if len(list) == 0 {
		return nil, "", fmt.Errorf("no channels or videos found in %s", src)
	}
	return list, "", nil
}

// parseM3U turns an extended M3U into entries. base resolves relative
// entries: a folder for a file on this PC, or the list's own link.
func parseM3U(text []byte, base string) []entry {
	var out []entry
	var name, group, groupLine string
	var opts []string
	sc := bufio.NewScanner(bytes.NewReader(text))
	sc.Buffer(make([]byte, 64<<10), 4<<20)
	first := true
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if first {
			line = strings.TrimPrefix(line, "\ufeff")
			first = false
		}
		switch {
		case line == "":
		case strings.HasPrefix(line, "#EXTINF"):
			name, group = parseExtinf(line)
		case strings.HasPrefix(line, "#EXTGRP:"):
			groupLine = strings.TrimSpace(line[len("#EXTGRP:"):])
		case strings.HasPrefix(line, "#EXTVLCOPT:"):
			k, v, _ := strings.Cut(line[len("#EXTVLCOPT:"):], "=")
			switch strings.ToLower(strings.TrimSpace(k)) {
			case "http-user-agent":
				opts = append(opts, "-user_agent", strings.TrimSpace(v))
			case "http-referrer", "http-referer":
				opts = append(opts, "-referer", strings.TrimSpace(v))
			}
		case strings.HasPrefix(line, "#"):
			// other tags: #EXTM3U, #KODIPROP, comments
		default:
			src, pipeOpts := splitPipeHeaders(line)
			e := entry{src: src, name: name, group: group}
			if e.group == "" {
				e.group = groupLine
			}
			e.src, e.kind = resolveEntry(src, base)
			if all := append(append([]string(nil), opts...), pipeOpts...); len(all) > 0 && e.kind == entStream {
				setStreamOpts(e.src, all)
			}
			if e.kind != entFile || fileExists(e.src) {
				out = append(out, e)
			}
			name, group, opts = "", "", nil
		}
	}
	return out
}

// resolveEntry decides what one line of a list points at. base is the
// list's folder (a list on this PC) or its link (a list on the web).
func resolveEntry(src, base string) (string, int) {
	switch {
	case isYouTubeURL(src):
		return src, entYouTube
	case isURL(src):
		return src, entStream
	}
	p := src
	if strings.HasPrefix(strings.ToLower(p), "file:///") {
		p = filepath.FromSlash(p[len("file:///"):])
	}
	if base == "" || filepath.IsAbs(p) {
		return p, entFile
	}
	if isURL(base) { // a relative link in a list from the web
		if bu, err := url.Parse(base); err == nil {
			if ru, err := bu.Parse(strings.ReplaceAll(src, "\\", "/")); err == nil {
				return ru.String(), entStream
			}
		}
	}
	return filepath.Join(base, p), entFile
}

// parseExtinf reads `#EXTINF:-1 tvg-name="x" group-title="News",Channel Name`.
func parseExtinf(line string) (name, group string) {
	rest := line[len("#EXTINF"):]
	rest = strings.TrimPrefix(rest, ":")
	// The name follows the first comma that isn't inside quotes.
	inQ := false
	cut := -1
	for i, r := range rest {
		if r == '"' {
			inQ = !inQ
		} else if r == ',' && !inQ {
			cut = i
			break
		}
	}
	attrs := rest
	if cut >= 0 {
		attrs, name = rest[:cut], strings.TrimSpace(rest[cut+1:])
	}
	group = attrValue(attrs, "group-title")
	if name == "" {
		name = attrValue(attrs, "tvg-name")
	}
	return name, group
}

func attrValue(attrs, key string) string {
	low := strings.ToLower(attrs)
	i := strings.Index(low, key+`="`)
	if i < 0 {
		return ""
	}
	v := attrs[i+len(key)+2:]
	if j := strings.IndexByte(v, '"'); j >= 0 {
		v = v[:j]
	}
	return strings.TrimSpace(v)
}

// splitPipeHeaders handles Kodi-style "URL|User-Agent=x&Referer=y".
func splitPipeHeaders(line string) (string, []string) {
	u, hdrs, ok := strings.Cut(line, "|")
	if !ok || !isURL(u) {
		return line, nil
	}
	var opts []string
	var extra []string
	for _, kv := range strings.Split(hdrs, "&") {
		k, v, ok := strings.Cut(kv, "=")
		if !ok {
			continue
		}
		if dv, err := url.QueryUnescape(v); err == nil {
			v = dv
		}
		switch strings.ToLower(strings.TrimSpace(k)) {
		case "user-agent":
			opts = append(opts, "-user_agent", v)
		case "referer", "referrer":
			opts = append(opts, "-referer", v)
		default:
			extra = append(extra, strings.TrimSpace(k)+": "+v+"\r\n")
		}
	}
	if len(extra) > 0 {
		opts = append(opts, "-headers", strings.Join(extra, ""))
	}
	return strings.TrimSpace(u), opts
}

// matchEntries lists the positions of entries whose name or group contains
// every word of q (any case). An empty q matches everything.
func matchEntries(names []string, q string) []int {
	words := strings.Fields(strings.ToLower(q))
	var out []int
	for i, n := range names {
		ln := strings.ToLower(n)
		ok := true
		for _, w := range words {
			if !strings.Contains(ln, w) {
				ok = false
				break
			}
		}
		if ok {
			out = append(out, i)
		}
	}
	return out
}
