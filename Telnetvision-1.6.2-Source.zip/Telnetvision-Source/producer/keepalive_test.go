package main

import (
	"io"
	"net"
	"strings"
	"testing"
	"time"
)

// With nothing new to send, the last picture goes again now and then, so
// the server doesn't drop a quiet feed (a big YouTube video downloading).
func TestKeepAlive(t *testing.T) {
	keepAlive = 300 * time.Millisecond
	defer func() { keepAlive = 15 * time.Second }()
	s := NewSender(&Config{Channel: "cam"}, 0, t.Logf)
	a, b := net.Pipe()
	defer b.Close()
	dead := make(chan struct{})
	pic := framed([]byte{msgFrame, 1, 2, 3})
	s.SendVideo(pic)
	errc := make(chan error, 1)
	go func() { errc <- s.pump(a, dead, time.Now().Add(-time.Minute)) }()
	got := 0
	b.SetReadDeadline(time.Now().Add(4 * time.Second))
	for got < 3 {
		buf := make([]byte, len(pic))
		if _, err := io.ReadFull(b, buf); err != nil {
			t.Fatalf("after %d pictures: %v", got, err)
		}
		if string(buf) != string(pic) {
			t.Fatalf("sent % x, want the last picture again", buf)
		}
		got++
	}
	// The server closing the link after a long quiet spell says so.
	s.mu.Lock()
	s.lastWrite = time.Now().Add(-time.Minute)
	s.lastVideo = nil
	s.mu.Unlock()
	close(dead)
	s.cond.Broadcast()
	if err := <-errc; err == nil || !strings.Contains(err.Error(), "nothing to send") {
		t.Errorf("got %v", err)
	}
}
