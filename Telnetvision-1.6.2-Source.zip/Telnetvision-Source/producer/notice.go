package main

// The please-wait picture shown while a re-encoded copy is made: the last
// picture of the movie, dimmed, with a few words in big letters in the
// middle. It's drawn into the picture itself, so every viewer sees it the
// same way - in characters, sixel, JPEG XL or the web page - in letters a
// few times the size of normal text.

import "strings"

// font5x7 is a classic 5x7 pixel font: each glyph is 7 rows of 5 bits.
var font5x7 = map[rune][7]string{
	'A': {".###.", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"},
	'B': {"####.", "#...#", "#...#", "####.", "#...#", "#...#", "####."},
	'C': {".###.", "#...#", "#....", "#....", "#....", "#...#", ".###."},
	'D': {"####.", "#...#", "#...#", "#...#", "#...#", "#...#", "####."},
	'E': {"#####", "#....", "#....", "####.", "#....", "#....", "#####"},
	'F': {"#####", "#....", "#....", "####.", "#....", "#....", "#...."},
	'G': {".###.", "#...#", "#....", "#.###", "#...#", "#...#", ".####"},
	'H': {"#...#", "#...#", "#...#", "#####", "#...#", "#...#", "#...#"},
	'I': {".###.", "..#..", "..#..", "..#..", "..#..", "..#..", ".###."},
	'J': {"..###", "...#.", "...#.", "...#.", "...#.", "#..#.", ".##.."},
	'K': {"#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"},
	'L': {"#....", "#....", "#....", "#....", "#....", "#....", "#####"},
	'M': {"#...#", "##.##", "#.#.#", "#.#.#", "#...#", "#...#", "#...#"},
	'N': {"#...#", "#...#", "##..#", "#.#.#", "#..##", "#...#", "#...#"},
	'O': {".###.", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."},
	'P': {"####.", "#...#", "#...#", "####.", "#....", "#....", "#...."},
	'Q': {".###.", "#...#", "#...#", "#...#", "#.#.#", "#..#.", ".##.#"},
	'R': {"####.", "#...#", "#...#", "####.", "#.#..", "#..#.", "#...#"},
	'S': {".####", "#....", "#....", ".###.", "....#", "....#", "####."},
	'T': {"#####", "..#..", "..#..", "..#..", "..#..", "..#..", "..#.."},
	'U': {"#...#", "#...#", "#...#", "#...#", "#...#", "#...#", ".###."},
	'V': {"#...#", "#...#", "#...#", "#...#", "#...#", ".#.#.", "..#.."},
	'W': {"#...#", "#...#", "#...#", "#.#.#", "#.#.#", "#.#.#", ".#.#."},
	'X': {"#...#", "#...#", ".#.#.", "..#..", ".#.#.", "#...#", "#...#"},
	'Y': {"#...#", "#...#", ".#.#.", "..#..", "..#..", "..#..", "..#.."},
	'Z': {"#####", "....#", "...#.", "..#..", ".#...", "#....", "#####"},
	'0': {".###.", "#...#", "#..##", "#.#.#", "##..#", "#...#", ".###."},
	'1': {"..#..", ".##..", "..#..", "..#..", "..#..", "..#..", ".###."},
	'2': {".###.", "#...#", "....#", "...#.", "..#..", ".#...", "#####"},
	'3': {"#####", "...#.", "..#..", "...#.", "....#", "#...#", ".###."},
	'4': {"...#.", "..##.", ".#.#.", "#..#.", "#####", "...#.", "...#."},
	'5': {"#####", "#....", "####.", "....#", "....#", "#...#", ".###."},
	'6': {"..##.", ".#...", "#....", "####.", "#...#", "#...#", ".###."},
	'7': {"#####", "....#", "...#.", "..#..", ".#...", ".#...", ".#..."},
	'8': {".###.", "#...#", "#...#", ".###.", "#...#", "#...#", ".###."},
	'9': {".###.", "#...#", "#...#", ".####", "....#", "...#.", ".##.."},
	'%': {"##...", "##..#", "...#.", "..#..", ".#...", "#..##", "...##"},
	'-': {".....", ".....", ".....", "#####", ".....", ".....", "....."},
	'.': {".....", ".....", ".....", ".....", ".....", ".##..", ".##.."},
	':': {".....", ".##..", ".##..", ".....", ".##..", ".##..", "....."},
	' ': {".....", ".....", ".....", ".....", ".....", ".....", "....."},
}

// noticeScale is the largest whole size the lines fit at in a w x h
// picture (1 = 5x7 pixels a letter; 0 = they don't fit).
func noticeScale(w, h int, lines []string) int {
	longest := 0
	for _, l := range lines {
		longest = max(longest, len([]rune(l)))
	}
	if longest == 0 {
		return 0
	}
	// 6 pixels a letter (5 + a gap), 9 a line (7 + 2), a border round it.
	return min((w-4)/(6*longest), (h-2)/(9*len(lines)))
}

// drawNotice writes lines into an RGB picture (w x h), centred, in white
// capital letters with a dark shadow, on a darkened panel.
func drawNotice(rgb []byte, w, h int, lines []string) {
	if len(rgb) < w*h*3 {
		return
	}
	s := noticeScale(w, h, lines)
	if s < 1 {
		return
	}
	for i := range lines {
		lines[i] = strings.ToUpper(lines[i])
	}
	blockW, blockH := 0, len(lines)*9*s-2*s
	for _, l := range lines {
		blockW = max(blockW, len([]rune(l))*6*s-s)
	}
	x0, y0 := (w-blockW)/2, (h-blockH)/2
	set := func(x, y int, r, g, b byte) {
		if x >= 0 && y >= 0 && x < w && y < h {
			i := (y*w + x) * 3
			rgb[i], rgb[i+1], rgb[i+2] = r, g, b
		}
	}
	// A darker panel behind the words.
	pad := 2 * s
	for y := y0 - pad; y < y0+blockH+pad; y++ {
		for x := x0 - pad; x < x0+blockW+pad; x++ {
			if x >= 0 && y >= 0 && x < w && y < h {
				i := (y*w + x) * 3
				rgb[i], rgb[i+1], rgb[i+2] = rgb[i]/3, rgb[i+1]/3, rgb[i+2]/3+12
			}
		}
	}
	// Shadows first, then the letters over them.
	for pass := 0; pass < 2; pass++ {
		if pass == 0 && s == 1 {
			continue // too small for a shadow
		}
		off := 0
		var c byte = 255
		if pass == 0 {
			off, c = max(1, s/3), 0
		}
		for li, l := range lines {
			r := []rune(l)
			lx := (w - (len(r)*6*s - s)) / 2 // each line centred
			ly := y0 + li*9*s
			for ci, ch := range r {
				g, ok := font5x7[ch]
				if !ok {
					g = font5x7[' ']
				}
				for gy := 0; gy < 7; gy++ {
					for gx := 0; gx < 5; gx++ {
						if g[gy][gx] != '#' {
							continue
						}
						for dy := 0; dy < s; dy++ {
							for dx := 0; dx < s; dx++ {
								set(lx+(ci*6+gx)*s+dx+off, ly+gy*s+dy+off, c, c, c)
							}
						}
					}
				}
			}
		}
	}
}

// noticePicture is the dimmed picture with the notice on it (a fresh
// copy; nil picture: a black one).
func noticePicture(pic []byte, w, h int, lines []string) []byte {
	out := make([]byte, w*h*3)
	if len(pic) == len(out) {
		for i, x := range pic {
			out[i] = x / 3
		}
	}
	drawNotice(out, w, h, append([]string(nil), lines...))
	return out
}
