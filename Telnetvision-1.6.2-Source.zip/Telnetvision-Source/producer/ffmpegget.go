package main

// Getting an ffmpeg that can make JPEG XL pictures, when the one in use
// can't (gyan.dev's "essentials" build, the usual one, has no libjxl).
//
// It's downloaded once, from BtbN's FFmpeg builds on GitHub (the GPL
// "shared" build: ffmpeg.exe plus its DLLs, about 90 MB), into the
// ffmpeg-jxl folder next to telnetvision.exe, and used only for making the
// JPEG XL pictures; the ffmpeg already in use keeps doing everything else.
// If telnetvision.exe has no ffmpeg at all, it's used for everything.
// JXL_DOWNLOAD=0 turns this off.

import (
	"archive/zip"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"os"
	"path"
	"path/filepath"
	"runtime"
	"strings"
	"time"
)

const jxlFolder = "ffmpeg-jxl"

const btbnBase = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/"

// jxlFFmpegURL is the build for this PC's Windows (a 32-bit telnetvision.exe
// on 64-bit Windows still gets the 64-bit ffmpeg; it's a separate program).
// "" = there's none (32-bit Windows, or not Windows).
func jxlFFmpegURL() string {
	if runtime.GOOS != "windows" {
		return ""
	}
	arch := strings.ToUpper(os.Getenv("PROCESSOR_ARCHITEW6432")) // set for 32-bit programs on 64-bit Windows
	if arch == "" {
		arch = strings.ToUpper(os.Getenv("PROCESSOR_ARCHITECTURE"))
	}
	switch {
	case arch == "ARM64":
		return btbnBase + "ffmpeg-master-latest-winarm64-gpl-shared.zip"
	case arch == "AMD64" || runtime.GOARCH == "amd64":
		return btbnBase + "ffmpeg-master-latest-win64-gpl-shared.zip"
	}
	return ""
}

// jxlFFmpegPath is where a downloaded JPEG XL ffmpeg lives.
func jxlFFmpegPath() string {
	name := "ffmpeg"
	if runtime.GOOS == "windows" {
		name = "ffmpeg.exe"
	}
	return filepath.Join(exeDir(), jxlFolder, name)
}

// ffmpegForJXL returns an ffmpeg that can make JPEG XL pictures, or "".
// main is the ffmpeg in use ("" if there's none). It downloads one if
// needed and allowed, printing progress on the console.
func ffmpegForJXL(main string, allowDownload bool, logf func(string, ...any)) string {
	if main != "" && ffmpegHasJXL(main) {
		return main
	}
	local := jxlFFmpegPath()
	if _, err := os.Stat(local); err == nil {
		if ffmpegHasJXL(local) {
			return local
		}
		logf("JPEG XL: %s can't make JPEG XL pictures (delete the %s folder to download it again)", local, jxlFolder)
		return ""
	}
	if !allowDownload {
		return ""
	}
	url := jxlFFmpegURL()
	if url == "" {
		logf("JPEG XL: no ffmpeg that makes JPEG XL pictures can be downloaded for this PC; JXL viewers get sixel or characters instead")
		return ""
	}
	why := "this ffmpeg can't make JPEG XL pictures"
	if main == "" {
		why = "there's no ffmpeg here"
	}
	logf("JPEG XL: %s; downloading one that can (about 90 MB, only this once) into %s", why, filepath.Dir(local))
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Minute)
	defer cancel()
	if err := downloadFFmpeg(ctx, url, filepath.Dir(local), consoleProgress()); err != nil {
		logf("JPEG XL: couldn't download ffmpeg (%v); JXL viewers get sixel or characters instead. Put an ffmpeg with libjxl (gyan.dev's \"full\" build) next to telnetvision.exe, or set JXL_DOWNLOAD=0 to stop trying", err)
		return ""
	}
	if !ffmpegHasJXL(local) {
		logf("JPEG XL: the downloaded ffmpeg doesn't run here, or can't make JPEG XL; JXL viewers get sixel or characters instead")
		return ""
	}
	logf("JPEG XL: downloaded ffmpeg into %s; it makes the JPEG XL pictures from now on", filepath.Dir(local))
	return local
}

// consoleProgress prints "downloading ... 42%" on one console line.
func consoleProgress() func(done, total int64) {
	last := -1
	return func(done, total int64) {
		if total <= 0 {
			return
		}
		pct := int(done * 100 / total)
		if pct == last {
			return
		}
		last = pct
		fmt.Fprintf(os.Stderr, "\r  downloading ffmpeg for JPEG XL: %3d%% of %d MB ", pct, total>>20)
		if done >= total {
			fmt.Fprintln(os.Stderr)
		}
	}
}

// downloadFFmpeg fetches an ffmpeg build's zip and puts its bin folder's
// ffmpeg and DLLs into dir. dir appears whole or not at all.
func downloadFFmpeg(ctx context.Context, url, dir string, progress func(done, total int64)) error {
	parent := filepath.Dir(dir)
	if err := os.MkdirAll(parent, 0o755); err != nil {
		return err
	}
	tmp, err := os.CreateTemp(parent, "ffmpeg-download-*.zip")
	if err != nil {
		return fmt.Errorf("can't write in %s: %v", parent, err)
	}
	defer func() {
		tmp.Close()
		os.Remove(tmp.Name())
	}()
	req, err := http.NewRequestWithContext(ctx, "GET", url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("User-Agent", "telnetvision/"+version)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return fmt.Errorf("%s: %s", url, resp.Status)
	}
	var done int64
	buf := make([]byte, 256<<10)
	for {
		n, rerr := resp.Body.Read(buf)
		if n > 0 {
			if _, err := tmp.Write(buf[:n]); err != nil {
				return err
			}
			done += int64(n)
			if progress != nil {
				progress(done, resp.ContentLength)
			}
		}
		if rerr == io.EOF {
			break
		}
		if rerr != nil {
			return rerr
		}
	}
	if resp.ContentLength > 0 && done != resp.ContentLength {
		return fmt.Errorf("the download stopped early (%d of %d bytes)", done, resp.ContentLength)
	}

	zr, err := zip.NewReader(tmp, done)
	if err != nil {
		return fmt.Errorf("the download isn't a zip file: %v", err)
	}
	part := dir + ".part"
	os.RemoveAll(part)
	if err := os.MkdirAll(part, 0o755); err != nil {
		return err
	}
	defer os.RemoveAll(part)
	found := false
	for _, f := range zr.File {
		dirName, name := path.Split(f.Name)
		lname := strings.ToLower(name)
		if !strings.HasSuffix(strings.ToLower(dirName), "/bin/") || f.FileInfo().IsDir() {
			continue
		}
		if lname != "ffmpeg.exe" && lname != "ffmpeg" && !strings.HasSuffix(lname, ".dll") {
			continue // ffplay, ffprobe: not needed
		}
		if err := extractFile(f, filepath.Join(part, name)); err != nil {
			return err
		}
		if lname == "ffmpeg.exe" || lname == "ffmpeg" {
			found = true
		}
	}
	if !found {
		return errors.New("there's no ffmpeg in the download")
	}
	os.RemoveAll(dir)
	return os.Rename(part, dir)
}

func extractFile(f *zip.File, dst string) error {
	r, err := f.Open()
	if err != nil {
		return err
	}
	defer r.Close()
	w, err := os.OpenFile(dst, os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0o755)
	if err != nil {
		return err
	}
	if _, err := io.Copy(w, r); err != nil {
		w.Close()
		return err
	}
	return w.Close()
}
