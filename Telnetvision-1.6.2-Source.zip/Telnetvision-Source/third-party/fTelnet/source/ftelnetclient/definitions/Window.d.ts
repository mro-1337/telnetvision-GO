interface Window {
    clipboardData: ClipboardData;
}
