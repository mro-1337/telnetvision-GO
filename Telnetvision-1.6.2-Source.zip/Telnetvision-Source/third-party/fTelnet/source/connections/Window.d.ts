interface Window {
    cordova: any;
}
