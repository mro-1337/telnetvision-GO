package main

import (
	"bytes"
	"encoding/binary"
	"os/exec"
	"sync"
	"testing"
	"time"
)

func TestJXLDistance(t *testing.T) {
	for q, want := range map[int]float64{90: 1.0, 75: 2.35, 50: 4.6, 100: 0.1, 30: 6.4} {
		if d := jxlDistance(q); d < want-0.01 || d > want+0.01 {
			t.Errorf("quality %d: distance %.2f, want %.2f", q, d, want)
		}
	}
	if d := jxlDistance(1); d > 15 || d < 6.4 {
		t.Errorf("quality 1: %.2f", d)
	}
}

func TestSizedPicture(t *testing.T) {
	pic := make([]byte, 320*192*3)
	if _, w, h := sizedPicture(pic, 320, 192, 160); w != 160 || h != 96 {
		t.Fatalf("%dx%d", w, h)
	}
	if p, w, _ := sizedPicture(pic, 320, 192, 320); w != 320 || &p[0] != &pic[0] {
		t.Fatal("same size: untouched")
	}
}

// The real encoder, with this machine's ffmpeg (skipped without libjxl).
func TestJXLEncoder(t *testing.T) {
	ff, err := exec.LookPath("ffmpeg")
	if err != nil || !ffmpegHasJXL(ff) {
		t.Skip("no ffmpeg with libjxl here")
	}
	var mu sync.Mutex
	var got [][]byte
	e := newJXLEncoder(ff, 75, func(m []byte) {
		mu.Lock()
		got = append(got, m)
		mu.Unlock()
	}, t.Logf)
	defer e.stop()
	w, h := 64, 32
	for i := 0; i < 10; i++ {
		rgb := make([]byte, w*h*3)
		for j := range rgb {
			rgb[j] = byte(j*7 + i*20)
		}
		e.push(rgb, w, h, uint64(1000+i*66))
		time.Sleep(80 * time.Millisecond)
	}
	time.Sleep(500 * time.Millisecond)
	mu.Lock()
	defer mu.Unlock()
	if len(got) < 8 {
		t.Fatalf("only %d pictures out of 10", len(got))
	}
	var last uint64
	for _, m := range got {
		p := m[4:]
		if p[0] != msgFrameJXL || binary.BigEndian.Uint16(p[1:3]) != uint16(w) || binary.BigEndian.Uint16(p[3:5]) != uint16(h) {
			t.Fatalf("header %v", p[:5])
		}
		pts := binary.BigEndian.Uint64(p[5:13])
		if pts <= last {
			t.Fatalf("time stamps out of order: %d after %d", pts, last)
		}
		last = pts
		if !bytes.HasPrefix(p[13:], []byte{0xff, 0x0a}) && !bytes.HasPrefix(p[13:], []byte{0, 0, 0, 0x0c, 'J', 'X', 'L', ' '}) {
			t.Fatalf("not a JPEG XL picture: % x", p[13:21])
		}
	}
	t.Logf("%d pictures, last %d bytes", len(got), len(got[len(got)-1]))
}
