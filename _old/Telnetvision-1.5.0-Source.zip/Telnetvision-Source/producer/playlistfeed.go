package main

// The playlist for viewers (tvserver's L key): a viewer who is the only one
// watching can see what's in the playlist, play something now, or tag
// things to play next. tvserver asks for the list (WANT_PLAYLIST); this
// answers with PLAYLIST; a choice comes back as PLAY_ITEM.

import (
	"encoding/binary"
	"strconv"
	"strings"
)

const (
	msgPlaylist     = 0x17 // 0x17 | u32 now playing (0xFFFFFFFF = none) | u16 n | n x u32 up next, in order | names, one per line
	msgWantPlaylist = 0x23 // server -> producer: send PLAYLIST
	msgPlayItem     = 0x24 // server -> producer: 0x24 | u8 0 = play now, 1 = tag / untag as up next | u32 index
	capPlaylist     = 0x08 // hello caps: this producer shares its playlist

	maxPlaylistNames = 20000
	maxPlaylistName  = 200 // characters
)

// playlistPayload is a PLAYLIST message (framed).
func playlistPayload(cur int, upNext []int, names []string) []byte {
	if len(names) > maxPlaylistNames {
		names = names[:maxPlaylistNames]
	}
	if len(upNext) > 1000 {
		upNext = upNext[:1000]
	}
	p := []byte{msgPlaylist}
	c := uint32(0xFFFFFFFF)
	if cur >= 0 && cur < len(names) {
		c = uint32(cur)
	}
	p = binary.BigEndian.AppendUint32(p, c)
	p = binary.BigEndian.AppendUint16(p, uint16(len(upNext)))
	for _, i := range upNext {
		p = binary.BigEndian.AppendUint32(p, uint32(i))
	}
	clean := make([]string, len(names))
	for i, n := range names {
		n = strings.Map(func(r rune) rune {
			if r < 32 || r == 127 {
				return ' '
			}
			return r
		}, n)
		if r := []rune(n); len(r) > maxPlaylistName {
			n = string(r[:maxPlaylistName])
		}
		clean[i] = n
	}
	p = append(p, strings.Join(clean, "\n")...)
	return framed(p)
}

// handlePlaylistRequest acts on WANT_PLAYLIST / PLAY_ITEM from tvserver.
func handlePlaylistRequest(b []byte, p *Player, snd *Sender, logf func(string, ...any)) {
	switch {
	case b[0] == msgWantPlaylist:
		cur, up, names := p.PlaylistInfo()
		snd.SendControl(playlistPayload(cur, up, names))
	case b[0] == msgPlayItem && len(b) >= 6:
		mode, i := b[1], int(binary.BigEndian.Uint32(b[2:6]))
		_, _, names := p.PlaylistInfo()
		if i < 0 || i >= len(names) {
			return
		}
		if mode == 0 {
			logf("a viewer picked %d %s from the playlist: playing it now", i+1, names[i])
			p.Command("goto", strconv.Itoa(i+1))
		} else if on := p.ToggleUpNext(i); on {
			logf("a viewer tagged %d %s to play next", i+1, names[i])
		} else {
			logf("a viewer untagged %d %s", i+1, names[i])
		}
		cur, up, names := p.PlaylistInfo()
		snd.SendControl(playlistPayload(cur, up, names))
	}
}
