package main

// Re-encoding a movie this PC can't decode fast enough (REENCODE=1).
//
// A 4K or HEVC movie can be too heavy to decode in real time on an older
// PC: picture and sound then crawl. With REENCODE=1, when that happens the
// player stops, and ffmpeg makes a lighter copy of the rest of the movie,
// from the exact place it had got to:
//
//	ffmpeg -ss <place> -i movie.mkv -vf scale=720:-2 -c:v libx264 -crf 23
//	       -preset veryfast -c:a aac  tmp.movie.ts
//
// Viewers see the last picture, dimmed, with a please-wait notice and how
// far along it is. The copy is an MPEG-TS file, which can be played while
// it's still being written, so playing starts as soon as enough of it is
// made that it won't run out before the end (worked out from how fast it's
// being made); it starts at the exact place the movie had reached. Jumping
// around (J, the arrow keys) plays from the copy when it has that part, or
// starts a new copy from there. The copy is deleted when the movie ends or
// something else is played, and when telnetvision closes.

import (
	"bufio"
	"context"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

// reencodeFolder is where the temporary copies go.
func reencodeFolder(cfg *Config) string {
	if d := strings.TrimSpace(cfg.ReencodeFolder); d != "" {
		return d
	}
	return filepath.Join(os.TempDir(), "telnetvision-reencode")
}

// cleanReencodeFolder deletes copies left behind by a telnetvision that
// didn't close normally (only in our own folder, and only old ones).
func cleanReencodeFolder(cfg *Config) {
	dir := reencodeFolder(cfg)
	ents, err := os.ReadDir(dir)
	if err != nil {
		return
	}
	for _, e := range ents {
		if !strings.HasPrefix(e.Name(), "tmp.") || !strings.HasSuffix(e.Name(), ".ts") {
			continue
		}
		if fi, err := e.Info(); err == nil && time.Since(fi.ModTime()) > 10*time.Minute {
			os.Remove(filepath.Join(dir, e.Name()))
		}
	}
}

// reencodeArgs is the ffmpeg command that makes the copy.
func reencodeArgs(cfg *Config, src string, start float64, out string) []string {
	a := []string{"-hide_banner", "-loglevel", "error", "-nostdin", "-y", "-nostats", "-progress", "pipe:1"}
	a = append(a, decodeArgs(cfg)...)
	if start >= 0.05 {
		a = append(a, "-ss", strconv.FormatFloat(start, 'f', 3, 64))
	}
	w := cfg.ReencodeWidth
	if w <= 0 {
		w = 720
	}
	crf := cfg.ReencodeCRF
	if crf <= 0 {
		crf = 23
	}
	preset := cfg.ReencodePreset
	if preset == "" {
		preset = "veryfast"
	}
	a = append(a, "-i", src,
		"-map", "0:v:0", "-map", "0:a:0?", "-sn", "-dn",
		// Never wider than the movie, an even height, and plain 8-bit
		// colour (a 10-bit copy would be slow to play again).
		"-vf", fmt.Sprintf("scale='min(%d,iw)':-2", w), "-pix_fmt", "yuv420p",
		"-c:v", "libx264", "-preset", preset, "-crf", strconv.Itoa(crf), "-g", "50",
		"-c:a", "aac", "-b:a", "160k",
		"-f", "mpegts", out)
	return a
}

// reencoder makes one copy, from start to the end of the movie.
type reencoder struct {
	src, path string
	start     float64 // where in the movie the copy begins (s)
	total     float64 // how much of the movie it covers (s; 0 = unknown)
	began     time.Time
	cancel    context.CancelFunc
	finished  chan struct{}

	mu      sync.Mutex
	encoded float64 // seconds of movie made so far
	done    bool    // the whole copy is made
	err     error
}

func startReencode(ctx context.Context, ffmpeg string, cfg *Config, src string, start, duration float64, logf func(string, ...any)) (*reencoder, error) {
	dir := reencodeFolder(cfg)
	if err := os.MkdirAll(dir, 0o755); err != nil {
		return nil, fmt.Errorf("can't make the folder %s: %v", dir, err)
	}
	var rnd [3]byte
	rand.Read(rnd[:])
	name := strings.TrimSuffix(filepath.Base(src), filepath.Ext(src))
	path := filepath.Join(dir, "tmp."+name+"."+hex.EncodeToString(rnd[:])+".ts")
	rctx, cancel := context.WithCancel(ctx)
	r := &reencoder{src: src, path: path, start: start, began: time.Now(), cancel: cancel, finished: make(chan struct{})}
	if duration > start {
		r.total = duration - start
	}
	cmd := ffmpegCommand(rctx, ffmpeg, reencodeArgs(cfg, src, start, path)...)
	tail := &tailBuffer{}
	cmd.Stderr = tail
	out, err := cmd.StdoutPipe()
	if err == nil {
		err = cmd.Start()
	}
	if err != nil {
		cancel()
		return nil, fmt.Errorf("can't run ffmpeg: %v", err)
	}
	logf("re-encoding %s from %s, so this PC can play it smoothly (into %s)", filepath.Base(src), clockTime(start), path)
	go func() {
		defer close(r.finished)
		sc := bufio.NewScanner(out)
		for sc.Scan() {
			k, v, ok := strings.Cut(sc.Text(), "=")
			if !ok {
				continue
			}
			switch k {
			case "out_time_us", "out_time_ms": // both are microseconds
				if us, err := strconv.ParseInt(v, 10, 64); err == nil && us > 0 {
					r.mu.Lock()
					r.encoded = float64(us) / 1e6
					r.mu.Unlock()
				}
			case "progress":
				if v == "end" {
					r.mu.Lock()
					r.done = true
					r.mu.Unlock()
				}
			}
		}
		werr := cmd.Wait()
		r.mu.Lock()
		defer r.mu.Unlock()
		switch {
		case rctx.Err() != nil:
		case werr != nil && !r.done:
			why := tail.String()
			if why == "" {
				why = werr.Error()
			}
			r.err = fmt.Errorf("ffmpeg stopped: %s", why)
		default:
			r.done = true
			if r.total > 0 && r.encoded < r.total-5 && r.encoded > 0 {
				r.total = r.encoded // the movie was shorter than it said
			}
			logf("re-encoded copy finished (%s of movie in %s)", clockTime(r.encoded), clockTime(time.Since(r.began).Seconds()))
		}
	}()
	return r, nil
}

// state is how far along the copy is.
func (r *reencoder) state() (encoded float64, done bool, err error) {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.encoded, r.done, r.err
}

// speed is seconds of movie made per second (0 until it's been going a
// few seconds).
func (r *reencoder) speed() float64 {
	enc, _, _ := r.state()
	el := time.Since(r.began).Seconds()
	if el < 4 || enc <= 0 {
		return 0
	}
	return enc / el
}

// has reports whether the copy covers place at (or soon will: it's
// being made and is less than two minutes short of it).
func (r *reencoder) has(at float64) bool {
	enc, done, err := r.state()
	if err != nil || at < r.start-0.5 {
		return false
	}
	if done {
		return r.total <= 0 || at < r.start+r.total
	}
	return at <= r.start+enc+120
}

// leadNeeded is how far ahead of place at the copy must be before playing
// from there, so that it won't run out before the end of the movie: the
// copy keeps growing at speed s while it plays at 1.
func leadNeeded(remaining, s float64) float64 {
	const minLead = 15.0 // always a little in hand
	switch {
	case remaining <= 0:
		return minLead
	case s <= 0:
		return remaining // no speed yet: can't tell
	case s >= 1.15:
		return minLead
	}
	lead := remaining*(1-s)/s*1.15 + minLead
	return min(lead, remaining)
}

// ready reports whether playing from at can start now, and if not, about
// how long until it can (0 = unknown).
func (r *reencoder) ready(at float64) (bool, time.Duration) {
	enc, done, _ := r.state()
	if done {
		return true, 0
	}
	ahead := r.start + enc - at
	remaining := 0.0
	if r.total > 0 {
		remaining = r.start + r.total - at
	}
	s := r.speed()
	need := leadNeeded(remaining, s)
	if remaining <= 0 && s >= 1.15 {
		need = 15
	}
	if ahead >= need && ahead > 5 {
		return true, 0
	}
	if s <= 0 {
		return false, 0
	}
	return false, time.Duration((need - ahead) / s * float64(time.Second))
}

// percent is how much of the copy is made (0-100, -1 = unknown).
func (r *reencoder) percent() float64 {
	enc, done, _ := r.state()
	if done {
		return 100
	}
	if r.total <= 0 {
		return -1
	}
	return min(99, enc*100/r.total)
}

// close stops making the copy and deletes it.
func (r *reencoder) close() {
	r.cancel()
	<-r.finished
	// The player's ffmpeg may take a moment to let go of the file.
	for i := 0; i < 20; i++ {
		if err := os.Remove(r.path); err == nil || os.IsNotExist(err) {
			return
		}
		time.Sleep(250 * time.Millisecond)
	}
}

// aboutText is a rough "about 4 min" for the please-wait notice.
func aboutText(d time.Duration) string {
	switch {
	case d <= 0:
		return ""
	case d < 50*time.Second:
		return "less than a minute"
	case d < 90*time.Minute:
		return fmt.Sprintf("about %d min", int(d.Minutes()+0.5))
	}
	return fmt.Sprintf("about %.1f hours", d.Hours())
}
