package main

import (
	"os"
	"strings"
	"testing"
	"time"
)

func TestParseSeekTime(t *testing.T) {
	cases := map[string]string{
		"1:05:00": "=3900", "45:00": "=2700", "1:30": "=90", "90": "=5400", "90m": "=5400",
		"1h30m": "=5400", "45s": "=45", "1h": "=3600", "+10": "+600", "-5": "-300",
		"+30s": "+30", "-1:00": "-60", " 2 : 03 ": "=123", "0": "=0", "1.5": "=90",
	}
	for in, want := range cases {
		if got, ok := parseSeekTime(in); !ok || got != want {
			t.Errorf("parseSeekTime(%q) = %q, %v; want %q", in, got, ok, want)
		}
	}
	for _, bad := range []string{"", "+", "abc", "1:75", "1:2:3:4", "5x", "h", "-", "1::2"} {
		if got, ok := parseSeekTime(bad); ok {
			t.Errorf("parseSeekTime(%q) = %q, want an error", bad, got)
		}
	}
	if d := describeSeek("+300"); d != "5:00 ahead" {
		t.Errorf("describeSeek: %q", d)
	}
	if c := clockTime(3725); c != "1:02:05" {
		t.Errorf("clockTime: %q", c)
	}
}

func TestArrowKeysSeek(t *testing.T) {
	c := newControls(&Config{SeekStep: 5})
	c.key(keyRight)
	c.key(keyLeft)
	for _, want := range []string{"+300", "-300"} {
		a := <-c.actions
		if a.kind != "seek" || a.arg != want {
			t.Errorf("got %+v, want seek %s", a, want)
		}
	}
	c.key('j')
	for _, k := range []byte("1:05:00\r") {
		c.key(k)
	}
	if a := <-c.actions; a.kind != "seek" || a.arg != "=3900" {
		t.Errorf("J 1:05:00 gave %+v", a)
	}
}

func TestSeekInputArgs(t *testing.T) {
	f := t.TempDir() + "/movie.mkv"
	writeFile(t, f)
	c := &Config{Source: f, seekSec: 754.5}
	a, _, _, err := videoInputArgs(c, "ffmpeg")
	if err != nil {
		t.Fatal(err)
	}
	j := strings.Join(a, " ")
	if !strings.Contains(j, "-ss 754.500 -i "+f) {
		t.Errorf("no seek before the input: %s", j)
	}
	// The re-encoded copy starts at 600 s of the movie: 154.5 s into it.
	c.playFile, c.playOffset, c.growing = t.TempDir()+"/tmp.movie.ts", 600, true
	a, _, _, _ = videoInputArgs(c, "ffmpeg")
	j = strings.Join(a, " ")
	if !strings.Contains(j, "-follow 1") || !strings.Contains(j, "-ss 154.500 -i "+c.playFile) || strings.Contains(j, "stream_loop") {
		t.Errorf("copy input: %s", j)
	}
}

func TestSubtitlesAfterSeek(t *testing.T) {
	s := &Subtitles{mode: "sidecar", cues: []subCue{{start: 600, end: 603, text: "ten minutes in"}}}
	now := time.Now()
	s.startRun(now, 599)
	if got := s.Current(now.Add(1500 * time.Millisecond)); got != "ten minutes in" {
		t.Errorf("after a jump to 9:59, 1.5 s later: %q", got)
	}
}

func TestLeadNeeded(t *testing.T) {
	if l := leadNeeded(3600, 2); l != 15 {
		t.Errorf("fast copy: %v", l)
	}
	// Made at half speed, an hour left: needs to be over half an hour ahead.
	if l := leadNeeded(3600, 0.5); l < 3600*0.5*1.1 || l > 3600 {
		t.Errorf("half-speed copy: %v", l)
	}
	if l := leadNeeded(600, 0); l != 600 {
		t.Errorf("speed unknown: %v", l)
	}
}

func TestReencodeArgs(t *testing.T) {
	c := &Config{ReencodeWidth: 720, ReencodeCRF: 23, ReencodePreset: "veryfast"}
	j := strings.Join(reencodeArgs(c, "in.mkv", 1234.5, "out.ts"), " ")
	for _, want := range []string{"-ss 1234.500 -i in.mkv", "scale='min(720,iw)':-2", "-c:v libx264", "-crf 23", "-preset veryfast", "-c:a aac", "-f mpegts out.ts", "-progress pipe:1"} {
		if !strings.Contains(j, want) {
			t.Errorf("missing %q in %s", want, j)
		}
	}
}

func writeFile(t *testing.T, p string) {
	t.Helper()
	if err := os.WriteFile(p, []byte("x"), 0o644); err != nil {
		t.Fatal(err)
	}
}
